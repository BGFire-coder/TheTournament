using System.Collections;
using UnityEngine;

public enum EventTypes
{
    cardPlayed,
    multichoiceMade,
    chanceDecided,
    abilityActivated,
    cardUpgraded,
    turnEnded,
    matchEnded,
    error
}

public class EnemyEvent
{
    public EventTypes eventType;
    public string name;

    public virtual IEnumerator Resolve()
    {
        EventQueue.events.Remove(this);
        yield return null;
    }
}

public class CardPlayedEvent : EnemyEvent
{
    public int indexInHand;
    public int IndexOnBoard;
    public int cardType;

    public CardPlayedEvent()
    {
        eventType = EventTypes.cardPlayed;
    }

    public override IEnumerator Resolve()
    {
        yield return base.Resolve();
        Players player = GameObject.Find("EndTurnButton").GetComponent<EndTurn>().empty[1].GetComponent<Players>();
        if(cardType == 0)
        {
            if (player.hand[indexInHand].GetComponent<Basecard>().CheckIfPlayable()) player.hand[indexInHand].GetComponent<Basecard>().StartCoroutine(player.hand[indexInHand].GetComponent<Basecard>().Play(IndexOnBoard));
            else { /*error*/ }
        }
        else if (cardType == 1)
        {
            Robots robots = (Robots)player.typeController;
            Battery played = robots.batteries[indexInHand].GetComponent<Battery>();
            yield return played.StartCoroutine(played.Play(0));
        }
        else
        {
            //for later
        }
    }
}

public class MultichoiceEvent : EnemyEvent
{
    public int index;
    public int optionsCount;

    public MultichoiceEvent()
    {
        eventType = EventTypes.multichoiceMade;
    }
}

public class ChanceEvent : EnemyEvent
{
    public int chanceMode;

    public bool yesNo;
    public int chance;

    public int index;
    public int optionsCount;

    public int[] unordered;

    public ChanceEvent()
    {
        eventType = EventTypes.chanceDecided;
    }
}

public class AbilityEvent : EnemyEvent
{
    public bool effect;
    public int index;

    public AbilityEvent()
    {
        eventType = EventTypes.abilityActivated;
    }

    public override IEnumerator Resolve()
    {
        yield return base.Resolve();
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        if (effect)
        {
            if (controller.activeEffects[index].supportedTriggers.Contains("Ability")) yield return controller.activeEffects[index].StartCoroutine("Ability");
            else { /*error*/ }
        }
        else
        {
            Mythsunit unit = controller.board[1][index].GetComponent<Mythsunit>();
            if (unit != null && unit.currentcharges >= unit.charges) yield return unit.StartCoroutine(unit.UseAbility());
            else { /*error*/ }
        }
    }
}

public class UpgradeEvent : EnemyEvent
{
    public int index;
    public int discardIndex;

    public UpgradeEvent()
    {
        eventType = EventTypes.cardUpgraded;
    }

    public override IEnumerator Resolve()
    {
        yield return base.Resolve();
        if (index == discardIndex) { /*error*/ }
        else
        {
            Players player = GameObject.Find("EndTurnButton").GetComponent<EndTurn>().empty[1].GetComponent<Players>();
            yield return player.hand[index].GetComponent<Wildsunit>().StartCoroutine(player.hand[index].GetComponent<Wildsunit>().Upgrade());
            yield return player.hand[discardIndex].GetComponent<Basecard>().StartCoroutine("DiscardByUpgrade");
        }
    }
}

public class EndEvent : EnemyEvent
{
    public EndEvent()
    {
        eventType = EventTypes.turnEnded;
    }

    public override IEnumerator Resolve()
    {
        yield return base.Resolve();
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        yield return controller.StartCoroutine(controller.End());
    }
}
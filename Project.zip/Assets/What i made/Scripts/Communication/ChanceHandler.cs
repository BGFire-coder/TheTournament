using NUnit.Framework;
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using Unity.VisualScripting;

public static class ChanceHandler
{
    public static int mode = 0;
    public static IEnumerator MultiChoice<T>(List<T> collection)
    {
        if (mode == 0) ChanceValue.value = Random.Range(0, collection.Count);
        else
        {
            if(GameObject.Find("EndTurnButton").GetComponent<EndTurn>().turn == 0)
            {
                ChanceEvent chance = new ChanceEvent() { chanceMode = 2, optionsCount = collection.Count };
                Communication.forSend.Add(chance);
            }
            yield return new WaitUntil(() => EventQueue.events.Count > 0);
            if (EventQueue.events[0].eventType == EventTypes.chanceDecided)
            {
                ChanceValue.value = EventQueue.events[0].ConvertTo<ChanceEvent>().index;
                EventQueue.events.RemoveAt(0);
            }
            else
            {
                EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                Communication.forSend.Add(error);
            }
        }
    }

    public static IEnumerator Chance(int chance)
    {
        if(mode == 0) ChanceValue.yesNo = Random.Range(0, 100) < chance;
        else
        {
            if (GameObject.Find("EndTurnButton").GetComponent<EndTurn>().turn == 0)
            {
                ChanceEvent yesNo = new ChanceEvent() { chanceMode = 1, chance = chance };
                Communication.forSend.Add(yesNo);
            }
            yield return new WaitUntil(() => EventQueue.events.Count > 0);
            if (EventQueue.events[0].eventType == EventTypes.chanceDecided)
            {
                ChanceValue.yesNo = EventQueue.events[0].ConvertTo<ChanceEvent>().yesNo;
                EventQueue.events.RemoveAt(0);
            }
            else
            {
                EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                Communication.forSend.Add(error);
            }
        }
    }

    public static IEnumerator Order<T>(List<T> unordered)
    {
        List<T> indeces = new List<T>();
        for (int i = 0; i < unordered.Count; i++) indeces.Add(unordered[i]);
        if (mode == 0)
        {
            for (int i = 0; i < unordered.Count; i++)
            {
                int index = Random.Range(0, indeces.Count);
                unordered[i] = indeces[index];
                indeces.RemoveAt(index);
            }
        }
        else
        {
            int[] ints = new int[unordered.Count];
            for (int i = 0; i < ints.Length; i++) ints[i] = i;
            if (GameObject.Find("EndTurnButton").GetComponent<EndTurn>().turn == 0)
            {
                ChanceEvent order = new ChanceEvent() { chanceMode = 3, unordered = ints };
                Communication.forSend.Add(order);
            }
            yield return new WaitUntil(() => EventQueue.events.Count > 0);
            if (EventQueue.events[0].eventType == EventTypes.chanceDecided)
            {
                ints = EventQueue.events[0].ConvertTo<ChanceEvent>().unordered;
                EventQueue.events.RemoveAt(0);
                for (int i = 0; i < unordered.Count; i++)
                {
                    int index = ints[i];
                    unordered[i] = indeces[index];
                    indeces.RemoveAt(index);
                }
            }
            else
            {
                EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                Communication.forSend.Add(error);
            }
        }
    }
}

public static class ChanceValue
{
    public static int value;
    public static bool yesNo;
}
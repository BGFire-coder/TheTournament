using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Communication
{
    public static List<EnemyEvent> forSend = new List<EnemyEvent>();
    public static bool isOver = false;

    public static async Task StartConnection()
    {
        TcpClient client = new TcpClient();
        await client.ConnectAsync("95.168.240.43", 443);
        await client.GetStream().WriteAsync(new byte[1] { 2 });


        DeckSave myDeck = new DeckSave();
        myDeck = Deck.decks[0];
        myDeck.name = SaveSystem.save.name;
        string json = JsonUtility.ToJson(myDeck);
        byte[] confirm = await ReadFromStream(client.GetStream());
        if(Encoding.UTF8.GetString(confirm) != "connected")
        {
            client.Close();
            return;
        }
        await WriteToStream(client.GetStream(), Encoding.UTF8.GetBytes(json));


        byte[] buffer = await ReadFromStream(client.GetStream());
        Deck.decks[1] = JsonUtility.FromJson<DeckSave>(Encoding.UTF8.GetString(buffer));


        buffer = await ReadFromStream(client.GetStream());
        json = Encoding.UTF8.GetString(buffer);
        EnemyEvent enemyEvent = JsonUtility.FromJson<EnemyEvent>(json);
        if(enemyEvent.eventType == EventTypes.chanceDecided)
        {
            ChanceEvent chance = JsonUtility.FromJson<ChanceEvent>(json);
            Deck.decks[0].cards = chance.unordered;
        }
        else
        {
            EnemyEvent error = new EnemyEvent();
            error.eventType = EventTypes.error;
            json = JsonUtility.ToJson(error);
            await WriteToStream(client.GetStream(), Encoding.UTF8.GetBytes(json));
            client.Close();
            return;
        }


        buffer = await ReadFromStream(client.GetStream());
        json = Encoding.UTF8.GetString(buffer);
        if(json == "FirstTurn:")
        {
            await client.GetStream().ReadAsync(buffer, 0, 4);
            int turn = BitConverter.ToInt32(buffer);
            SceneManager.LoadScene("Battle");
            while (SceneManager.GetActiveScene().name != "Battle") await Task.Yield();
            GameObject.Find("EndTurnButton").GetComponent<EndTurn>().turn = turn;
            GameObject.Find("EndTurnButton").GetComponent<EndTurn>().mode = 1;
            await Communicate(client.GetStream());
            client.Close();
        }
        else
        {
            EnemyEvent error = new EnemyEvent();
            error.eventType = EventTypes.error;
            json = JsonUtility.ToJson(error);
            await WriteToStream(client.GetStream(), Encoding.UTF8.GetBytes(json));
            client.Close();
        }
    }

    async static Task Communicate(NetworkStream stream)
    {
        Listen(stream);
        while(!isOver)
        {
            while (forSend.Count == 0) await Task.Delay(10);
            forSend[0].name = SaveSystem.save.name;
            string json = JsonUtility.ToJson(forSend[0]);
            await WriteToStream(stream, Encoding.UTF8.GetBytes(json));
            forSend.RemoveAt(0);
        }
    }

    static async Task Listen(NetworkStream stream)
    {
        while(!isOver)
        {
            try
            {
                byte[] buffer = await ReadFromStream(stream);
                string json = Encoding.UTF8.GetString(buffer);
                EnemyEvent enemyEvent = JsonUtility.FromJson<EnemyEvent>(json);

                switch (enemyEvent.eventType)
                {
                    case EventTypes.cardPlayed:
                        {
                            CardPlayedEvent cardPlayed = JsonUtility.FromJson<CardPlayedEvent>(json);
                            EventQueue.events.Add(cardPlayed);
                            break;
                        }
                    case EventTypes.multichoiceMade:
                        {
                            MultichoiceEvent multichoice = JsonUtility.FromJson<MultichoiceEvent>(json);
                            EventQueue.events.Add(multichoice);
                            break;
                        }
                    case EventTypes.abilityActivated:
                        {
                            AbilityEvent ability = JsonUtility.FromJson<AbilityEvent>(json);
                            EventQueue.events.Add(ability);
                            break;
                        }
                    case EventTypes.chanceDecided:
                        {
                            ChanceEvent chance = JsonUtility.FromJson<ChanceEvent>(json);
                            EventQueue.events.Add(chance);
                            break;
                        }
                    case EventTypes.turnEnded:
                        {
                            EndEvent endTurn = JsonUtility.FromJson<EndEvent>(json);
                            EventQueue.events.Add(endTurn);
                            break;
                        }
                    case EventTypes.cardUpgraded:
                        {
                            UpgradeEvent upgrade = JsonUtility.FromJson<UpgradeEvent>(json);
                            EventQueue.events.Add(upgrade);
                            break;
                        }
                    default:
                        {
                            EventQueue.events.Add(enemyEvent);
                            break;
                        }
                }
            }
            catch (Exception e)
            {
                Debug.Log(e.Message);
            }
        }
    }

    async static Task WriteToStream(NetworkStream stream, byte[] message)
    {
        byte[] count = BitConverter.GetBytes(message.Length);
        await stream.WriteAsync(count, 0, count.Length);
        await stream.WriteAsync(message, 0, message.Length);
    }

    async static Task<byte[]> ReadFromStream(NetworkStream stream)
    {
        byte[] count = new byte[4];
        for (int i = 0; i < 4;) i += await stream.ReadAsync(count, i, 4 - i);
        int amount = BitConverter.ToInt32(count);
        byte[] bytes = new byte[amount];
        for (int i = 0; i < amount;) i += await stream.ReadAsync(bytes, i, amount - i);
        return bytes;
    }
}
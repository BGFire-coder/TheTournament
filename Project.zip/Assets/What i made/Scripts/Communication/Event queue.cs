using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting.Antlr3.Runtime;
using UnityEngine;

public static class EventQueue
{
    public static List<EnemyEvent> events = new List<EnemyEvent>();
    static bool endOfTurn = false;

    public static IEnumerator Resolve()
    {
        yield return null;
        endOfTurn = false;
        while (!endOfTurn)
        {
            yield return new WaitUntil(() => events.Count > 0);
            if (events[0].eventType == EventTypes.multichoiceMade || events[0].eventType == EventTypes.chanceDecided)
            {
                EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                Debug.Log("error");
                Communication.forSend.Add(error);
            }
            if (events[0].eventType == EventTypes.turnEnded)
            {
                endOfTurn = true;
                yield return events[0].Resolve();
            }
            else yield return events[0].Resolve();
        }
    }
}
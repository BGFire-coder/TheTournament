using NUnit.Framework;
using System;
using System.Collections.Generic;
using UnityEngine;

public enum EffectNames
{
    ATKBoost,
    CritBoost,
    HpBoost,
    Multiattack,
    Burn,
    Poison,
    Stun,
    Freeze,
    Defense,
    AntiHeal,
    OtherSpecific
};

public class Effect : MonoBehaviour
{
    public EffectNames effect;
    public int power;
    public bool permanent = false;
    public GameObject creator;
    public GameObject target;
    public int[] index = new int[2];
    public bool buff;
    public int turns;
    public int turnsLeft;

    public List<string> supportedTriggers = new List<string>();
}
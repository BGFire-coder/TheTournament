using System;
using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Poison : Effect
{
    public GameObject affliction;
    public GameObject indicator;
    public EndTurn controller;
    GameObject child;

    void Awake()
    {
        effect = EffectNames.Poison;
        supportedTriggers.Add("OnTurnStart1");
        buff = false;
        affliction = GameObject.Find("Animation library").GetComponent<AnimationLibrary>().effects[5];
        indicator = GameObject.Find("Animation library").GetComponent<AnimationLibrary>().effects[6];
    }

    void Start()
    {
        turnsLeft = turns;
        Vector3 dir = creator.transform.position - target.transform.position;
        Vector3 center = (creator.transform.position + target.transform.position) / 2f;
        float angle = Mathf.Atan2(dir.x, -dir.y) * Mathf.Rad2Deg;
        child = Instantiate(affliction, center, Quaternion.Euler(0, 0, angle));
        child.transform.SetParent(transform, true);
    }

    public void Apply()
    {
        Transform poison = Instantiate(indicator, transform).transform;
        poison.position = PositionByIndex.GetPosition(index[0], index[1]) - new Vector3(0, 0.38f, 0);
    }
    public IEnumerator OnTurnStart1()
    {
        yield return null;
        turnsLeft--;
        if (turnsLeft == 0)
        {
            transform.parent.GetComponent<Unit>().statuses.Remove(this);
            Destroy(gameObject);
        }
    }

    public IEnumerator Hit(HitData data)
    {
        index[1] = Array.IndexOf(controller.board[index[0]], transform.parent.gameObject);
        if (data.side == index[0] && Array.IndexOf(controller.board[index[0]], transform.parent) != data.index)
        {
            yield return transform.parent.GetComponent<Unit>().StartCoroutine(transform.parent.GetComponent<Unit>().TakeDMG(new AttackData(1, false, creator, false, dmgTypes.damage)));
        }
    }
}
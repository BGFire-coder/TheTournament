using System.Collections;
using UnityEngine;

public class DmgBuff : Effect
{
    void Start()
    {
        effect = EffectNames.ATKBoost;
        buff = (power > 0) ? true : false;
    }
}

public class TimedDmgBuff : Effect
{
    void Start()
    {
        effect = EffectNames.ATKBoost;
        supportedTriggers.Add("OnTurnEndAA");
        buff = (power > 0) ? true : false;
    }

    public IEnumerator OnTurnEndAA()
    {
        turnsLeft--;
        if (turnsLeft == 0)
        {
            yield return null;
            GetComponentInParent<Unit>().statuses.Remove(this);
            Destroy(gameObject);
        }
    }
}
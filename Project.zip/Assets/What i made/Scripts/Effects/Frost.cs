using System.Collections;
using UnityEngine;

public class Frost : Effect
{
    public GameObject affliction;
    public GameObject indicator;

    void Start()
    {
        affliction = GameObject.Find("Animation Library").GetComponent<AnimationLibrary>().effects[7];
        indicator = GameObject.Find("Animation Library").GetComponent<AnimationLibrary>().effects[8];
        turnsLeft = turns;
        Vector3 dir = creator.transform.position - target.transform.position;
        Vector3 center = (creator.transform.position + target.transform.position - new Vector3(0, 1.2f, 0)) / 2f;
        float angle = Mathf.Atan2(dir.x, -dir.y) * Mathf.Rad2Deg;
        GameObject child = Instantiate(affliction, center, Quaternion.Euler(0, 0, angle));
        child.transform.SetParent(transform, true);

        effect = EffectNames.Freeze;
        GetComponentInParent<Unit>().statuses.Add(this);
        supportedTriggers.Add("OnTurnStart1");
        buff = false;
    }

    public void Apply()
    {
        Instantiate(indicator, transform);
    }

    public IEnumerator OnTurnStart1()
    {
        turnsLeft--;
        if (turnsLeft == 0)
        {
            yield return null;
            GetComponentInParent<Unit>().statuses.Remove(this);
            Destroy(gameObject);
        }
    }
}
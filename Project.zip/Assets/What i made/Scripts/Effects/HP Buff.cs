using UnityEngine;

public class HP_buff : Effect
{
    public void Start()
    {
        effect = EffectNames.HpBoost;
        buff = (power > 0) ? true : false;
    }
}
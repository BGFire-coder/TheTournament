using System.Collections;
using UnityEngine;

public class CritBuff : Effect
{
    void Start()
    {
        effect = EffectNames.CritBoost;
        buff = (power > 0) ? true : false;
    }
}

public class TimedCritBuff : Effect
{
    void Start()
    {
        effect = EffectNames.CritBoost;
        supportedTriggers.Add("OnTurnEndAA");
        buff = (power > 0) ? true : false;
    }

    public IEnumerator OnTurnEndAA()
    {
        turnsLeft--;
        if (turnsLeft == 0)
        {
            yield return null;
            GetComponentInParent<Unit>().statuses.Remove(this);
            Destroy(gameObject);
        }
    }
}
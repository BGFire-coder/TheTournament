using UnityEngine;

public class Afflict : MonoBehaviour
{
    public void Finish()
    {
        transform.parent.gameObject.SendMessage("Apply");
        Destroy(gameObject);
    }
}
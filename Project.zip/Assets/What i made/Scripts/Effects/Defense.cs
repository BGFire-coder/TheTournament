using System.Collections;

public class Defence : Effect
{
    void Start()
    {
        effect = EffectNames.Defense;
        supportedTriggers.Add("OnTurnStart1");
        buff = (power > 0) ? true : false;
    }

    public IEnumerator OnTurnStart1()
    {
        turnsLeft--;
        if (turnsLeft == 0)
        {
            yield return null;
            GetComponentInParent<Unit>().statuses.Remove(this);
            Destroy(gameObject);
        }
    }
}
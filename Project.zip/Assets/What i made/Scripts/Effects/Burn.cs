using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class Burn : Effect
{
    public GameObject affliction;
    public GameObject indicator;
    public EndTurn controller;
    Vector3 targetPosition;
    GameObject child;

    void Awake()
    {
        controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        effect = EffectNames.Burn;
        supportedTriggers.Add("OnTurnStart1");
        buff = false;
        affliction = GameObject.Find("Animation Library").GetComponent<AnimationLibrary>().effects[3];
        indicator = GameObject.Find("Animation Library").GetComponent<AnimationLibrary>().effects[4];
    }

    void Start()
    {
        turnsLeft = turns;
        if (controller.board[index[0]][index[1]] == controller.empty[index[0]]) targetPosition = PositionByIndex.GetPosition(index[0], index[1]);
        else targetPosition = target.transform.position;
        Vector3 dir = creator.transform.position - targetPosition;
        Vector3 center = (creator.transform.position + targetPosition) / 2f;
        float angle = Mathf.Atan2(dir.x, -dir.y) * Mathf.Rad2Deg;
        child = Instantiate(affliction, center, Quaternion.Euler(0, 0, angle));
        child.transform.SetParent(transform, true);
    }

    public void Apply()
    {
        Transform flame = Instantiate(indicator, transform).transform;
        flame.position = PositionByIndex.GetPosition(index[0], index[1]) - new Vector3(0, 0.375f, 0);
    }

    public IEnumerator OnTurnStart1()
    {
        if (!controller.burn.Contains(this))
        {
            yield return transform.parent.GetComponent<Unit>().StartCoroutine(transform.parent.GetComponent<Unit>().TakeDMG(new AttackData(1, false, creator, false, dmgTypes.damage)));
        }
        else yield return controller.empty[index[0]].GetComponent<Players>().StartCoroutine(controller.empty[index[0]].GetComponent<Players>().TakeDMG(new AttackData(1, false, creator, false, dmgTypes.damage)));
        turnsLeft--;
        if(turnsLeft == 0)
        {
            if(controller.board[index[0]][index[1]] != controller.empty[index[0]]) controller.board[index[0]][index[1]].GetComponent<Unit>().statuses.Remove(this);
            if(controller.burn.Contains(this)) controller.burn.Remove(this);
            Destroy(gameObject);
        }
    }
}
using System;
using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class MimiBuff : Effect
{
    public Myths source;
    public EndTurn controller;

    void Awake()
    {
        effect = EffectNames.OtherSpecific;
        supportedTriggers.Add("Hit");
        buff = true;
    }

    public IEnumerator Hit(HitData data)
    {
        index[1] = Array.IndexOf(controller.board[index[0]], transform.parent.gameObject);
        if (data.side == index[0] && Array.IndexOf(controller.board[index[0]], transform.parent) == data.index && data.attack.interactive)
        {
            yield return StartCoroutine(ChanceHandler.Chance(50));
            if (source.corpses > 10 && ChanceValue.yesNo)
            {
                yield return transform.parent.GetComponent<Unit>().StartCoroutine(transform.parent.GetComponent<Unit>().TakeDMG(new AttackData(data.attack.amount, false, creator, false, dmgTypes.heal)));
            }
        }
    }
}
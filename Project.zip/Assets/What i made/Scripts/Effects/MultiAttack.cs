using UnityEngine;

public class MuliAttack : Effect
{
    void Start()
    {
        effect = EffectNames.Multiattack;
        buff = true;
    }
}
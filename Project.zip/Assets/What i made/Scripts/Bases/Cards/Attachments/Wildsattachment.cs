using UnityEngine;

public class Wildsattachment : Attachment, IWilds
{
    public int energyCost;
    public int bloodCost;
    public int BloodCost { get => bloodCost; set => bloodCost = value; }
    public int EnergyCost { get => energyCost; set => energyCost = value; }
}

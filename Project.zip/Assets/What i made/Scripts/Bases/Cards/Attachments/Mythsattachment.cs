using UnityEngine;

public class Mythsattachment : Attachment, IMyths
{
    public int corpseCost;
    public int CorpseCost { get => corpseCost; set => corpseCost = value; }
}

using UnityEngine;

public class Warattachment : Attachment, IWar
{
    public int ammoCost;
    public int AmmoCost { get => ammoCost; set => ammoCost = value; }
}

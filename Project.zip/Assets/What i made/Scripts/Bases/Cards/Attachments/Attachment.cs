using UnityEngine;

public class Attachment : Basecard
{
    public Sprite icon;
}
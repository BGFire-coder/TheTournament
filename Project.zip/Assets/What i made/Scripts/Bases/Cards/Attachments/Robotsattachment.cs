using UnityEngine;

public class Robotsattachment : Attachment, IRobots
{
    public int[] colors = new int[4];
    public int[] Colors { get => colors; set => colors = value; }
}

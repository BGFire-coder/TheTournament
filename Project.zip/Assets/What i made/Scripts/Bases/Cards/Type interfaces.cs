using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;

public interface IWar
{
    int AmmoCost { get; set; }
}

public interface IWilds
{
    int EnergyCost { get; set; }
    int BloodCost { get; set; }

    public IEnumerator DiscardByUpgrade() { yield return null; }
}

public interface IRobots
{
    int[] Colors { get; set; }
}

public interface IMyths
{
    int CorpseCost { get; set; }
}
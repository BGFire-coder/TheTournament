using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR;

public class Robotsunit : Unit, IRobots
{
    public int[] colors = new int[4];
    public List<int> colorsPossesed = new List<int>();
    public SpriteRenderer[] renderers;
    public Sprite[] orColors;
    public Sprite[] andColors;
    public int topLimit = 4;
    public int bottomLimit = 0;
    public bool combined = false;
    public int[] Colors { get => colors; set => colors = value; }

    public override void Awake()
    {
        base.Awake();
        for(int i = 0; i < 4; i++)
        {
            if (colors[i] != 0)
            {
                renderers[i].enabled = true;
                if (colors[i] == 1) renderers[i].sprite = andColors[i];
                else renderers[i].sprite = orColors[i];
            }
        }
    }

    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for (int i = bottomLimit; i < topLimit + 1; i++)
        {
            if (array[mySide][i] == controller.empty[mySide]) positions.Add(i);
        }

        return positions;
    }

    public override void ApplyPermanents(PermanentModifiers permanent)
    {
        RobotsModifiers modifiers = (RobotsModifiers)permanent;
        if (modifiers.HPmodifier != 0)
        {
            statuses.Add(new HP_buff());
            statuses[statuses.Count - 1].power = modifiers.HPmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.ATKmodifier != 0)
        {
            statuses.Add(new DmgBuff());
            statuses[statuses.Count - 1].power = modifiers.ATKmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.Critmodifier != 0)
        {
            statuses.Add(new CritBuff());
            statuses[statuses.Count - 1].power = modifiers.Critmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
    }

    public override IEnumerator Play(int index)
    {
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        transform.position = PositionByIndex.GetPosition(mySide, index);
        transform.localScale = new Vector3(1.2f, 1.2f, 1);
        array[mySide][index] = gameObject;
        Destroy(GetComponent<BoxCollider2D>());
        pile = 1;
        if (combined) yield return Message.SendToAllOnASide(mySide, "Combined", null);
        else yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, index, colorsPossesed.ToArray()));
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Hit");
        for (int i = 0; i < 4; i++)
        {
            if (colorsPossesed.Contains(i))
            {
                renderers[i].enabled = true;
                renderers[i].sprite = andColors[i];
            }
            else renderers[i].enabled = false;
        }
    }

    public override bool CheckIfPlayable()
    {
        bool[] colorSatisfied = new bool[4];
        int[] activeBatteries = controller.empty[mySide].GetComponent<Robots>().colors;
        bool[] optionsSatisfied = new bool[4];
        int optional = colors.Max() - 1;
        for(int i = 0; i < 4; i++)
        {
            if (colors[i] == 0) colorSatisfied[i] = true;
            else if (activeBatteries[i] > 0)
            {
                colorSatisfied[i] = true;
                if (colors[i] > 1)
                {
                    optional--;
                    optionsSatisfied[i] = true;
                }
            }
        }
        if(optional < 1)
        {
            for(int i = 0; i < 4; i++) if (colors[i] > 1) colorSatisfied[i] = true;
        }
        if (!colorSatisfied.Contains(false))
        {
            for (int i = 0; i < 4; i++) if (optionsSatisfied[i]) colorsPossesed.Add(i);
            return true;
        }
        return false;
    }

    public bool CheckForTarget(GameObject[] free)
    {
        return array[mySide].Where(x => (x == controller.empty[mySide] || free.Contains(x)) && System.Array.IndexOf(array[mySide], x) < topLimit + 1 && System.Array.IndexOf(array[mySide], x) > bottomLimit - 1).ToList().Count > 0;
    }

    public virtual void AddColor(int color)
    {
        colorsPossesed.Add(color);
        renderers[color].enabled = true;
    }

    public virtual void RemoveColor(int color)
    {
        colorsPossesed.Remove(color);
        renderers[color].enabled = false;
    }

    public virtual IEnumerator Destroy()
    {
        currentHP = 0;
        yield return Message.SendToEffects(gameObject, "Destroy", null);
        if (currentHP == 0)
        {
            foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
            {
                controller.burn.Add(b);
                b.transform.SetParent(null, true);
            }
            if (System.Array.IndexOf(array[mySide], gameObject) > -1) if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
            Hide();
        }
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            int atk = 0;
            foreach (DmgBuff e in statuses.Where(x => x.effect == EffectNames.ATKBoost && x.permanent)) atk += e.power;
            int hp = 0;
            foreach (HP_buff e in statuses.Where(x => x.effect == EffectNames.HpBoost && x.permanent)) hp += e.power;
            int crit = 0;
            foreach (CritBuff e in statuses.Where(x => x.effect == EffectNames.CritBoost && x.permanent)) crit += e.power;
            RobotsModifiers rm = new RobotsModifiers();
            rm.ATKmodifier = atk;
            rm.HPmodifier = hp;
            rm.Critmodifier = crit;
            rm.timesCombined = 1;
            rm.previousColors = colorsPossesed.ToArray();
            controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], rm));
        }
    }
}

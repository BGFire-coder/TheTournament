using System.Collections;
using UnityEngine;

public class Mythsbook : Mythsunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Kill");
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        yield return null;
    }

    public IEnumerator Kill()
    {
        controller.empty[mySide].GetComponent<Myths>().corpses++;
        yield return null;
    }
}

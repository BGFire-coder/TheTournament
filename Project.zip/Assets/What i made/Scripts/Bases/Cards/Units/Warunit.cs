using System.Buffers;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;

public class Warunit : Unit, IWar
{
    public int ammoCost;
    public int maxLifetime;
    public int currentLifetime;
    public int discardableAfterTurns = 0;
    public int cycles = 0;
    public int AmmoCost { get => ammoCost; set => ammoCost = value; }

    public override void ApplyPermanents(PermanentModifiers permanent)
    {
        WarModifiers modifiers = (WarModifiers)permanent;
        if (modifiers.HPmodifier != 0)
        {
            statuses.Add(new HP_buff());
            statuses[statuses.Count - 1].power = modifiers.HPmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.ATKmodifier != 0)
        {
            statuses.Add(new DmgBuff());
            statuses[statuses.Count - 1].power = modifiers.ATKmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.Critmodifier != 0)
        {
            statuses.Add(new CritBuff());
            statuses[statuses.Count - 1].power = modifiers.Critmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        cycles = modifiers.cycles;
    }

    public override IEnumerator Play(int index)
    {
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        transform.position = PositionByIndex.GetPosition(mySide, index);
        array[mySide][index] = gameObject;
        transform.localScale = new Vector3(1.2f, 1.2f, 1);
        Destroy(GetComponent<BoxCollider2D>());
        pile = 1;
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, index, new int[0]));
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == index))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("ChangeLifetime");
        supportedTriggers.Add("OnTurnStart2");
        supportedTriggers.Add("OnMoved");
        supportedTriggers.Add("Hit");
    }

    public override bool CheckIfPlayable()
    {
        return ammoCost <= controller.empty[mySide].GetComponent<War>().ammo;
    }

    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for (int i = 0; i < 10; i++)
        {
            if (array[mySide][i] == controller.empty[mySide] && (i < 5 || (i > 4 && array[mySide][i - 5] != controller.empty[mySide]))) positions.Add(i);
        }
        return positions;
    }

    public override void ChangeResources()
    {
        controller.empty[mySide].GetComponent<War>().ammo -= ammoCost;
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return StartCoroutine(base.OnTurnStart1());
        if (System.Array.IndexOf(array[mySide], gameObject) < 5)
        {
            yield return StartCoroutine(ChangeLifetime(-1));
            yield return new WaitForSeconds(0.2f);
        }
    }

    public virtual IEnumerator ChangeLifetime(int amount)
    {
        currentLifetime += amount;
        if (currentLifetime < 1 && currentHP > 0)
        {
            yield return Message.SendToAll(mySide, "Kill", new KillData(gameObject, mySide, System.Array.IndexOf(array[mySide], gameObject)));
            if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
            foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
            {
                controller.burn.Add(b);
                b.transform.SetParent(null, true);
            }
            Hide();
        }
    }

    public virtual IEnumerator OnTurnStart2()
    {
        int index = System.Array.IndexOf(array[mySide], gameObject);
        if (index > 4 && array[mySide][index - 5] == controller.empty[mySide])
        {
            array[mySide][index] = controller.empty[mySide];
            array[mySide][index - 5] = gameObject;
            transform.position = PositionByIndex.GetPosition(mySide, index - 5);
            foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(array[mySide], gameObject)))
            {
                b.transform.SetParent(transform, true);
                statuses.Add(b);
            }
            yield return new WaitForSeconds(0.2f);
        }
    }

    public virtual IEnumerator OnMoved()
    {
        int index = System.Array.IndexOf(array[mySide], gameObject);
        if (index > 4 && array[mySide][index - 5] == controller.empty[mySide])
        {
            array[mySide][index] = controller.empty[mySide];
            array[mySide][index - 5] = gameObject;
            transform.position = PositionByIndex.GetPosition(mySide, index - 5);
            foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(array[mySide], gameObject)))
            {
                b.transform.SetParent(transform, false);
                statuses.Add(b);
            }
        }
        yield return null;
    }

    public override IEnumerator Discard()
    {
        if (pile == 0)
        {
            if (discardableAfterTurns == 0)
            {
                AddToDiscard();
                controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
                yield return new WaitForSeconds(0.05f);
                Destroy(gameObject);
            }
            else discardableAfterTurns--;
        }
        else if (currentHP < 1 || currentLifetime < 1)
        {
            AddToDiscard();
            yield return null;
            controller.disposed.Remove(gameObject);
            Destroy(gameObject);
        }
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            int atk = 0;
            foreach (DmgBuff e in statuses.Where(x => x.effect == EffectNames.ATKBoost && x.permanent)) atk += e.power;
            int hp = 0;
            foreach (HP_buff e in statuses.Where(x => x.effect == EffectNames.HpBoost && x.permanent)) hp += e.power;
            int crit = 0;
            foreach (CritBuff e in statuses.Where(x => x.effect == EffectNames.CritBoost && x.permanent)) crit += e.power;
            WarModifiers wm = new WarModifiers();
            wm.ATKmodifier = atk;
            wm.HPmodifier = hp;
            wm.Critmodifier = crit;
            wm.cycles = cycles;
            controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], wm));
        }
    }
}

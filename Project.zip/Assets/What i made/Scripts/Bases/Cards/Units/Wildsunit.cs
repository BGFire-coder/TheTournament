using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Wildsunit : Unit, IWilds
{
    public Sprite normal;
    public Sprite day;
    public Sprite night;
    public List<GameObject> upgradeDeath = new List<GameObject>();
    public int upgrade;
    public int bloodCost;
    public int energyCost;
    public bool claws = false;
    public int BloodCost { get => bloodCost; set => bloodCost = value; }
    public int EnergyCost { get => energyCost; set => energyCost = value; }

    public virtual IEnumerator Upgrade()
    {
        yield return null;
        if (controller.empty[mySide].GetComponent<Wilds>().day == 0)
        {
            upgrade = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = day;
            baseATK++;
            maxHP++;
            currentHP++;
        }
        else
        {
            upgrade = 2;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = night;
            gameObject.BroadcastMessage("Upgraded");
            if(bloodCost > 0) bloodCost--;
            if (energyCost > 0) energyCost--;
        }
        yield return Message.SendToAllOnASide(mySide, "Upgraded", null);
    }

    public virtual IEnumerator Upgrade(int cycle)
    {
        yield return null;
        if (cycle == 0)
        {
            upgrade = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = day;
            baseATK++;
            maxHP++;
            currentHP++;
        }
        else
        {
            upgrade = 2;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = night;
            gameObject.BroadcastMessage("Upgraded");
            if (bloodCost > 0) bloodCost--;
            if (energyCost > 0) energyCost--;
        }
        yield return Message.SendToAllOnASide(mySide, "Upgraded", null);
    }

    public virtual void RemoveUpgrade()
    {
        if(upgrade == 1)
        {
            maxHP--;
            baseATK--;
            if (currentHP > 1) currentHP--;
        }
        upgrade = 0;
        transform.Find("Background").GetComponent<SpriteRenderer>().sprite = normal;
        gameObject.BroadcastMessage("UpgradeRemoved");
    }

    public override void ApplyPermanents(PermanentModifiers permanent)
    {
        WildsModifiers modifiers = (WildsModifiers)permanent;
        if (modifiers.HPmodifier != 0)
        {
            statuses.Add(new HP_buff());
            statuses[statuses.Count - 1].power = modifiers.HPmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.ATKmodifier != 0)
        {
            statuses.Add(new DmgBuff());
            statuses[statuses.Count - 1].power = modifiers.ATKmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.Critmodifier != 0)
        {
            statuses.Add(new CritBuff());
            statuses[statuses.Count - 1].power = modifiers.Critmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.upgraded == 1)
        {
            upgrade = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = day;
            baseATK++;
            maxHP++;
            currentHP++;
        }
        else if (modifiers.upgraded == 2)
        {
            upgrade = 2;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = night;
            if (bloodCost > 0) bloodCost--;
            if (energyCost > 0) energyCost--;
        }
    }

    public override bool CheckIfPlayable()
    {
        Wilds owner = controller.empty[mySide].GetComponent<Wilds>();
        if (owner.blood >= bloodCost && owner.energy >= energyCost) return true;
        return false;
    }

    public override void ChangeResources()
    {
        Wilds owner = controller.empty[mySide].GetComponent<Wilds>();
        controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(bloodCost, false, gameObject, false, dmgTypes.heal)));
        owner.energy -= energyCost;
    }

    public override IEnumerator Attack()
    {
        if (statuses.Where(x => x.power == 1 && (x.effect == EffectNames.Freeze || x.effect == EffectNames.Stun)).ToList().Count == 0 && currentATK > 0)
        {
            int multiattack = 1;
            foreach (Effect effect in statuses.Where(x => x.effect == EffectNames.Multiattack)) multiattack += effect.power;
            for (int i = 0; i < multiattack; i++)
            {
                int crit = 1;
                bool isCrit = false;
                yield return StartCoroutine(ChanceHandler.Chance(currentCrit));
                if (ChanceValue.yesNo)
                {
                    isCrit = true;
                    crit = 2;
                }
                if(claws)
                {
                    int index = System.Array.IndexOf(array[mySide], gameObject);
                    List<GameObject> alreadyHit = new List<GameObject>();
                    if (attackAnimation != null)
                    {
                        GameObject attack = Instantiate(library.attacks[0]);
                        Attack anim = attack.GetComponent<Attack>();
                        anim.target = 4 - index;
                        anim.beggining = index;
                        anim.side = mySide;
                        yield return new WaitUntil(() => anim.finished);
                    }
                    for (int j = (index == 0? 4 : 5); j > (index == 4? 3 : 2); j--)
                    {
                        GameObject target = array[otherSide][j - index];
                        if(!alreadyHit.Contains(target))
                        {
                            if(target == controller.empty[otherSide]) yield return controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                            else yield return target.GetComponent<Unit>().StartCoroutine(target.GetComponent<Unit>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                            alreadyHit.Add(target);
                        }    
                    }
                }
                else
                {
                    int index = System.Array.IndexOf(array[mySide], gameObject);
                    if(attackAnimation != null)
                    {
                        GameObject attack = Instantiate(attackAnimation);
                        Attack anim = attack.GetComponent<Attack>();
                        anim.target = 4 - index;
                        anim.beggining = index;
                        anim.side = mySide;
                        yield return new WaitUntil(() => anim.finished);
                    }
                    GameObject target = array[otherSide][4 - index];
                    if(target == controller.empty[otherSide]) yield return controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                    else yield return target.GetComponent<Unit>().StartCoroutine(target.GetComponent<Unit>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                }
                if(isCrit) yield return Message.SendToBoard(mySide, "Crit", new CritData(mySide, System.Array.IndexOf(array[mySide], gameObject), gameObject));
                yield return new WaitForSeconds(0.1f);
            }
            yield return new WaitForSeconds(0.5f);
        }
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return base.OnTurnStart1();
        if (controller.empty[mySide].GetComponent<Wilds>().energy < 9) controller.empty[mySide].GetComponent<Wilds>().energy++;
    }

    public virtual IEnumerator DiscardByUpgrade()
    {
        yield return StartCoroutine(Discard());
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (currentHP > 0)
        {
            int defense = 0;
            int reduction = 0;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.AntiHeal)) reduction += e.power;
            if (atk.type != dmgTypes.damage)
            {
                if (atk.amount > reduction)
                {
                    currentHP += (atk.amount - reduction);
                    if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
                    Instantiate(heal, transform);
                    yield return Message.SendToSide(mySide, "Healed", new AttackData(atk.amount, atk.isCrit, gameObject, false, dmgTypes.heal));
                }
            }
            else if (defense < atk.amount)
            {
                currentHP -= (atk.amount - defense);
                if (atk.isCrit) Instantiate(crit, transform);
                else Instantiate(damage, transform);
                yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
            }
            if (currentHP < 1)
            {
                foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
                {
                    controller.burn.Add(b);
                    b.transform.SetParent(null, true);
                }
                yield return null;
                if (controller.empty[mySide].GetComponent<Players>().type == 4) controller.empty[mySide].GetComponent<Myths>().corpses++;
                if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
                if(upgrade == 0) Instantiate(death, transform.position, new Quaternion());
                else Instantiate(upgradeDeath[upgrade - 1], transform.position, new Quaternion());
                yield return Message.SendToAll(mySide, "Kill", new KillData(atk.attacker, mySide, System.Array.IndexOf(array[mySide], gameObject)));
                if (System.Array.IndexOf(array[mySide], gameObject) > -1) if (System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
                Hide();
            }
        }
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            int atk = 0;
            foreach (DmgBuff e in statuses.Where(x => x.effect == EffectNames.ATKBoost && x.permanent)) atk += e.power;
            int hp = 0;
            foreach (HP_buff e in statuses.Where(x => x.effect == EffectNames.HpBoost && x.permanent)) hp += e.power;
            int crit = 0;
            foreach (CritBuff e in statuses.Where(x => x.effect == EffectNames.CritBoost && x.permanent)) crit += e.power;
            WildsModifiers wm = new WildsModifiers();
            wm.ATKmodifier = atk;
            wm.HPmodifier = hp;
            wm.Critmodifier = crit;
            wm.upgraded = upgrade;
            controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], wm));
        }
    }
}
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class Unit : Basecard
{
    public int maxHP;
    public int currentHP;
    public int baseATK;
    public int currentATK;
    public int basecritrate;
    public int currentCrit;
    public List<Effect> statuses = new List<Effect>();

    public GameObject damage;
    public GameObject heal;
    public GameObject crit;

    public GameObject death;

    public virtual void ApplyPermanents(PermanentModifiers modifiers)
    {
        return;
    }

    public override void Start()
    {
        base.Start();
        damage = library.effects[0];
        heal = library.effects[1];
        crit = library.effects[2];
        death = library.deaths[type - 1];
    }

    public override IEnumerator Play(int index)
    {
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        transform.position = PositionByIndex.GetPosition(mySide, index);
        transform.localScale = new Vector3(1.2f, 1.2f, 1);
        array[mySide][index] = gameObject;
        if (type != 4) Destroy(GetComponent<BoxCollider2D>());
        pile = 1;
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, index, new int[0]));
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == index))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Hit");
    }


    public virtual IEnumerator Attack()
    {
        if (statuses.Where(x => x.power == 1 && (x.effect == EffectNames.Freeze || x.effect == EffectNames.Stun)).ToList().Count == 0 && currentATK > 0)
        {
            int multiattack = 1;
            foreach (Effect effect in statuses.Where(x => x.effect == EffectNames.Multiattack)) multiattack += effect.power;
            for (int i = 0; i < multiattack; i++)
            {
                int crit = 1;
                bool isCrit = false;
                yield return StartCoroutine(ChanceHandler.Chance(currentCrit));
                if (ChanceValue.yesNo)
                {
                    isCrit = true;
                    crit = 2;
                }
                int index = System.Array.IndexOf(array[mySide], gameObject);
                if(attackAnimation != null)
                {
                    GameObject attack = Instantiate(attackAnimation);
                    
                    Attack anim = attack.GetComponent<Attack>();
                    anim.target = 4 - index;
                    anim.beggining = index;
                    anim.side = mySide;
                    yield return new WaitUntil(() => anim.finished);
                }
                GameObject target = array[otherSide][4 - index];
                if (target == controller.empty[otherSide]) yield return controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                else yield return target.GetComponent<Unit>().StartCoroutine(target.GetComponent<Unit>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                if (isCrit) yield return Message.SendToBoard(mySide, "Crit", new CritData(mySide, index, gameObject));
                yield return new WaitForSeconds(0.1f);
            }
            yield return new WaitForSeconds(0.3f);
        }
    }

    public virtual void Update()
    {
        currentATK = baseATK;
        foreach (Effect e in statuses.Where(x => x.effect == EffectNames.ATKBoost)) currentATK += e.power;
        if(currentATK < 0) currentATK = 0;
        currentCrit = basecritrate;
        foreach (Effect e in statuses.Where(x => x.effect == EffectNames.CritBoost)) currentCrit += e.power;
        if(currentCrit < 0) currentCrit = 0;
    }

    public virtual IEnumerator TakeDMG(AttackData atk)
    {
        if(currentHP > 0)
        {
            int defense = 0;
            int reduction = 0;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.AntiHeal)) reduction += e.power;
            if (atk.type != dmgTypes.damage)
            {
                if(atk.amount > reduction)
                {
                    currentHP += (atk.amount - reduction);
                    if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
                    Instantiate(heal, transform);
                    yield return Message.SendToSide(mySide, "Healed", new AttackData(atk.amount, atk.isCrit, gameObject, false, dmgTypes.heal));
                }
            }
            else if (defense < atk.amount)
            {
                currentHP -= (atk.amount - defense);
                if (atk.isCrit) Instantiate(crit, transform);
                else Instantiate(damage, transform);
                yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
            }
            if (currentHP < 1)
            {
                foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
                {
                    controller.burn.Add(b);
                    b.transform.SetParent(null, true);
                }
                yield return null;
                if (controller.empty[mySide].GetComponent<Players>().type == 4) controller.empty[mySide].GetComponent<Myths>().corpses++;
                if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
                Instantiate(death, transform.position, new Quaternion());
                yield return Message.SendToAll(mySide, "Kill", new KillData(atk.attacker, mySide, System.Array.IndexOf(array[mySide], gameObject)));
                if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
                Hide();
            }
        }
    }

    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for(int i  = 0; i < 5; i++)
        {
            if (array[mySide][i] == controller.empty[mySide]) positions.Add(i);
        }

        return positions;
    }

    public virtual IEnumerator OnTurnStart1()
    {
        yield return Message.SendToEffects(gameObject, "OnTurnStart1", null);
    }

    public virtual IEnumerator OnTurnEndBA()
    {
        yield return Message.SendToEffects(gameObject, "OnTurnEndBA", null);
    }

    public virtual IEnumerator OnTurnEndAA()
    {
        yield return Message.SendToEffects(gameObject, "OnTurnEndAA", null);
    }

    public virtual IEnumerator Hit(HitData data)
    {
        if (data.side == mySide && data.index != System.Array.IndexOf(array[mySide], gameObject) && currentHP > 0)
        {
            foreach (Effect e in statuses.ToArray().Where(e => e.supportedTriggers.Contains("Hit"))) yield return e.StartCoroutine("Hit", data);
        }
    }

    public virtual void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
        foreach (SpriteRenderer sr in GetComponentsInChildren<SpriteRenderer>()) if(sr.gameObject.name != "Burning(Clone)") sr.enabled = false;
        foreach(TextMeshPro text in GetComponentsInChildren<TextMeshPro>()) text.enabled = false;
        if(!controller.disposed.Contains(gameObject)) controller.disposed.Add(gameObject);
    }

    public override IEnumerator Discard()
    {
        if (pile == 0)
        {
            AddToDiscard();
            controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
            OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
            yield return new WaitForSeconds(0.05f);
            Destroy(gameObject);
        }
        else if (currentHP < 1)
        {
            AddToDiscard();
            yield return null;
            controller.disposed.Remove(gameObject);
            Destroy(gameObject);
        }
    }
}
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using TMPro;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Mythsunit : Unit, IMyths
{
    public int corpseCost;
    public int charges;
    public int currentcharges;
    public bool healEnabled;
    public int healAmount = 1;
    public int chargeRate;
    public int CorpseCost { get => corpseCost; set => corpseCost = value; }

    public override void ApplyPermanents(PermanentModifiers permanent)
    {
        MythsModifiers modifiers = (MythsModifiers)permanent;
        if (modifiers.HPmodifier != 0)
        {
            statuses.Add(new HP_buff());
            statuses[statuses.Count - 1].power = modifiers.HPmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.ATKmodifier != 0)
        {
            statuses.Add(new DmgBuff());
            statuses[statuses.Count - 1].power = modifiers.ATKmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.Critmodifier != 0)
        {
            statuses.Add(new CritBuff());
            statuses[statuses.Count - 1].power = modifiers.Critmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if(modifiers.healing != 0) healAmount = modifiers.healing;
        if(modifiers.chargeRate != 0) chargeRate = modifiers.chargeRate;
        if(modifiers.charges != 0) charges = modifiers.charges;
    }

    public override IEnumerator Play(int index)
    {
        supportedTriggers.Add("Charge");
        yield return base.Play(index);
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return StartCoroutine(base.OnTurnStart1());
        if (healEnabled) yield return StartCoroutine(TakeDMG(new AttackData(1, false, gameObject, true, dmgTypes.heal)));
        if (currentcharges < charges)
        {
            Charge(chargeRate);
            if (currentcharges >= charges) healEnabled = false;
        }
    }

    public override IEnumerator OnMouseDown()
    {
        if(pile == 1)
        {
            if (charges <= currentcharges && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0 && controller.runningProcesses == 0 && controller.turn == mySide)
            {
                int index = Array.IndexOf(array[mySide], gameObject);
                yield return StartCoroutine(AbilityPrep());
                if(currentcharges == 0 && controller.mode == 1)
                {
                    AbilityEvent ability = new AbilityEvent() { effect = false, index = index };
                    Communication.forSend.Add(ability);
                }
            }
        }
        else yield return base.OnMouseDown();
    }

    public override bool CheckIfPlayable()
    {
        return corpseCost <= controller.empty[mySide].GetComponent<Myths>().corpses;
    }

    public virtual IEnumerator AbilityPrep()
    {
        controller.runningProcesses++;
        yield return StartCoroutine(UseAbility());
        if (currentcharges == 0) yield return Message.SendToSide(mySide, "Ability", Array.IndexOf(array[mySide], gameObject));
        controller.runningProcesses--;
    }

    public virtual IEnumerator UseAbility()
    {
        yield break;
    }

    public virtual void Charge(int amount)
    {
        currentcharges += amount;
        if (currentcharges >= charges)
        {
            currentcharges = charges;
            healEnabled = false;
        }
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            int atk = 0;
            foreach (DmgBuff e in statuses.Where(x => x.effect == EffectNames.ATKBoost && x.permanent)) atk += e.power;
            int hp = 0;
            foreach (HP_buff e in statuses.Where(x => x.effect == EffectNames.HpBoost && x.permanent)) hp += e.power;
            int crit = 0;
            foreach (CritBuff e in statuses.Where(x => x.effect == EffectNames.CritBoost && x.permanent)) crit += e.power;
            MythsModifiers mm = new MythsModifiers();
            mm.ATKmodifier = atk;
            mm.HPmodifier = hp;
            mm.Critmodifier = crit;
            mm.healing = healAmount;
            mm.chargeRate = chargeRate;
            mm.charges = charges;
            controller.empty[mySide].GetComponent<Players>().drawPile.Insert(0, (controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], mm));
        }
    }
}
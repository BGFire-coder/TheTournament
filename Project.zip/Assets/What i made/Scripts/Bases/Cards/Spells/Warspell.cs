using System.Collections;
using UnityEngine;

public class Warspell : Spell, IWar
{
    public int ammoCost;
    public int AmmoCost { get => ammoCost; set => ammoCost = value; }
    public int discardableAfterTurns = 0;
    public int cycles;

    public void ApplyPermanents(WarModifiers modifiers)
    {
        cycles = modifiers.cycles;
    }

    public override IEnumerator Discard()
    {
        if (discardableAfterTurns == 0) yield return StartCoroutine(base.Discard());
        else discardableAfterTurns--;
    }

    public override bool CheckIfPlayable()
    {
        return ammoCost <= controller.empty[mySide].GetComponent<War>().ammo;
    }

    public override void ChangeResources()
    {
        controller.empty[mySide].GetComponent<War>().ammo -= ammoCost;
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            WarModifiers wm = new WarModifiers();
            wm.cycles = cycles;
            controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], wm));
        }
    }
}

using System.Linq;
using UnityEngine;

public class Mythsspell : Spell, IMyths
{
    public int corpseCost;
    public int CorpseCost { get => corpseCost; set => corpseCost = value; }

    public override bool CheckIfPlayable()
    {
        return corpseCost <= controller.empty[mySide].GetComponent<Myths>().corpses;
    }

    public override void ChangeResources()
    {
        controller.empty[mySide].GetComponent<Myths>().corpses -= corpseCost;
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], new MythsModifiers()));
        }
    }
}

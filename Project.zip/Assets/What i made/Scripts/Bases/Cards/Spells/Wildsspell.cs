using System.Collections;
using UnityEngine;

public class Wildsspell : Spell, IWilds
{
    public int bloodCost;
    public int energyCost;
    public int BloodCost { get => bloodCost; set => bloodCost = value; }
    public int EnergyCost { get => energyCost; set => energyCost = value; }

    public override bool CheckIfPlayable()
    {
        return bloodCost <= controller.empty[mySide].GetComponent<Wilds>().blood && energyCost <= controller.empty[mySide].GetComponent<Wilds>().energy;
    }

    public override void ChangeResources()
    {
        controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(bloodCost, false, gameObject, false, dmgTypes.heal)));
        controller.empty[mySide].GetComponent<Wilds>().energy -= energyCost;
    }

    public virtual IEnumerator DiscardByUpgrade()
    {
        yield return StartCoroutine(Discard());
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
    }
}

using System.Collections.Generic;
using UnityEngine;

public class Spell : Basecard
{
    public bool global;

    public override void Start()
    {
        base.Start();
        if (global) pickedIndex = 0;
    }

    public override List<int> GetTargets()
    {
        return new List<int>() { 0 };
    }
}
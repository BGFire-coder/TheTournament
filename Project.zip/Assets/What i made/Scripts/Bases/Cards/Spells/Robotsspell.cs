using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Robotsspell : Spell, IRobots
{
    public int[] colors = new int[4];
    public List<int> colorsPossesed = new List<int>();
    public SpriteRenderer[] renderers;
    public Sprite[] orColors;
    public Sprite[] andColors;
    public int[] Colors { get => colors; set => colors = value; }

    public override void Awake()
    {
        base.Awake();
        for (int i = 0; i < 4; i++)
        {
            if (colors[i] != 0)
            {
                renderers[i].enabled = true;
                if (colors[i] == 1) renderers[i].sprite = andColors[i];
                else renderers[i].sprite = orColors[i];
            }
        }
    }

    public override bool CheckIfPlayable()
    {
        bool[] colorSatisfied = new bool[4];
        int[] activeBatteries = controller.empty[mySide].GetComponent<Robots>().colors;
        bool[] optionsSatisfied = new bool[4];
        int optional = colors.Max() - 1;
        for (int i = 0; i < 4; i++)
        {
            if (colors[i] == 0) colorSatisfied[i] = true;
            else if (activeBatteries[i] > 0)
            {
                colorSatisfied[i] = true;
                if (colors[i] > 1)
                {
                    optional--;
                    optionsSatisfied[i] = true;
                }
            }
        }
        if (optional < 1)
        {
            for (int i = 0; i < 4; i++) if (colors[i] > 1) colorSatisfied[i] = true;
        }
        if (!colorSatisfied.Contains(false))
        {
            for (int i = 0; i < 4; i++) if (optionsSatisfied[i]) colorsPossesed.Add(i);
            return true;
        }
        return false;
    }

    public override void AddToDiscard()
    {
        if (real)
        {
            RobotsModifiers rm = new RobotsModifiers();
            controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], rm));
        }
    }
}

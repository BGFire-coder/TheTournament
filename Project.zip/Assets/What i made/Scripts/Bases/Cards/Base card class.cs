using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Basecard : MonoBehaviour
{
    public int id;
    public int pile = 0;
    public int type;
    public EndTurn controller;
    public AnimationLibrary library;
    public GameObject[][] array;
    public GameObject carrier;
    public int mySide;
    public int otherSide;
    public int pickedIndex = -1;
    public GameObject picker;
    public List<string> supportedTriggers = new List<string>();
    public bool real = true;
    [TextArea(5, 15)]
    public string description;
    public GameObject attackAnimation;

    public virtual void Awake()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") return;
        transform.localScale = new Vector3(1.2f, 1.2f, 1);
        controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        library = GameObject.Find("Animation Library").GetComponent<AnimationLibrary>();
        carrier = controller.effectCarrier;
        array = controller.board;
        supportedTriggers.Add("Discard");
        picker = library.picker;
    }

    public virtual void Start()
    {
        otherSide = 1 - mySide;
    }

    public virtual IEnumerator OnMouseDown()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") yield break;
        controller.runningProcesses++;
        if (controller.runningProcesses == 1 && CheckIfPlayable() && controller.turn == mySide && GetTargets().Count > 0)
        {
            int inHand = controller.empty[mySide].GetComponent<Players>().hand.IndexOf(gameObject);
            if(pickedIndex == -1) yield return StartCoroutine(SpawnPickers());
            if (pickedIndex < 10) yield return StartCoroutine(Play(pickedIndex));
            else pickedIndex = -1;
            if (pile == 1)
            {
                ChangeResources();
                if (controller.mode == 1)
                {
                    CardPlayedEvent cardPlayed = new CardPlayedEvent() { IndexOnBoard = pickedIndex, indexInHand = inHand, cardType = 0 };
                    Communication.forSend.Add(cardPlayed);
                }
                OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
            }
        }
        controller.runningProcesses--;
    }

    public virtual bool CheckIfPlayable()
    {
        return true;
    }

    public virtual List<int> GetTargets()
    {
        return new List<int>();
    }

    public virtual void ChangeResources()
    {
        return;
    }

    public virtual IEnumerator Play(int index)
    {
        yield return null;
    }

    public virtual IEnumerator SpawnPickers()
    {
        pickedIndex = -1;
        List<GameObject> indexers = new List<GameObject>();
        foreach (int i in GetTargets())
        {
            indexers.Add(Instantiate(picker, PositionByIndex.GetPosition(mySide, i) + new Vector3(0, -0.375f, 0), new Quaternion()));
            indexers[indexers.Count - 1].GetComponent<IndexPicker>().reciever = this;
            indexers[indexers.Count - 1].GetComponent<IndexPicker>().index = i;
            indexers[indexers.Count - 1].transform.localScale = new Vector3(2.4f, 2.4f, 1);
        }
        yield return new WaitForSeconds(0.1f);
        IndexPicker empty = GameObject.Find("Empty Click").GetComponent<IndexPicker>();
        empty.reciever = this;
        empty.transform.position = new Vector3(0, 0, -2);
        yield return new WaitUntil(() => pickedIndex > -1);
        for (int i = indexers.Count - 1; i > -1; i--)
        {
            Destroy(indexers[i]);
            indexers.RemoveAt(i);
        }
        empty.transform.position = new Vector3(0, 0, 5);
        empty.reciever = null;
    }

    private void OnMouseEnter()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") return;
        if (pile == 0) transform.localScale = Vector3.one * 1.4f;
    }

    private void OnMouseExit()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") return;
        if (pile == 0) transform.localScale = Vector3.one * 1.2f;
    }

    public virtual IEnumerator Discard()
    {
        if (pile == 0)
        {
            AddToDiscard();
            controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
            OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
            yield return new WaitForSeconds(0.05f);
            Destroy(gameObject);
        }
        else
        {
            AddToDiscard();
            yield return null;
            controller.disposed.Remove(gameObject);
            Destroy(gameObject);
        }
    }

    public virtual void Hide()
    {
        GetComponent<SpriteRenderer>().enabled = false;
        foreach (SpriteRenderer sr in GetComponentsInChildren<SpriteRenderer>()) if (sr.gameObject.name != "Burning(Clone)") sr.enabled = false;
        foreach (TextMeshPro text in GetComponentsInChildren<TextMeshPro>()) text.enabled = false;
        if (!controller.disposed.Contains(gameObject)) controller.disposed.Add(gameObject);
    }

    public virtual void AddToDiscard()
    {
        if (real) controller.empty[mySide].GetComponent<Players>().discardPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][id - 100 * type], new PermanentModifiers()));
    }
}
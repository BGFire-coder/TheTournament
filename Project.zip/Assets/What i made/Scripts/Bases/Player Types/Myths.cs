using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Myths : Type
{
    public int corpses;
    EndTurn controller;

    private void Start()
    {
        controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        if(GetComponent<Players>().mySide == 0) Instantiate(controller.types[3], transform);
        
    }

    public IEnumerator Book()
    {
        GameObject book = Instantiate(controller.library.GetComponent<CardLibrary>().allCards[3][Deck.decks[GetComponent<Players>().mySide].specialCards[0]]);
        book.GetComponent<Mythsbook>().mySide = GetComponent<Players>().mySide;
        if (GetComponent<Players>().mySide == 1)
        {
            if(controller.mode == 0) yield return book.GetComponent<Mythsbook>().StartCoroutine(book.GetComponent<Mythsbook>().Play(GetComponent<Players>().ai.ChoiceMaking(1, new List<int>() { 0, 1, 2, 3, 4 })));
            else
            {
                yield return new WaitUntil(() => EventQueue.events.Count > 0);
                if (EventQueue.events[0].eventType == EventTypes.multichoiceMade)
                {
                    yield return book.GetComponent<Mythsbook>().StartCoroutine(book.GetComponent<Mythsbook>().Play(EventQueue.events[0].ConvertTo<MultichoiceEvent>().index));
                    EventQueue.events.RemoveAt(0);
                }
                else
                {
                    EnemyEvent error = new EnemyEvent();
                    error.eventType = EventTypes.error;
                    Communication.forSend.Add(error);
                }
            }
        }
        else
        {
            Mythsbook toPlay = book.GetComponent<Mythsbook>();
            yield return toPlay.StartCoroutine(toPlay.SpawnPickers());
            if (controller.mode == 1)
            {
                MultichoiceEvent choice = new MultichoiceEvent() { index = toPlay.pickedIndex, optionsCount = toPlay.GetTargets().Count };
                Communication.forSend.Add(choice);
            }
            yield return toPlay.StartCoroutine(toPlay.Play(toPlay.pickedIndex));
            
        }
    }

    public override IEnumerator FirstDraw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        yield return StartCoroutine(Draw(mySide, hand, drawPile));
        yield return StartCoroutine(Draw(mySide, hand, drawPile));
    }

    public override IEnumerator StartTurn(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        yield return StartCoroutine(Draw(mySide, hand, drawPile));
    }

    public override IEnumerator Draw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        int[] step = new int[4] { 2, 3, 6, 15 };
        int group = 0;
        int[] chances = new int[drawPile.Count];
        chances[0] = 1;
        for (int i = 1; i < drawPile.Count; i++)
        {
            int prevPrev;
            if (i - 2 > -1) prevPrev = chances[i - 2];
            else prevPrev = 0;
            chances[i] = chances[i - 1] * 2 + step[group] - prevPrev;
            if (drawPile.Count / 4 * (group + 1) == i && group < 3) group++;
        }
        List<int> indeces = new List<int>();
        for(int i = 0;  i < drawPile.Count; i++)
        {
            for(int j = 0; j < i; j++) indeces.Add(i);
        }
        yield return StartCoroutine(ChanceHandler.MultiChoice(indeces));
        (GameObject, PermanentModifiers) pair = drawPile[indeces[ChanceValue.value]];
        drawPile.Remove(pair);
        yield return StartCoroutine(Message.SendToAll(mySide, "Drawing", null));
        hand.Add(Instantiate(pair.Item1));
        hand[hand.Count - 1].GetComponent<Basecard>().mySide = mySide;
        Unit u;
        if (hand[hand.Count - 1].TryGetComponent(out u)) u.ApplyPermanents(pair.Item2);
        OrderHand.Order(hand, mySide);
    }
}

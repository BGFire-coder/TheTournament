using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Wilds : Type
{
    public int energy = 0;
    public int blood = 0;
    public int day = 0;
    Players enemy;
    GameObject altar;

    private void Start()
    {
        if (GetComponent<Players>().mySide == 0) Instantiate(GameObject.Find("EndTurnButton").GetComponent<EndTurn>().types[1], transform);
        enemy = GameObject.Find("EndTurnButton").GetComponent<EndTurn>().empty[1 - GetComponent<Players>().mySide].GetComponent<Players>();
        if(GetComponent<Players>().mySide == 0) altar = Instantiate(GameObject.Find("EndTurnButton").GetComponent<EndTurn>().altar, transform);
    }

    public override IEnumerator FirstDraw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        if(!Deck.decks[mySide].cards.Contains(12)) for (int i = 0; i < 4; i++) yield return StartCoroutine(Draw(mySide, hand, drawPile));
        else
        {
            (GameObject, PermanentModifiers) pair = drawPile.First(x => x.Item1.GetComponent<Basecard>().id == 212);
            drawPile.Remove(pair);
            yield return StartCoroutine(Message.SendToAll(mySide, "Drawing", null));
            hand.Add(Instantiate(pair.Item1));
            hand[hand.Count - 1].GetComponent<Basecard>().mySide = mySide;
            Unit u;
            if (hand[hand.Count - 1].TryGetComponent(out u)) u.ApplyPermanents(pair.Item2);
            OrderHand.Order(hand, mySide);
            for (int i = 0; i < 3; i++) yield return StartCoroutine(Draw(mySide, hand, drawPile));
        }
    }

    public override IEnumerator StartTurn(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        day = 1 - day;
        yield return StartCoroutine(Draw(mySide, hand, drawPile));
    }

    private void Update()
    {
        blood = 10 - enemy.hp;
    }
}
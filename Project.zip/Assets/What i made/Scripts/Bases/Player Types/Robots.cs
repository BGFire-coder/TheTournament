using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.XR;

public class Robots : Type
{
    public int[] colors = new int[4];
    public List<GameObject> batteries = new List<GameObject>();
    List<int> colorsEnabled;
    EndTurn controller;

    void Start()
    {
        colorsEnabled = new List<int>();
        for(int i = 0; i < 4; i++)
        {
            if(Deck.decks[GetComponent<Players>().mySide].specialCards[i] == 1) colorsEnabled.Add(i);
        }
        controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        if (GetComponent<Players>().mySide == 0) Instantiate(controller.types[2], transform);
        CombinationRecipes.Fill(controller.library.GetComponent<CardLibrary>());
    }

    public override IEnumerator Draw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        (GameObject, PermanentModifiers) pair = drawPile[0];
        drawPile.Remove(pair);
        yield return StartCoroutine(Message.SendToAll(mySide, "Drawing", null));
        hand.Add(Instantiate(pair.Item1));
        hand[hand.Count - 1].GetComponent<Basecard>().mySide = mySide;
        Unit u;
        if (hand[hand.Count - 1].TryGetComponent(out u)) u.ApplyPermanents(pair.Item2);
        OrderHand.OrderBatteries(hand, batteries, mySide);
    }

    public override IEnumerator FirstDraw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        for (int i = 0; i < 4; i++) yield return StartCoroutine(Draw(mySide, hand, drawPile));
        for (int i = 0; i < 2; i++) yield return StartCoroutine(DrawBattery(mySide, hand));
    }

    public IEnumerator DrawBattery(int mySide, List<GameObject> hand)
    {
        GameObject[] cards = controller.library.GetComponent<CardLibrary>().allCards[GetComponent<Players>().type - 1].ToArray();
        yield return StartCoroutine(ChanceHandler.MultiChoice(colorsEnabled));
        batteries.Add(Instantiate(cards[colorsEnabled[ChanceValue.value]]));
        batteries[batteries.Count - 1].GetComponent<Robotsspell>().mySide = mySide;
        OrderHand.OrderBatteries(hand, batteries, mySide);
        yield return StartCoroutine(Message.SendToAll(mySide, "DrawingBattery", null));
    }

    public override IEnumerator StartTurn(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        for (int i = 0; i < 4; i++)
        {
            if (colors[i] > 0)
            {
                colors[i]--;
                yield return StartCoroutine(Message.SendToSide(mySide, "BatteryExpired", i));
            }
        }
        yield return StartCoroutine(DrawBattery(mySide, hand));
        if(drawPile.Count > 0) yield return StartCoroutine(Draw(mySide, hand, drawPile));
        yield return StartCoroutine(TryCombine());
    }

    public IEnumerator TryCombine()
    {
        for(int i = 0; i < 4; i++)
        {
            if (controller.board[GetComponent<Players>().mySide][i] == gameObject) continue;
            for (int j = i + 1; j < 5; j++)
            {
                if (controller.board[GetComponent<Players>().mySide][j] == gameObject) continue;
                for (int optional = j + 1; optional < 6; optional++)
                {
                    if (controller.board[GetComponent<Players>().mySide][optional] == gameObject && optional < 5) continue;
                    if (optional < 5) yield return CombinationRecipes.CheckRecipes(new GameObject[3] { controller.board[GetComponent<Players>().mySide][i], controller.board[GetComponent<Players>().mySide][j], controller.board[GetComponent<Players>().mySide][optional] }, this);
                    else yield return CombinationRecipes.CheckRecipes(new GameObject[2] { controller.board[GetComponent<Players>().mySide][i], controller.board[GetComponent<Players>().mySide][j] }, this);
                }
            }
        }
    }

    public IEnumerator ExecuteRecipe(GameObject[] originals, GameObject combination)
    {
        GameObject test = Instantiate(combination);
        int[] indeces = new int[originals.Length];
        int side = GetComponent<Players>().mySide;
        for (int i = 0; i < indeces.Length; i++) indeces[i] = Array.IndexOf(controller.board[side], originals[i]);
        test.GetComponent<Robotsunit>().bottomLimit = Mathf.Min(indeces);
        test.GetComponent<Robotsunit>().topLimit = Mathf.Max(indeces);
        if (!test.GetComponent<Robotsunit>().CheckForTarget(originals))
        {
            Destroy(test);
            yield break;
        }
        foreach (GameObject go in originals)
        {
            controller.board[side][Array.IndexOf(controller.board[side], go)] = gameObject;
            yield return go.GetComponent<Robotsunit>().Destroy();
        }
        Robotsunit product = test.GetComponent<Robotsunit>();
        test.transform.position = PositionByIndex.GetPosition(side, 7);
        product.combined = true;
        product.real = false;
        product.mySide = side;
        product.pile = 1;
        if (side == 0)
        {
            product.pickedIndex = 10;
            while(product.pickedIndex > 9) yield return product.StartCoroutine(product.SpawnPickers());
            if (controller.mode == 1)
            {
                MultichoiceEvent choice = new MultichoiceEvent() { index = product.pickedIndex, optionsCount = product.GetTargets().Count };
                Communication.forSend.Add(choice);
            }
            yield return product.StartCoroutine(product.Play(product.pickedIndex));
        }
        else if (controller.mode == 0)
        {
            yield return StartCoroutine(ChanceHandler.MultiChoice(product.GetTargets()));
            int index = product.GetTargets()[ChanceValue.value];
            yield return product.StartCoroutine(product.Play(index));
        }
        else
        {
            yield return new WaitUntil(() => EventQueue.events.Count > 0);
            if (EventQueue.events[0].eventType == EventTypes.multichoiceMade)
            {
                MultichoiceEvent multichoice = EventQueue.events[0].ConvertTo<MultichoiceEvent>();
                EventQueue.events.RemoveAt(0);
                if (multichoice.optionsCount == product.GetTargets().Count) yield return product.StartCoroutine(product.Play(multichoice.index));
                else
                {
                    EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                    Communication.forSend.Add(error);
                }
            }
            else
            {
                EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                Communication.forSend.Add(error);
            }
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public abstract class Type : MonoBehaviour
{
    public abstract IEnumerator FirstDraw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile);
    public virtual IEnumerator Draw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        (GameObject, PermanentModifiers) pair = drawPile[0];
        drawPile.Remove(pair);
        yield return StartCoroutine(Message.SendToAll(mySide, "Drawing", null));
        hand.Add(Instantiate(pair.Item1));
        hand[hand.Count - 1].GetComponent<Basecard>().mySide = mySide;
        Unit u;
        if (hand[hand.Count - 1].TryGetComponent(out u)) u.ApplyPermanents(pair.Item2);
        OrderHand.Order(hand, mySide);
    }

    public abstract IEnumerator StartTurn(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile);
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class War : Type
{
    public int ammo = 0;

    private void Start()
    {
        if (GetComponent<Players>().mySide == 0) Instantiate(GameObject.Find("EndTurnButton").GetComponent<EndTurn>().types[0], transform);
    }

    public override IEnumerator FirstDraw(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        ammo = 7;
        for (int i = 0; i < 5; i++) yield return StartCoroutine(base.Draw(mySide, hand, drawPile));
    }

    public override IEnumerator StartTurn(int mySide, List<GameObject> hand, List<(GameObject, PermanentModifiers)> drawPile)
    {
        ammo = 7;
        for (int i = hand.Count - 1; i > -1; i--)
        {
            yield return hand[i].GetComponent<Basecard>().StartCoroutine("Discard");
        }
        yield return new WaitForSeconds(0.05f);
        for (int i = 0; i < 3; i++)
        {
            if(drawPile.Count > 0) yield return StartCoroutine(Draw(mySide, hand, drawPile));
            else
            {
                yield return StartCoroutine(ChanceHandler.Order(GetComponent<Players>().discardPile));
                drawPile.AddRange(GetComponent<Players>().discardPile);
                GetComponent<Players>().discardPile.Clear();
            }
        }
    }
}
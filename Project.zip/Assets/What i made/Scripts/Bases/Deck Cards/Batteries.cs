using System;
using System.Linq;
using UnityEngine;

public class Batteries : BaseDeckCard
{
    public override void Start()
    {
        transform.position = PositionByIndex.GetPositionInDeck(position);
        if (save.specialCards[card.id % 100] == 0) transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(0.6f, 0.6f, 0.6f, 1);
        else transform.Find("Background").GetComponent<SpriteRenderer>().color = Color.white;
    }

    public override void OnMouseDown()
    {
        if (save.specialCards[card.id % 100] == 1)
        {
            save.specialCards[card.id % 100] = 0;
            transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(0.6f, 0.6f, 0.6f, 1);
        }
        else
        {
            save.specialCards[card.id % 100] = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().color = Color.white;
        }
    }
}
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Books : BaseDeckCard
{
    static Books[] allBooks = new Books[6];
    public override void Start()
    {
        allBooks[position] = this;
        transform.position = PositionByIndex.GetPositionInDeck(position);
        if (save.specialCards[0] != card.id % 100) transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(0.6f, 0.6f, 0.6f, 1);
        else transform.Find("Background").GetComponent<SpriteRenderer>().color = Color.white;
    }

    public override void OnMouseDown()
    {
        if (save.specialCards[0] != position)
        {
            save.specialCards[0] = position;
            transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
            foreach (Books book in allBooks) if(book.position != position) book.transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(0.6f, 0.6f, 0.6f, 1);
        }
    }
}
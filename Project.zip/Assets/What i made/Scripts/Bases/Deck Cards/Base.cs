using System;
using System.Linq;
using TMPro;
using UnityEngine;

public class BaseDeckCard : MonoBehaviour
{
    public int position;
    public DeckSave save;
    public Basecard card;

    void Awake()
    {
        card = GetComponent<Basecard>();
        card.enabled = false;
    }
    public virtual void Start()
    {
        if (GetComponent<Battery>() != null)
        {
            Batteries b = gameObject.AddComponent<Batteries>();
            b.save = save;
            b.position = position;
            Destroy(this);
        }
        else if(GetComponent<Mythsbook>() != null)
        {
            Books b = gameObject.AddComponent<Books>();
            b.save = save;
            b.position = position;
            Destroy(this);
        }
        if (save.specialCards.Length == 4) position += 4;
        else if (save.specialCards.Length == 1) position += 2;
        transform.position = PositionByIndex.GetPositionInDeck(position);
        if(!save.cards.Contains(card.id % 100))
        {
            transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(0.6f, 0.6f, 0.6f, 1);
        }
    }

    public virtual void OnMouseDown()
    {
        if (save.cards.Contains(card.id % 100))
        {
            save.cards[Array.IndexOf(save.cards, card.id % 100)] = -1;
            transform.Find("Background").GetComponent<SpriteRenderer>().color = new Color(0.6f, 0.6f, 0.6f, 1);
        }
        else if(save.cards.Contains(-1))
        {
            save.cards[Array.IndexOf(save.cards, -1)] = card.id % 100;
            transform.Find("Background").GetComponent<SpriteRenderer>().color = Color.white;
        }
    }

    void OnMouseEnter()
    {
        GameObject.Find("Information").GetComponent<TextMeshPro>().text = GetComponent<Basecard>().description;
    }

    void OnMouseExit()
    {
        GameObject.Find("Information").GetComponent<TextMeshPro>().text = "";
    }
}
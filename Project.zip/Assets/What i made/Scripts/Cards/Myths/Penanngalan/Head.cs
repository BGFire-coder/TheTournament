using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Head : Mythsunit
{
    public override void Awake()
    {
        base.Awake();
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Kill");
        supportedTriggers.Add("Hit");
    }

    public IEnumerator Kill(KillData data)
    {
        if(data.killer == gameObject && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            List<GameObject> possTargets = array[otherSide].Where(x => !controller.empty.Contains(x) && System.Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Unit>().id == 407).ToList();
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int target = ChanceValue.value;
                GameObject buff = Instantiate(controller.effectCarrier, possTargets[target].transform);
                DmgBuff effect = buff.AddComponent<DmgBuff>();
                effect.power = 2;
                possTargets[target].GetComponent<Penanngalan>().statuses.Add(effect);
                yield return Message.SendToBoard(mySide, "Status", new StatusData(otherSide, System.Array.IndexOf(array[otherSide], possTargets[target]), true, buff));
            }
        }
    }

    public override IEnumerator UseAbility()
    {
        List<GameObject> possTargets = array[otherSide].Where(x => !controller.empty.Contains(x) && Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Unit>().id != 407).ToList();
        if (possTargets.Count > 0)
        {
            currentcharges = 0;
            yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
            int target = ChanceValue.value;
            target = Array.IndexOf(array[otherSide], possTargets[target]);
            array[otherSide][target].GetComponent<Unit>().currentHP = 0;
            array[otherSide][target].BroadcastMessage("Discard");
            array[otherSide][target] = Instantiate(controller.library.GetComponent<CardLibrary>().type4[7], PositionByIndex.GetPosition(otherSide, target), new Quaternion());
            array[otherSide][target].GetComponent<Penanngalan>().real = false;
            array[otherSide][target].GetComponent<Penanngalan>().pile = 1;
            array[otherSide][target].GetComponent<Penanngalan>().mySide = otherSide;
            array[otherSide][target].transform.localScale = new Vector3(1.2f, 1.2f, 1);
            switch (controller.empty[otherSide].GetComponent<Players>().type)
            {
                case 1:
                    {
                        WarDummy dummy = array[otherSide][target].AddComponent<WarDummy>();
                        dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                        dummy.pile = 1;
                        break;
                    }
                case 2:
                    {
                        WildsDummy dummy = array[otherSide][target].AddComponent<WildsDummy>();
                        dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                        dummy.pile = 1;
                        break;
                    }
                case 3:
                    {
                        RobotsDummy dummy = array[otherSide][target].AddComponent<RobotsDummy>();
                        dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                        dummy.pile = 1;
                        break;
                    }
                case 4:
                    {
                        MythsDummy dummy = array[otherSide][target].AddComponent<MythsDummy>();
                        dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                        dummy.pile = 1;
                        break;
                    }
            }
            array[otherSide][target].transform.localScale = new Vector3(1.2f, 1.2f, 1);
        }
        yield break;
    }

    public override IEnumerator OnTurnStart1()
    {
        if (array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Unit>().id == 702).ToList().Count < 1)
        {
            if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
            yield return null;
            GetComponent<SpriteRenderer>().enabled = false;
            foreach (SpriteRenderer sr in GetComponentsInChildren<SpriteRenderer>()) if (sr.gameObject.name != "Burning(Clone)") sr.enabled = false;
            yield return Message.SendToAll(mySide, "Kill", null);
            controller.disposed.Add(gameObject);
        }
        yield return StartCoroutine(base.OnTurnStart1());
    }
}
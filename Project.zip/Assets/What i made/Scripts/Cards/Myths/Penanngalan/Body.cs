using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class Body : Mythsunit
{
    public override void Awake()
    {
        base.Awake();
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Hit");
    }

    public override IEnumerator UseAbility()
    {
        if (array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Unit>().id == 701).ToList().Count == 1)
        {
            int index = Array.IndexOf(array[mySide], array[mySide].Where(x => !controller.empty.Contains(x) && x.GetComponent<Unit>().id == 701).ToArray()[0]);
            Destroy(array[mySide][index]);
            array[mySide][index] = controller.empty[mySide];
            GameObject newBody = Instantiate(controller.library.GetComponent<CardLibrary>().type4[7], PositionByIndex.GetPosition(mySide, Array.IndexOf(array[mySide], gameObject)), new Quaternion());
            array[mySide][Array.IndexOf(array[mySide], gameObject)] = newBody;
            newBody.GetComponent<Penanngalan>().mySide = mySide;
            newBody.GetComponent<Penanngalan>().pile = 1;
            newBody.transform.localScale = new Vector3(1.2f, 1.2f, 1);
            yield return null;
            Destroy(gameObject);
        }
        yield break;
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (currentHP > 0)
        {
            int defense = 0;
            int reduction = 0;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.AntiHeal)) reduction += e.power;
            if (atk.type != dmgTypes.damage)
            {
                if (atk.amount > reduction)
                {
                    currentHP += (atk.amount - reduction);
                    if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
                    Instantiate(heal, transform);
                    yield return Message.SendToSide(mySide, "Healed", new AttackData(atk.amount, atk.isCrit, gameObject, false, dmgTypes.heal));
                }
            }
            else if (defense < atk.amount)
            {
                currentHP -= (atk.amount - defense);
                if (atk.isCrit) Instantiate(crit, transform);
                else Instantiate(damage, transform);
                yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
            }
            if (currentHP < 1)
            {
                if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
                yield return null;
                GetComponent<SpriteRenderer>().enabled = false;
                foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
                {
                    controller.burn.Add(b);
                    b.transform.SetParent(null, true);
                }
                yield return null;
                if (controller.empty[mySide].GetComponent<Players>().type == 4) controller.empty[mySide].GetComponent<Myths>().corpses++;
                if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
                Instantiate(death, transform.position, new Quaternion());
                foreach (SpriteRenderer sr in GetComponentsInChildren<SpriteRenderer>()) sr.enabled = false;
                GetComponentInChildren<TextMeshPro>().enabled = false;
                yield return Message.SendToAll(mySide, "Kill", atk.attacker);
                id = 407;
                controller.disposed.Add(gameObject);
                List<GameObject> possTargets = array[otherSide].Where(x => !controller.empty.Contains(x) && Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Unit>().id != 407).ToList();
                if (possTargets.Count > 0 && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
                {
                    yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                    int target = ChanceValue.value;
                    GameObject buff = Instantiate(controller.effectCarrier, possTargets[target].transform);
                    DmgBuff effect = buff.AddComponent<DmgBuff>();
                    effect.power = 1;
                    possTargets[target].GetComponent<Penanngalan>().statuses.Add(effect);
                    yield return null;
                    possTargets.RemoveAt(target);
                    if (possTargets.Count > 0)
                    {
                        yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                        target = ChanceValue.value;
                        buff = Instantiate(controller.effectCarrier, possTargets[target].transform);
                        effect = buff.AddComponent<DmgBuff>();
                        effect.power = 1;
                        possTargets[target].GetComponent<Penanngalan>().statuses.Add(effect);
                        yield return Message.SendToBoard(mySide, "Status", new StatusData(otherSide, System.Array.IndexOf(array[otherSide], possTargets[target]), true, buff));
                        possTargets.RemoveAt(target);
                    }
                }
            }
        }
    }
}
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Penanngalan : Mythsunit
{
    public GameObject body;
    public GameObject head;
    Myths owner;

    public override void Awake()
    {
        base.Awake();
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Hit");
    }

    public override void Start()
    {
        base.Start();
        if (controller.empty[mySide].GetComponent<Players>().type == 4) owner = controller.empty[mySide].GetComponent<Myths>();
    }

    public override IEnumerator UseAbility()
    {
        yield return StartCoroutine(Split());
    }

    public override void Charge(int amount)
    {
        if(real) base.Charge(amount);
    }

    public override IEnumerator Attack()
    {
        if (statuses.Where(x => x.power == 1 && (x.effect == EffectNames.Freeze || x.effect == EffectNames.Stun)).ToList().Count == 0)
        {
            int multiattack = 1;
            foreach (Effect effect in statuses.Where(x => x.effect == EffectNames.Multiattack)) multiattack += effect.power;
            for (int i = 0; i < multiattack; i++)
            {
                int crit = 1;
                bool isCrit = false;
                yield return StartCoroutine(ChanceHandler.Chance(currentCrit));
                if (ChanceValue.yesNo)
                {
                    isCrit = true;
                    crit = 2;
                }
                GameObject attack = Instantiate(attackAnimation);
                int index = System.Array.IndexOf(array[mySide], gameObject);
                Attack anim = attack.GetComponent<Attack>();
                anim.target = index;
                anim.beggining = index;
                anim.side = mySide;
                yield return new WaitUntil(() => anim.finished);
                yield return StartCoroutine(TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                if (isCrit) yield return Message.SendToBoard(mySide, "Crit", new CritData(mySide, System.Array.IndexOf(array[mySide], gameObject), gameObject));
                yield return new WaitForSeconds(0.1f);
            }
            yield return new WaitForSeconds(0.3f);
        }
    }

    public override void Update()
    {
        base.Update();
        if (pile == 0 && controller.empty[mySide].GetComponent<Players>().type == 4) corpseCost = owner.corpses;
    }

    IEnumerator Split()
    {
        pickedIndex = -1;
        List<GameObject> indexers = new List<GameObject>();
        if (array[mySide].Where(x => x == controller.empty[mySide]).ToList().Count > 5)
        {
            currentcharges = 0;
            if (mySide == 0)
            {
                pickedIndex = 10;
                while(pickedIndex > 9) yield return SpawnPickers();
                if (controller.mode == 1)
                {
                    MultichoiceEvent choice = new MultichoiceEvent() { index = pickedIndex, optionsCount = GetTargets().Count };
                    Communication.forSend.Add(choice);
                }
            }
            else if (controller.mode == 0)
            {
                pickedIndex = controller.empty[1].GetComponent<Players>().ai.ChoiceMaking(1, GetTargets());
            }
            else
            {
                yield return new WaitUntil(() => EventQueue.events.Count > 0);
                if (EventQueue.events[0].eventType == EventTypes.multichoiceMade)
                {
                    MultichoiceEvent multichoice = EventQueue.events[0].ConvertTo<MultichoiceEvent>();
                    EventQueue.events.RemoveAt(0);
                    if (multichoice.optionsCount == GetTargets().Count) pickedIndex = multichoice.index;
                    else
                    {
                        EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                        Communication.forSend.Add(error);
                    }
                }
                else
                {
                    EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                    Communication.forSend.Add(error);
                }
            }
            array[mySide][pickedIndex] = Instantiate(head, PositionByIndex.GetPosition(mySide, pickedIndex), new Quaternion());
            array[mySide][pickedIndex].GetComponent<Head>().mySide = mySide;
            GameObject replacement = Instantiate(body, PositionByIndex.GetPosition(mySide, System.Array.IndexOf(array[mySide], gameObject)), new Quaternion());
            array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = replacement;
            replacement.GetComponent<Body>().mySide = mySide;
            List<GameObject> possTargets = array[otherSide].Where(x => !controller.empty.Contains(x) && System.Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Unit>().id != 407).ToList();
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int target = ChanceValue.value;
                target = System.Array.IndexOf(array[otherSide], possTargets[target]);
                array[otherSide][target].GetComponent<Unit>().currentHP = 0;
                array[otherSide][target].BroadcastMessage("Discard");
                array[otherSide][target] = Instantiate(controller.library.GetComponent<CardLibrary>().type4[7], PositionByIndex.GetPosition(otherSide, target), new Quaternion());
                array[otherSide][target].GetComponent<Penanngalan>().real = false;
                array[otherSide][target].GetComponent<Penanngalan>().pile = 1;
                array[otherSide][target].GetComponent<Penanngalan>().mySide = otherSide;
                switch (controller.empty[otherSide].GetComponent<Players>().type)
                {
                    case 1:
                        {
                            WarDummy dummy = array[otherSide][target].AddComponent<WarDummy>();
                            dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                            dummy.pile = 1;
                            break;
                        }
                    case 2:
                        {
                            WildsDummy dummy = array[otherSide][target].AddComponent<WildsDummy>();
                            dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                            dummy.pile = 1;
                            break;
                        }
                    case 3:
                        {
                            RobotsDummy dummy = array[otherSide][target].AddComponent<RobotsDummy>();
                            dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                            dummy.pile = 1;
                            break;
                        }
                    case 4:
                        {
                            MythsDummy dummy = array[otherSide][target].AddComponent<MythsDummy>();
                            dummy.realScript = array[otherSide][target].GetComponent<Penanngalan>();
                            dummy.pile = 1;
                            break;
                        }
                }
                array[otherSide][target].transform.localScale = new Vector3(1.2f, 1.2f, 1);
            }
        }
        Destroy(gameObject);
    }
}
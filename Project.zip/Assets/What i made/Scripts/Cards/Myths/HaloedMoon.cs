using System.Collections.Generic;
using System.Linq;
using System.Collections;
using UnityEngine;

public class HaloedMoon : Mythsspell
{
    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for (int i = 0; i < 5; i++)
        {
            if (array[mySide][i] != controller.empty[mySide] && array[mySide][i].GetComponent<Mythsunit>() != null && array[mySide][i].GetComponent<Mythsunit>().currentHP < array[mySide][i].GetComponent<Mythsunit>().maxHP && array[mySide][i].GetComponent<Mythsunit>().currentcharges > 0) positions.Add(i);
        }
        return positions;
    }

    public override IEnumerator Play(int index)
    {
        pile = 1;
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        Mythsunit target = array[mySide][index].GetComponent<Mythsunit>();
        yield return target.StartCoroutine(target.TakeDMG(new AttackData(30, false, gameObject, false, dmgTypes.heal)));
        target.currentcharges = 0;
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, 10, null));
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        Hide();
    }
}
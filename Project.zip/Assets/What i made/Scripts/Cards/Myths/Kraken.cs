using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class Kraken : Mythsunit
{
    public override void ChangeResources()
    {
        controller.empty[mySide].GetComponent<Myths>().corpses -= 3;
    }

    public override bool CheckIfPlayable()
    {
        return controller.empty[mySide].GetComponent<Myths>().corpses > 2;
    }

    public override IEnumerator UseAbility()
    {
        currentcharges = 0;
        int strength = 1;
        if (controller.empty[mySide].GetComponent<Myths>().corpses > 10) strength = 2;
        for (int i = 0; i < 5; i++)
        {
            if (i != 4 - pickedIndex)
            {
                GameObject target = array[otherSide][i];
                if (target == controller.empty[otherSide]) controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(strength, false, gameObject, true, dmgTypes.damage)));
                else yield return target.GetComponent<Unit>().StartCoroutine(target.GetComponent<Unit>().TakeDMG(new AttackData(strength, false, gameObject, false, dmgTypes.damage)));
            }
        }
    }
}
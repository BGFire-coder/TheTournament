using System.Collections;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Hydra : Mythsunit
{
    public GameObject dmgbuff;
    
    public override void Awake()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") return;
        base.Awake();
        dmgbuff = Instantiate(carrier, transform);
        dmgbuff.AddComponent<DmgBuff>();
        dmgbuff.GetComponent<DmgBuff>().power = 0;
        statuses.Add(dmgbuff.GetComponent<DmgBuff>());
    }

    public override IEnumerator UseAbility()
    {
        if (currentHP < maxHP)
        {
            currentcharges = 0;
            dmgbuff.GetComponent<DmgBuff>().power = maxHP - currentHP;
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, pickedIndex, true, dmgbuff));
        }
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (currentHP > 0)
        {
            int defense = 0;
            int reduction = 0;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.AntiHeal)) reduction += e.power;
            if (atk.type != dmgTypes.damage)
            {
                if (atk.amount > reduction)
                {
                    currentHP += (atk.amount - reduction);
                    if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
                    Instantiate(heal, transform);
                    yield return Message.SendToSide(mySide, "Healed", new AttackData(atk.amount, atk.isCrit, gameObject, false, dmgTypes.heal));
                }
            }
            else if (defense < atk.amount)
            {
                currentHP -= (atk.amount - defense);
                if (atk.isCrit) Instantiate(crit, transform);
                else Instantiate(damage, transform);
                yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
            }
            if (currentHP < 1)
            {
                foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
                {
                    controller.burn.Add(b);
                    b.transform.SetParent(null, true);
                }
                yield return null;
                if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0) controller.empty[mySide].GetComponent<Myths>().corpses++;
                else controller.empty[mySide].GetComponent<Myths>().corpses += 5;
                if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
                Instantiate(death, transform.position, new Quaternion());
                yield return Message.SendToAll(mySide, "Kill", new KillData(atk.attacker, mySide, System.Array.IndexOf(array[mySide], gameObject)));
                if (System.Array.IndexOf(array[mySide], gameObject) > -1) if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
                Hide();
            }
        }
    }

    public override IEnumerator OnTurnEndAA()
    {
        yield return base.OnTurnEndAA();
        dmgbuff.GetComponent<DmgBuff>().power = 0;
    }
}
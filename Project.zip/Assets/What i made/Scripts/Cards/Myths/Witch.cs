using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class Witch : Mythsunit
{
    public override IEnumerator UseAbility()
    {
        if (array[otherSide][4 - System.Array.IndexOf(array[mySide], gameObject)] == controller.empty[otherSide]) yield break;
        currentcharges = 0;
        GameObject target = array[otherSide][4 - System.Array.IndexOf(array[mySide], gameObject)];
        GameObject debuff = Instantiate(controller.effectCarrier);
        Poison instance = debuff.AddComponent<Poison>();
        instance.creator = gameObject;
        instance.target = target;
        instance.turns = 90;
        instance.index = new int[] { otherSide, 4 - System.Array.IndexOf(array[mySide], gameObject) };
        instance.controller = controller;
        debuff.transform.SetParent(target.transform, false);
        target.GetComponent<Unit>().statuses.Add(instance);
        yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, Array.IndexOf(array[otherSide], target), false, debuff));
    }
}
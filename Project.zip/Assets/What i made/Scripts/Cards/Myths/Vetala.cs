using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Vetala : Mythsunit
{

    public override IEnumerator UseAbility()
    {
        if(array[otherSide].Where(x => !controller.empty.Contains(x) && System.Array.IndexOf(array[otherSide], x) < 5 && !x.TryGetComponent(out Mythsbook m)).ToList().Count > 0)
        {
            currentcharges = 0;
            if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
            {
                int loop = 1;
                again:
                List<GameObject> possTargets = array[otherSide].Where(x => !controller.empty.Contains(x) && System.Array.IndexOf(array[otherSide], x) < 5 && !x.TryGetComponent(out Mythsbook m)).ToList();
                if (possTargets.Count > 0)
                {
                    yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                    int pick = ChanceValue.value;
                    yield return possTargets[pick].GetComponent<Unit>().StartCoroutine(possTargets[pick].GetComponent<Unit>().TakeDMG(new AttackData(30, false, gameObject, false, dmgTypes.damage)));
                    if (loop == 1)
                    {
                        loop = 2;
                        goto again;
                    }
                }
                yield return new WaitForSeconds(0.3f);
                yield return StartCoroutine(TakeDMG(new AttackData(30, false, gameObject, false, dmgTypes.damage)));
            }
        }
        
    }
}
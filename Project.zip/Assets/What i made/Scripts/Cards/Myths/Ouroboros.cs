using System.Collections;
using System.Linq;
using UnityEngine;

public class Ouroboros : Mythsunit
{
    public int healed;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Healed");
    }

    public override IEnumerator UseAbility()
    {
        currentcharges = 0;
        yield return StartCoroutine(ChanceHandler.Chance(currentCrit));
        bool crit = ChanceValue.yesNo;
        yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().TakeDMG(new AttackData(2 * ((crit) ? 2 : 1), crit, gameObject, false, dmgTypes.heal)));
    }

    public IEnumerator Healed(AttackData trigger)
    {
        healed += trigger.amount;
        if(healed > 4)
        {
            healed = 0;
            yield return new WaitForSeconds(0.2f);
            Charge(1);
        }
    }
}
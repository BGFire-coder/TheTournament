using System;
using System.Collections;
using System.Diagnostics;
using UnityEngine;

public class Ghost : Mythsunit
{
    public override IEnumerator OnTurnEndBA()
    {
        yield return base.OnTurnEndBA();
        if (controller.empty[mySide].GetComponent<Myths>().corpses > 14)
        {
            GameObject buff = Instantiate(carrier, transform);
            TimedDmgBuff effect = buff.AddComponent<TimedDmgBuff>();
            effect.power = 1;
            effect.turnsLeft = 1;
            statuses.Add(effect);
            yield return Message.SendToBoard(otherSide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], gameObject), true, buff));
        }
    }

    public override IEnumerator UseAbility()
    {
        currentcharges = 0;
        GameObject invinsibility = Instantiate(carrier, transform);
        Defence buff = invinsibility.AddComponent<Defence>();
        buff.power = 30;
        buff.turnsLeft = 1;
        statuses.Add(buff);
        yield return Message.SendToBoard(otherSide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], gameObject), true, invinsibility));
    }
}
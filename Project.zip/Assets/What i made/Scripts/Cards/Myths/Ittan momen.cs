using System.Collections;
using System.Linq;
using UnityEngine;

public class IttanMomen : Mythsunit
{
    public GameObject dmgbuff;
    public GameObject critbuff;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Crit");
    }

    public override IEnumerator UseAbility()
    {
        currentcharges = 0;
        critbuff = Instantiate(carrier, transform);
        critbuff.AddComponent<CritBuff>();
        critbuff.GetComponent<CritBuff>().power = 10;
        statuses.Add(critbuff.GetComponent<CritBuff>());
        yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, pickedIndex, true, critbuff));
    }

    public IEnumerator Crit(CritData data)
    {
        if (data.critter == gameObject && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            if (chargeRate < charges) chargeRate++;
            else
            {
                dmgbuff = Instantiate(carrier, transform);
                dmgbuff.AddComponent<DmgBuff>();
                dmgbuff.GetComponent<DmgBuff>().power = 1;
                statuses.Add(dmgbuff.GetComponent<DmgBuff>());
                yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, pickedIndex, true, dmgbuff));
            }
        }
    }
}
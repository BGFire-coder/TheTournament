using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Jottun : Mythsunit
{
    int freezes = 0;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Status");
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (atk.attacker.TryGetComponent<Unit>(out Unit u) && atk.interactive && atk.amount > 0 && atk.type == dmgTypes.damage && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            GameObject debuff = Instantiate(controller.effectCarrier, atk.attacker.transform);
            Frost instance = debuff.AddComponent<Frost>();
            instance.creator = gameObject;
            instance.target = atk.attacker;
            instance.turns = 2;
            instance.power = 1;
            freezes++;
            yield return StartCoroutine(Message.SendToSide(mySide, "Freeze", null));
            yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, Array.IndexOf(array[otherSide], atk.attacker), false, debuff));
        }
        yield return StartCoroutine(base.TakeDMG(atk));
    }

    public IEnumerator Status(StatusData data)
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0 && data.side == mySide && data.index == Array.IndexOf(array[mySide], gameObject) && !data.buff)
        {
            GameObject target = data.carrier.GetComponent<Effect>().creator;
            GameObject debuff = Instantiate(controller.effectCarrier, target.transform);
            Frost instance = debuff.AddComponent<Frost>();
            instance.creator = gameObject;
            instance.target = target;
            instance.turns = 2;
            instance.power = 1;
            freezes++;
            yield return StartCoroutine(Message.SendToSide(mySide, "Freeze", null));
            yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, Array.IndexOf(array[otherSide], target), false, debuff));
        }
    }

    public override IEnumerator UseAbility()
    {
        List<GameObject> possTargets = array[otherSide].Where(x => x != controller.empty[otherSide] && System.Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Unit>().currentATK > 0).ToList();
        if (possTargets.Count > 0)
        {
            currentcharges = 0;
            for(int i = 0; i < freezes; i++)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                GameObject target = possTargets[index];
                GameObject debuff = Instantiate(controller.effectCarrier, target.transform);
                DmgBuff instance = debuff.AddComponent<DmgBuff>();
                instance.creator = gameObject;
                instance.power = -1;
                target.GetComponent<Unit>().statuses.Add(instance);
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, index, false, debuff));
            }
        }
    }
}
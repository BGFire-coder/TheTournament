using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Frozen_tome : Mythsbook
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Freeze");
    }

    public override IEnumerator UseAbility()
    {
        int index = System.Array.IndexOf(array[mySide], gameObject);
        for(int i = 3;  i < 6; i++)
        {
            if(i - index > -1 && i - index < 5 && array[otherSide][i - index] != controller.empty[otherSide])
            {
                currentcharges = 0;
                GameObject target = array[otherSide][i - index];
                GameObject debuff = Instantiate(controller.effectCarrier, target.transform);
                Frost instance = debuff.AddComponent<Frost>();
                instance.creator = gameObject;
                instance.target = target;
                instance.turns = 2;
                instance.power = 1;
                yield return StartCoroutine(Message.SendToSide(mySide, "Freeze", null));
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, i - index, false, debuff));
            }
        }
        yield break;
    }

    public IEnumerator Freeze()
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            List<GameObject> possTargets = array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Mythsunit>().currentcharges < x.GetComponent<Mythsunit>().charges && x != gameObject).ToList();
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int target = ChanceValue.value;
                possTargets[target].GetComponent<Mythsunit>().Charge(2);
                yield return null;
            }
        }
    }
}
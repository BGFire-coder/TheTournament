using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Namtar : Mythsunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Status");
    }

    public IEnumerator Status(StatusData data)
    {
        yield return null;
        if(data.side == otherSide && array[otherSide][data.index] != controller.empty[otherSide])
        {
            Unit unit = array[otherSide][data.index].GetComponent<Unit>();
            if (unit != null && unit.statuses.Where(x => !x.buff).Count() > 2)
            {
                yield return unit.StartCoroutine(unit.TakeDMG(new AttackData(30, false, gameObject, false, dmgTypes.damage)));
            }
        }
    }

    public override IEnumerator UseAbility()
    {
        yield return null;
        
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            List<Effect> enemyStatuses = new List<Effect>();
            for (int i = 0; i < 5; i++)
            {
                if (array[otherSide][i].GetComponent<Unit>() != null)
                {
                    enemyStatuses.AddRange(array[otherSide][i].GetComponent<Unit>().statuses.Where(x => !x.buff));
                }
            }
            enemyStatuses.AddRange(controller.burn.Where(x => x.index[0] == otherSide));
            if (enemyStatuses.Count == 0) yield break;
            yield return StartCoroutine(ChanceHandler.MultiChoice(enemyStatuses));
            Effect status = enemyStatuses[ChanceValue.value];
            List<GameObject> possTargets = array[otherSide].Where(x => x != controller.empty[otherSide] && System.Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Mythsbook>() == null && x != status.transform.parent.gameObject).ToList();
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                GameObject target = possTargets[index];
                GameObject debuff = Instantiate(controller.effectCarrier, target.transform);
                debuff.AddComponent(status.GetType());
                Effect effect = debuff.GetComponent<Effect>();
                effect.effect = status.effect;
                effect.buff = false;
                effect.creator = gameObject;
                effect.permanent = status.permanent;
                effect.power = status.power;
                effect.index = status.index;
                effect.turns = status.turnsLeft + 1;
                effect.turnsLeft = status.turnsLeft + 1;
                effect.target = target;
                target.GetComponent<Unit>().statuses.Add(effect);
                status.transform.parent.GetComponent<Unit>().statuses.Remove(status);
                Destroy(status.gameObject);
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, index, false, debuff));
                currentcharges = 0;
            }
        }
    }
}
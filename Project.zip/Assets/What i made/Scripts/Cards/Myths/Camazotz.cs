using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Camazotz : Mythsunit
{
    List<GameObject> burn = new List<GameObject>();

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Status");
        supportedTriggers.Add("Kill");
        supportedTriggers.Add("OnTurnStart2");
    }

    public override IEnumerator UseAbility()
    {
        if (burn.Count > 0)
        {
            currentcharges = 0;
            foreach (GameObject go in burn) go.GetComponent<Burn>().turnsLeft += 2;
        }
        yield return null;
    }

    public IEnumerator OnTurnStart2()
    {
        yield return null;
        for (int i = burn.Count - 1; i > -1; i--) if (burn[i] == null) burn.RemoveAt(i);
    }

    public IEnumerator Status(StatusData data)
    {
        yield return null;
        if (data.side == otherSide && data.carrier.GetComponent<Effect>().effect == EffectNames.Burn)
        {
            burn.Add(data.carrier);
        }
    }

    public IEnumerator Kill(KillData data)
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0 && data.side == otherSide)
        {
            List<int> possTargets = new List<int>() { 0, 1, 2, 3, 4 };
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                GameObject target = array[otherSide][index];
                GameObject debuff = Instantiate(controller.effectCarrier);
                Burn instance = debuff.AddComponent<Burn>();
                instance.creator = gameObject;
                instance.target = target;
                instance.turns = 2;
                instance.index = new int[] { otherSide, index };
                instance.controller = controller;
                if (target != controller.empty[otherSide])
                {
                    debuff.transform.SetParent(target.transform, false);
                    target.GetComponent<Unit>().statuses.Add(instance);
                }
                else
                {
                    debuff.transform.localScale = Vector3.one * 1.2f;
                    controller.burn.Add(instance);
                    debuff.transform.position = target.transform.position;
                }
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, index, false, debuff));
            }
        }
    }
}
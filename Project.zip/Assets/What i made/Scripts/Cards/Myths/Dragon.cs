using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class Dragon : Mythsunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Ability");
    }

    public IEnumerator Ability(int index)
    {
        yield return null;
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0 && (Array.IndexOf(array[mySide], gameObject) - index == 1 || Array.IndexOf(array[mySide], gameObject) - index == -1))
        {
            GameObject target = array[otherSide][4- index];
            GameObject debuff = Instantiate(controller.effectCarrier);
            Burn instance = debuff.AddComponent<Burn>();
            instance.creator = gameObject;
            instance.target = target;
            instance.turns = 2;
            instance.index = new int[] { otherSide, 4 - index };
            instance.controller = controller;
            if (target != controller.empty[otherSide])
            {
                debuff.transform.SetParent(target.transform, false);
                target.GetComponent<Unit>().statuses.Add(instance);
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, 4- index, false, debuff));
            }
            else
            {
                debuff.transform.localScale = Vector3.one * 1.2f;
                controller.burn.Add(instance);
                debuff.transform.position = target.transform.position;
            }
        }
    }

    public override IEnumerator UseAbility()
    {
        currentcharges = 0;
        GameObject target = array[otherSide][4 - Array.IndexOf(array[mySide], gameObject)];
        GameObject debuff = Instantiate(controller.effectCarrier);
        Burn instance = debuff.AddComponent<Burn>();
        instance.creator = gameObject;
        instance.target = target;
        instance.turns = 6;
        instance.index = new int[]{ otherSide, 4 - Array.IndexOf(array[mySide], gameObject) };
        instance.controller = controller;
        if (target != controller.empty[otherSide])
        {
            debuff.transform.SetParent(target.transform, false);
            target.GetComponent<Unit>().statuses.Add(instance);
            yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, Array.IndexOf(array[otherSide], target), false, debuff));
        }
        else
        {
            debuff.transform.localScale = Vector3.one * 1.2f;
            controller.burn.Add(instance);
            debuff.transform.position = target.transform.position;
        }
        yield break;
    }
}
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Nuckelavee : Mythsunit
{
    List<GameObject> poisons = new List<GameObject>();

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Status");
        supportedTriggers.Add("OnTurnStart2");
    }

    public override IEnumerator UseAbility()
    {
        if(poisons.Count > 0)
        {
            currentcharges = 0;
            yield return StartCoroutine(ChanceHandler.MultiChoice(poisons));
            int index = ChanceValue.value;
            poisons[index].GetComponent<Poison>().turnsLeft = 90;
            poisons.RemoveAt(index);
        }
        yield return null;
    }

    public IEnumerator OnTurnStart2()
    {
        yield return null;
        for (int i = poisons.Count - 1; i > -1; i--) if (poisons[i] == null) poisons.RemoveAt(i);
    }

    public IEnumerator Status(StatusData data)
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0 && data.side == otherSide && !data.buff && data.carrier.GetComponent<Effect>().effect != EffectNames.Poison)
        {
            List<GameObject> possTargets = array[otherSide].Where(x => x != controller.empty[otherSide] && System.Array.IndexOf(array[otherSide], x) < 5 && x.GetComponent<Mythsbook>() == null).ToList();
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                GameObject target = possTargets[index];
                GameObject debuff = Instantiate(controller.effectCarrier, target.transform);
                Poison instance = debuff.AddComponent<Poison>();
                instance.creator = gameObject;
                instance.target = target;
                instance.turns = 2;
                instance.index = new int[] { otherSide, index };
                instance.controller = controller;
                target.GetComponent<Unit>().statuses.Add(instance);
                poisons.Add(debuff);
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, index, false, debuff));
            }
        }
    }
}
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MimiSpirit : Mythsunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        MimiBuff buff = Instantiate(carrier, transform).AddComponent<MimiBuff>();
        buff.controller = controller;
        buff.effect = EffectNames.OtherSpecific;
        buff.source = controller.empty[mySide].GetComponent<Myths>();
        statuses.Add(buff);
    }

    public override IEnumerator UseAbility()
    {
        yield return null;
        if(array[mySide].Where(x => x != controller.empty[mySide] && x != gameObject && x.GetComponent<Mythsbook>() == null).ToList().Count > 0)
        {
            currentcharges = 0;
            List<GameObject> possTargets = array[mySide].Where(x => x != controller.empty[mySide] && x != gameObject && x.GetComponent<Mythsbook>() == null).ToList();
            yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
            int index = ChanceValue.value;
            GameObject target = array[mySide][index];
            MimiBuff buff = Instantiate(carrier, target.transform).AddComponent<MimiBuff>();
            buff.controller = controller;
            buff.effect = EffectNames.OtherSpecific;
            buff.source = controller.empty[mySide].GetComponent<Myths>();
            target.GetComponent<Mythsunit>().statuses.Add(buff);
            buff.index = new int[2] { mySide, index };
        }
        
    }
}
using System.Collections;
using System.Linq;
using UnityEngine;

public class Uktena : Mythsunit
{
    int mode = 0;
    public Sprite[] sprites = new Sprite[2];

    public override IEnumerator UseAbility()
    {
        yield return null;
        currentcharges = 0;
        mode = 1 - mode;
        GetComponent<SpriteRenderer>().sprite = sprites[mode];
    }

    public IEnumerator Status(StatusData data)
    {
        if(mode == 0 && data.side == otherSide)
        {
            if(statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
            {
                yield return array[otherSide][data.index].GetComponent<Unit>().StartCoroutine(array[otherSide][data.index].GetComponent<Unit>().TakeDMG(new AttackData(currentATK, false, gameObject, false, dmgTypes.damage)));
            }
        }
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield return base.OnTurnEndBA();
        if(mode == 1 && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            foreach(GameObject go in array[mySide].Where(go => go != controller.empty[mySide]))
            {
                GameObject buff = Instantiate(carrier, go.transform);
                TimedDmgBuff dmg = buff.AddComponent<TimedDmgBuff>();
                dmg.power = 1;
                dmg.turnsLeft = dmg.turns = 1;
                dmg.target = go;
                dmg.creator = gameObject;
                go.GetComponent<Unit>().statuses.Add(dmg);
            }
        }
    }
}
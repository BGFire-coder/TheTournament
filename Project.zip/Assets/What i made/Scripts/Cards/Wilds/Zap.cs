using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Zap : Wildsspell
{
    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for (int i = 0; i < 5; i++)
        {
            if (array[otherSide][i].GetComponent<Mythsbook>() == null) positions.Add(i);
        }
        return positions;
    }

    public override IEnumerator Play(int index)
    {
        pile = 1;
        if (array[otherSide][index].GetComponent<Unit>() != null) yield return array[otherSide][index].GetComponent<Unit>().StartCoroutine(array[otherSide][index].GetComponent<Unit>().TakeDMG(new AttackData(3, false, gameObject, false, dmgTypes.damage)));
        else yield return controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(3, false, gameObject, false, dmgTypes.damage)));
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, index, null));
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        Hide();
    }
}
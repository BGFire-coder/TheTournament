using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Wolfpack : Wildsunit
{
    public override bool CheckIfPlayable()
    {
        return array[mySide].Where(x => x != controller.empty[mySide]).ToList().Count == 0 && base.CheckIfPlayable();
    }

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        for (int i = 0; i < 5; i++)
        {
            if (i != index)
            {
                array[mySide][i] = Instantiate(controller.library.GetComponent<CardLibrary>().help[3], PositionByIndex.GetPosition(mySide, i), new Quaternion());
                array[mySide][i].GetComponent<Wolf>().mySide = mySide;
                array[mySide][i].GetComponent<Wolf>().pile = 1;
                array[mySide][i].GetComponent<Wolf>().real = false;
                array[mySide][i].transform.localScale = new Vector3(1.2f, 1.2f, 1);
            }
        }
    }
}
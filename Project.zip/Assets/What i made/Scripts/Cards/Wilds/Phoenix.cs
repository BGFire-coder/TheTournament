using System;
using System.Collections;
using System.Linq;
using TMPro;
using UnityEngine;

public class Phoenix : Wildsunit
{
    public GameObject empty;
    GameObject ocupied;
    int turnsLeft;

    public IEnumerator OnTurnStart2()
    {
        turnsLeft--;
        if(turnsLeft == 0 && Array.IndexOf(array[mySide], ocupied) != -1)
        {
            int index = Array.IndexOf(array[mySide], ocupied);
            array[mySide][index] = gameObject;
            currentHP = maxHP;
            Destroy(ocupied);

            foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == index))
            {
                b.transform.SetParent(transform, true);
                statuses.Add(b);
            }
            foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
            GetComponent<SpriteRenderer>().enabled = true;
            foreach (SpriteRenderer sr in GetComponentsInChildren<SpriteRenderer>()) if (sr.gameObject.name != "Burning(Clone)") sr.enabled = true;
            foreach (TextMeshPro text in GetComponentsInChildren<TextMeshPro>()) text.enabled = true;
        }
        yield return null;
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (currentHP > 0)
        {
            int defense = 0;
            int reduction = 0;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.AntiHeal)) reduction += e.power;
            if (atk.type != dmgTypes.damage)
            {
                if (atk.amount > reduction)
                {
                    currentHP += (atk.amount - reduction);
                    if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
                    Instantiate(heal, transform);
                    yield return Message.SendToSide(mySide, "Healed", new AttackData(atk.amount, atk.isCrit, gameObject, false, dmgTypes.heal));
                }
            }
            else if (defense < atk.amount)
            {
                currentHP -= (atk.amount - defense);
                if (atk.isCrit) Instantiate(crit, transform);
                else Instantiate(damage, transform);
                yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
            }
            if (currentHP < 1)
            {
                yield return Message.SendToAll(mySide, "Kill", new KillData(atk.attacker, mySide, Array.IndexOf(array[mySide], gameObject)));
                foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
                {
                    controller.burn.Add(b);
                    b.transform.SetParent(null, true);
                }
                yield return null;
                if (controller.empty[mySide].GetComponent<Players>().type == 4) controller.empty[mySide].GetComponent<Myths>().corpses++;
                if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
                if (upgrade == 0) Instantiate(death, transform.position, new Quaternion());
                else Instantiate(upgradeDeath[upgrade - 1], transform.position, new Quaternion());
                if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
                {
                    GetComponent<SpriteRenderer>().enabled = false;
                    foreach (SpriteRenderer sr in GetComponentsInChildren<SpriteRenderer>()) if (sr.gameObject.name != "Burning(Clone)") sr.enabled = false;
                    foreach (TextMeshPro text in GetComponentsInChildren<TextMeshPro>()) text.enabled = false;
                    ocupied = Instantiate(empty);
                    array[mySide][Array.IndexOf(array[mySide], gameObject)] = ocupied;
                    ocupied.GetComponent<Empty>().owner = gameObject;
                    turnsLeft = 2;
                    currentHP = 1;
                }
                else
                {
                    Hide();
                    array[mySide][Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
                }
            }
        }
    }
}
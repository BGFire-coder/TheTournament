using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Wolf : Wildsunit
{
    public override void Awake()
    {
        base.Awake();
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Kill");
        supportedTriggers.Add("Hit");
    }

    public IEnumerator Kill(KillData data)
    {
        if (data.killer == gameObject && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            GameObject buff = Instantiate(controller.effectCarrier, transform);
            CritBuff effect = buff.AddComponent<CritBuff>();
            effect.power = 10;
            statuses.Add(effect);
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, System.Array.IndexOf(array[mySide], gameObject), true, buff));
        }
    }
}
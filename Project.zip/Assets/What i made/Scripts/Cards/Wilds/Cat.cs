using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.XR;
using System;

public class Cat : Wildsunit
{
    public override IEnumerator TakeDMG(AttackData atk)
    {
        yield return StartCoroutine(base.TakeDMG(atk));
        if (currentHP < 1)
        {
            List<GameObject> possTargets = array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Wildsunit>().upgrade > 0 && x != gameObject).ToList();
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                GameObject carrier = Instantiate(controller.effectCarrier, possTargets[index].transform);
                HP_buff buff = carrier.AddComponent<HP_buff>();
                buff.power = 2;
                buff.permanent = true;
                possTargets[index].GetComponent<Wildsunit>().statuses.Add(buff);
                yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], possTargets[index]), true, carrier));
                yield return possTargets[index].GetComponent<Wildsunit>().StartCoroutine(possTargets[index].GetComponent<Wildsunit>().TakeDMG(new AttackData(2, false, gameObject, false, dmgTypes.heal)));
            }
            else
            {
                possTargets = array[mySide].Where(x => x != controller.empty[mySide] && x != gameObject).ToList();
                if(possTargets.Count > 0)
                {
                    yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                    int index = ChanceValue.value;
                    yield return possTargets[index].GetComponent<Wildsunit>().StartCoroutine(possTargets[index].GetComponent<Wildsunit>().Upgrade(0));
                }
            }
        }
    }
}
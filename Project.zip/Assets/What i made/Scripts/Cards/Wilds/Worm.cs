using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Worm : Wildsunit
{
    public override IEnumerator OnTurnEndBA()
    {
        yield return StartCoroutine(base.OnTurnEndBA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            GameObject target = array[otherSide].LastOrDefault(x => !controller.empty.Contains(x) && x.GetComponent<Unit>().currentHP <= GetComponent<Unit>().currentATK && System.Array.IndexOf(array[otherSide], x) < 5 && array[mySide][4 - System.Array.IndexOf(array[otherSide], x)] == controller.empty[mySide] && x.GetComponent<Mythsbook>() == null);
            if (target != null)
            {
                int index = 4 - System.Array.IndexOf(array[otherSide], target);
                int old = System.Array.IndexOf(array[mySide], gameObject);
                array[mySide][index] = gameObject;
                array[mySide][old] = controller.empty[mySide];
                transform.position = new Vector3(target.transform.position.x, transform.position.y, 0);
            }
        yield return new WaitForSeconds(0.3f);
        }
    }
}
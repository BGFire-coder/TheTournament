using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Claws : Wildsspell
{
    public override IEnumerator Play(int index)
    {
        pile = 1;
        controller.activeEffects.Add(this);
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, 10, null));
        transform.position = new Vector3(0, 10, 0);
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
    }

    public IEnumerator OnTurnEndBA()
    {
        for(int i = 0; i < 5; i++)
        {
            if(array[mySide][i].GetComponent<Wildsunit>() != null) array[mySide][i].GetComponent<Wildsunit>().claws = true;
        }
        yield return null;
    }

    public IEnumerator OnTurnEndAA()
    {
        for (int i = 0; i < 5; i++)
        {
            if (array[mySide][i].GetComponent<Wildsunit>() != null) array[mySide][i].GetComponent<Wildsunit>().claws = false;
        }
        yield return null;
        controller.activeEffects.Remove(this);
        AddToDiscard();
        Destroy(gameObject);
    }

    public override List<int> GetTargets()
    {
        return new List<int> { 0 };
    }
}
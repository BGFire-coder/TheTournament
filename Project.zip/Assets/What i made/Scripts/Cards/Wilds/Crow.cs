using System.Collections;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Crow : Wildsunit
{
    public int killed = 0;

    public override void Awake()
    {
        supportedTriggers.Add("Kill");
        base.Awake();
    }

    public IEnumerator Kill(KillData data)
    {
        if (data.side != mySide)
        {
            killed++;
            if (array[mySide].Where(x => x == controller.empty[mySide] && System.Array.IndexOf(array[mySide], x) < 5).ToList().Count > 0 && (killed > 2 || (upgrade > 0 && killed > 1)))
            {
                if(mySide == 0)
                {
                    pickedIndex = 10;
                    while (pickedIndex > 9) yield return SpawnPickers();
                    yield return StartCoroutine(Play(pickedIndex));
                    if(controller.mode == 1)
                    {
                        MultichoiceEvent choice = new MultichoiceEvent() { index = pickedIndex, optionsCount = GetTargets().Count};
                        Communication.forSend.Add(choice);
                    }
                    OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
                }
                else if(controller.mode == 0)
                {
                    yield return StartCoroutine(Play(controller.empty[1].GetComponent<Players>().ai.ChoiceMaking(1, GetTargets())));
                }
                else
                {
                    yield return new WaitUntil(() => EventQueue.events.Count > 0);
                    if (EventQueue.events[0].eventType == EventTypes.multichoiceMade)
                    {
                        MultichoiceEvent multichoice = EventQueue.events[0].ConvertTo<MultichoiceEvent>();
                        EventQueue.events.RemoveAt(0);
                        if(multichoice.optionsCount == GetTargets().Count) yield return StartCoroutine(Play(multichoice.index));
                        else
                        {
                            EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                            Communication.forSend.Add(error);
                        }
                    }
                    else
                    {
                        EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                        Communication.forSend.Add(error);
                    }
                }
            }
        }
        yield return null;
    }

    public override IEnumerator Play(int index)
    {
        supportedTriggers.Remove("Kill");
        yield return base.Play(index);
    }
}
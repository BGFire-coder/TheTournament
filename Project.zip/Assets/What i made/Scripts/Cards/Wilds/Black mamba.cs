using System.Collections;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Black_mamba : Wildsunit
{
    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (atk.attacker.TryGetComponent<Unit>(out Unit u) && atk.attacker.GetComponent<Unit>().currentHP <= currentATK && atk.interactive && atk.amount > 0 && atk.type == dmgTypes.damage && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            yield return atk.attacker.GetComponent<Unit>().StartCoroutine(atk.attacker.GetComponent<Unit>().TakeDMG(new AttackData(currentATK, false, gameObject, false, dmgTypes.damage)));
            if (atk.attacker.GetComponent<Unit>().currentHP > 0) yield return StartCoroutine(base.TakeDMG(atk));
            yield return new WaitForSeconds(0.2f);
        }
        else yield return StartCoroutine(base.TakeDMG(atk));
    }
}
using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Mantis : Wildsunit
{
    GameObject buff;
    DmgBuff dmgBuff;
    CritBuff critBuff;

    public override void Awake()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") return;
        base.Awake();
        buff = Instantiate(controller.effectCarrier, transform);
        buff.AddComponent<DmgBuff>();
        statuses.Add(buff.GetComponent<DmgBuff>());
        dmgBuff = buff.GetComponent<DmgBuff>();
        dmgBuff.power = 0;
        buff = Instantiate(controller.effectCarrier, transform);
        buff.AddComponent<CritBuff>();
        statuses.Add(buff.GetComponent<CritBuff>());
        critBuff = buff.GetComponent<CritBuff>();
        critBuff.power = 0;
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield return StartCoroutine(base.OnTurnEndBA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            
            foreach(GameObject go in array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Wildsunit>() != null && x.GetComponent<Wildsunit>().upgrade > 0 && x != gameObject))
            {
                go.GetComponent<Wildsunit>().RemoveUpgrade();
                dmgBuff.power += 1;
                critBuff.power += 3;
            }
            yield return new WaitForSeconds(0.3f);
        }
    }
}
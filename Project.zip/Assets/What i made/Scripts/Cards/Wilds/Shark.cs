using System.Collections;
using UnityEngine;

public class Shark : Wildsunit
{
    public override IEnumerator Upgrade()
    {
        yield return null;
        if (controller.empty[mySide].GetComponent<Wilds>().day == 0)
        {
            upgrade = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = day;
            baseATK++;
            maxHP++;
            currentHP++;
            energyCost++;
        }
        else
        {
            upgrade = 2;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = night;
            gameObject.BroadcastMessage("Upgraded");
            if (bloodCost > 0) bloodCost--;
            if (energyCost > 0) energyCost--;
            maxHP--;
            currentHP--;
        }
        yield return Message.SendToAllOnASide(mySide, "Upgraded", null);
    }

    public override IEnumerator Upgrade(int cycle)
    {
        yield return null;
        if (cycle == 0)
        {
            upgrade = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = day;
            baseATK++;
            maxHP++;
            currentHP++;
            energyCost++;
        }
        else
        {
            upgrade = 2;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = night;
            gameObject.BroadcastMessage("Upgraded");
            if (bloodCost > 0) bloodCost--;
            if (energyCost > 0) energyCost--;
            maxHP--;
            currentHP--;
        }
        yield return Message.SendToAllOnASide(mySide, "Upgraded", null);
    }

    public override void RemoveUpgrade()
    {
        if (upgrade == 1)
        {
            maxHP--;
            baseATK--;
            if (currentHP > 1) currentHP--;
        }
        else
        {
            maxHP++;
            currentHP++;
        }
        upgrade = 0;
        transform.Find("Background").GetComponent<SpriteRenderer>().sprite = normal;
        gameObject.BroadcastMessage("UpgradeRemoved");
    }

    public override void ApplyPermanents(PermanentModifiers permanent)
    {
        WildsModifiers modifiers = (WildsModifiers)permanent;
        if (modifiers.HPmodifier != 0)
        {
            statuses.Add(new HP_buff());
            statuses[statuses.Count - 1].power = modifiers.HPmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.ATKmodifier != 0)
        {
            statuses.Add(new DmgBuff());
            statuses[statuses.Count - 1].power = modifiers.ATKmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.Critmodifier != 0)
        {
            statuses.Add(new CritBuff());
            statuses[statuses.Count - 1].power = modifiers.Critmodifier;
            statuses[statuses.Count - 1].permanent = true;
        }
        if (modifiers.upgraded == 1)
        {
            upgrade = 1;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = day;
            baseATK++;
            maxHP++;
            currentHP++;
            energyCost++;
        }
        else if (modifiers.upgraded == 2)
        {
            upgrade = 2;
            transform.Find("Background").GetComponent<SpriteRenderer>().sprite = night;
            if (bloodCost > 0) bloodCost--;
            if (energyCost > 0) energyCost--;
            maxHP--;
            currentHP--;
        }
    }
}
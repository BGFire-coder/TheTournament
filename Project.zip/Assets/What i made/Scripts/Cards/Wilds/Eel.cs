using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Eel : Wildsunit
{
    public override IEnumerator OnTurnEndAA()
    {
        yield return StartCoroutine(base.OnTurnEndAA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            int loop = 1;
            againIfUpgraded:
            List<GameObject> possTargets = array[otherSide].Where(x => !controller.empty.Contains(x) && System.Array.IndexOf(array[otherSide], x) < 5 && !x.TryGetComponent<Mythsbook>(out Mythsbook m)).ToList();
            if (possTargets.Count > 0)
            {
                bool isCrit = false;
                int crit = 1;
                yield return StartCoroutine(ChanceHandler.Chance(currentCrit));
                if (ChanceValue.yesNo)
                {
                    isCrit = true;
                    crit = 2;
                }
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int pick = ChanceValue.value;
                yield return possTargets[pick].GetComponent<Unit>().StartCoroutine(possTargets[pick].GetComponent<Unit>().TakeDMG(new AttackData(1 * crit, isCrit, gameObject, false, dmgTypes.damage)));
                if (GetComponent<Wildsunit>().upgrade > 0 && loop == 1)
                {
                    loop = 2;
                    goto againIfUpgraded;
                }
            }
            yield return new WaitForSeconds(0.3f);
        }
    }
}
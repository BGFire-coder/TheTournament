using System.Collections;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Porcupine : Wildsunit
{
    public override IEnumerator TakeDMG(AttackData atk)
    {
        yield return StartCoroutine(base.TakeDMG(atk));
        if (currentHP < 0) yield return controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(-currentHP, false, gameObject, false, dmgTypes.damage)));
    }
}
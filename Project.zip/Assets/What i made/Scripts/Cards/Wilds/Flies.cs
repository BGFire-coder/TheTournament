using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Flies : Wildsunit
{
    public override void Awake()
    {
        supportedTriggers.Add("Kill");
        base.Awake();
    }

    public IEnumerator Kill(KillData data)
    {
        if (data.side == mySide && array[mySide][data.index].GetComponent<Unit>().currentHP < 1)
        {
            yield return StartCoroutine(Play(data.index));
            OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        }
        yield return null;
    }

    public override bool CheckIfPlayable()
    {
        return false;
    }

    public override IEnumerator Play(int index)
    {
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        transform.position = PositionByIndex.GetPosition(mySide, index);
        transform.localScale = new Vector3(1.2f, 1.2f, 1);
        controller.board[mySide][index] = gameObject;
        if (type != 4) Destroy(GetComponent<BoxCollider2D>());
        pile = 1;
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, index, new int[0]));
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == index))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
        }
        foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn)) controller.burn.Remove(b);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Hit");
        supportedTriggers.Remove("Kill");
    }
}
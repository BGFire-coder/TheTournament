using System.Collections;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Tyrannosaurus : Wildsunit
{
    public override void Awake()
    {
        base.Awake();
        supportedTriggers.Add("Upgraded");
    }

    public IEnumerator Upgraded()
    {
        yield return null;
        if ((bloodCost > 3 && upgrade < 2) || (bloodCost > 2 && upgrade == 2)) bloodCost--;
    }
}
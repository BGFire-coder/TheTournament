using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Spider : Wildsunit
{
    public GameObject web;
    public GameObject[] snared = new GameObject[5];

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Played");
    }

    public override IEnumerator OnTurnEndAA()
    {
        yield return StartCoroutine(base.OnTurnEndAA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            List<int> possTargets = new List<int>();
            for (int i = 0; i < 5; i++)
            {
                if (array[otherSide][i] == controller.empty[otherSide] && snared[i] == null) possTargets.Add(i);
            }
            if (possTargets.Count > 0)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                snared[possTargets[index]] = Instantiate(web, PositionByIndex.GetPosition(otherSide, possTargets[index]) - new Vector3(0, 0.375f, 0), new Quaternion());
            }
            yield return new WaitForSeconds(0.3f);
        }
    }

    public IEnumerator Played(PlayData data)
    {
        if(data.side == otherSide && snared[data.index] != null && array[otherSide][data.index] != controller.empty[otherSide])
        {
            yield return array[otherSide][data.index].GetComponent<Unit>().StartCoroutine(array[otherSide][data.index].GetComponent<Unit>().TakeDMG(new AttackData(currentATK, false, gameObject, false, dmgTypes.damage)));
            Destroy(snared[data.index]);
            snared[data.index] = null;
        }
    }
}
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Jetpack : Robotsunit
{
    GameObject multi;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        multi = Instantiate(controller.effectCarrier, transform);
        multi.AddComponent<MuliAttack>();
        statuses.Add(multi.GetComponent<MuliAttack>());
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield return base.OnTurnEndBA();
        multi.GetComponent<MuliAttack>().power = 0;
        int index = System.Array.IndexOf(controller.board[mySide], gameObject);
        if (4 > index && index > 0)
        {
            if (controller.board[mySide][index - 1] != controller.empty[mySide] && controller.board[mySide][index + 1] != controller.empty[mySide])
            {
                if((controller.board[mySide][index - 1].GetComponent<Robotsunit>().id == 304 || controller.board[mySide][index - 1].GetComponent<Robotsunit>().colorsPossesed.Contains(1)) && (controller.board[mySide][index + 1].GetComponent<Robotsunit>().id == 304 || controller.board[mySide][index + 1].GetComponent<Robotsunit>().colorsPossesed.Contains(1)))
                {
                    multi.GetComponent<MuliAttack>().power = 1;
                }
            }
        }
    }
}
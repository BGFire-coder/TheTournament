using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class VacuumCleaner : Robotsunit
{
    int direction = 1;
    bool triggered = false;
    public override IEnumerator OnTurnEndAA()
    {
        yield return StartCoroutine(base.OnTurnEndAA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            if (!triggered)
            {
                int index = System.Array.IndexOf(array[mySide], gameObject);
                if (index + direction < 5 && index + direction > -1 && array[mySide][index + direction] == controller.empty[mySide])
                {
                    array[mySide][index + direction] = gameObject;
                    array[mySide][index] = controller.empty[mySide];
                    transform.position = PositionByIndex.GetPosition(mySide, index + direction);
                    yield return Message.SendToSide(mySide, "Moved", new MoveData(gameObject, index, index + direction));
                    foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
                    {
                        b.transform.SetParent(transform, true);
                        statuses.Add(b);
                    }
                }
                else
                {
                    direction *= -1;
                    if (index + direction < 5 && index + direction > -1 && array[mySide][index + direction] == controller.empty[mySide])
                    {
                        array[mySide][index + direction] = gameObject;
                        array[mySide][index] = controller.empty[mySide];
                        transform.position = PositionByIndex.GetPosition(mySide, index + direction);
                        yield return Message.SendToSide(mySide, "Moved", new MoveData(gameObject, index, index + direction));
                        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
                        {
                            b.transform.SetParent(transform, true);
                            statuses.Add(b);
                        }
                        foreach (Burn b in statuses) b.index[1] = index;
                    }
                    else yield return Message.SendToSide(mySide, "MoveFailed", null);
                }
                int crit = 1;
                bool isCrit = false;
                yield return StartCoroutine(ChanceHandler.Chance(currentCrit * 3));
                if (ChanceValue.yesNo)
                {
                    isCrit = true;
                    crit = 2;
                }
                GameObject target = array[otherSide][4 - System.Array.IndexOf(array[mySide], gameObject)];
                if (target != controller.empty[otherSide]) yield return target.GetComponent<Unit>().StartCoroutine(target.GetComponent<Unit>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, false, dmgTypes.damage)));
                yield return new WaitForSeconds(0.2f);
                triggered = true;
            }
        }
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return StartCoroutine(base.OnTurnStart1());
        triggered = false;
    }
}
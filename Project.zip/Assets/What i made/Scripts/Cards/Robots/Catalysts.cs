using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Catalysts : Robotsspell
{
    public List<int> effects = new List<int>();
    public override IEnumerator Play(int index)
    {
        pile = 1;
        List<Robotsunit> done = new List<Robotsunit>();
        for(int i = 0; i < 5; i++)
        {
            
            GameObject target = array[mySide][i];
            if (target != controller.empty[mySide] && target.GetComponent<Robotsunit>() != null && target.GetComponent<Robotsunit>().colorsPossesed.Where(x => effects.Contains(x)).ToList().Count > 0)
            {
                Robotsunit unit = target.GetComponent<Robotsunit>();
                if(!done.Contains(unit))
                {
                    if (unit.supportedTriggers.Contains("OnTurnEndBA")) yield return unit.StartCoroutine("OnTurnEndBA");
                    if (unit.supportedTriggers.Contains("OnTurnEndAA")) yield return unit.StartCoroutine("OnTurnEndAA");
                    if (unit.supportedTriggers.Contains("OnTurnStart1")) yield return unit.StartCoroutine("OnTurnStart1");
                    if (unit.supportedTriggers.Contains("OnTurnStart2")) yield return unit.StartCoroutine("OnTurnStart2");
                    done.Add(unit);
                }
                
            }
        }
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, 10, colorsPossesed.ToArray()));
        Hide();
    }
}
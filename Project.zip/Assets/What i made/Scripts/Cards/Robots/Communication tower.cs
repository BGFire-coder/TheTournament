using System.Collections;

public class CommunicationTower : Robotsunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Moved");
        supportedTriggers.Add("Created");
    }

    public IEnumerator Moved(MoveData data)
    {
        yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().Draw(0));
    }

    public IEnumerator Created()
    {
        yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().Draw(0));
    }
}
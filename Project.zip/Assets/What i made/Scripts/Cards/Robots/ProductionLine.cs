using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class ProductionLine : Robotsunit
{
    public GameObject nanobot;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Moved");
    }

    public IEnumerator Moved(MoveData data)
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            array[mySide][data.oldIndex] = Instantiate(nanobot, PositionByIndex.GetPosition(mySide, data.oldIndex), new Quaternion());
            array[mySide][data.oldIndex].GetComponent<Robotsunit>().mySide = mySide;
            array[mySide][data.oldIndex].BroadcastMessage("Create", new int[2] { 1, 2 });
            yield return new WaitForSeconds(0.2f);
        }
    }
}
using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class BladeBot : Robotsunit
{
    GameObject dmgBuff;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Played");
    }

    public IEnumerator Played(PlayData data)
    {
        yield return null;
        if(data.side == mySide && data.colors.Contains(0) && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            dmgBuff = Instantiate(controller.effectCarrier, transform);
            dmgBuff.AddComponent<DmgBuff>();
            statuses.Add(dmgBuff.GetComponent<DmgBuff>());
            dmgBuff.GetComponent<DmgBuff>().power = 1;
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, pickedIndex, true, dmgBuff));
        }
    }
}
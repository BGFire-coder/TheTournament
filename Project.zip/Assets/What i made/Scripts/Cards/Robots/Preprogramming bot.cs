using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;
using static UnityEngine.GraphicsBuffer;

public class PreprogrammingBot : Robotsunit
{
    public GameObject nanobot;

    public override void Awake()
    {
        base.Awake();
        supportedTriggers.Add("OnTurnStart2");
    }

    public IEnumerator OnTurnStart2()
    {
        if (controller.empty[mySide].GetComponent<Robots>().colors[1] > 0 && array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Robotsunit>().colorsPossesed.Contains(1)).ToList().Count > 1 && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            for (int i = 0; i < 5; i++)
            {
                if (array[mySide][i] != controller.empty[mySide] && array[mySide][i] != gameObject)
                {
                    array[mySide][i].GetComponent<Unit>().currentHP = 0;
                    array[mySide][i].BroadcastMessage("Discard");
                    array[mySide][i] = Instantiate(nanobot, PositionByIndex.GetPosition(mySide, i), new Quaternion());
                    array[mySide][i].GetComponent<Nanobot>().mySide = mySide;
                    array[mySide][i].BroadcastMessage("Create", new int[2] { 2, 2 });
                    yield return new WaitForSeconds(0.2f);
                }
            }
        }
    }
}
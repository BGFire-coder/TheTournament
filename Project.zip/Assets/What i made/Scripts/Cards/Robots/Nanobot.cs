using NUnit.Framework;
using System.Linq;
using UnityEngine;
using System.Collections.Generic;

public class Nanobot : Robotsunit
{
    public void Create(int[] stats)
    {
        baseATK = currentATK = stats[0];
        maxHP = currentHP = stats[1];
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("OnTurnEndBA");
        supportedTriggers.Add("OnTurnEndAA");
        supportedTriggers.Add("Hit");
        real = false;
        StartCoroutine(Message.SendToSide(mySide, "Created", null));
    }

    public override void Start()
    {
        pile = 1;
        transform.localScale = new Vector3(1.2f, 1.2f, 1);
        base.Start();
        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(array[mySide], gameObject)))
        {
            b.transform.SetParent(transform, true);
            statuses.Add(b);
            controller.burn.Remove(b);
        }
    }
}
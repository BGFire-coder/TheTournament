using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class Forklift : Robotsunit
{
    bool triggered = false;
    public override IEnumerator OnTurnEndAA()
    {
        yield return StartCoroutine(base.OnTurnEndAA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            
            if (!triggered)
            {
                int direction = 0;
                int side = -1;
                int index = System.Array.IndexOf(array[mySide], gameObject);
                for(int i = 0; i < 2; i++)
                {
                    if (index + 2 * side > -1 && index + 2 * side < 5 && array[mySide][index + side] != controller.empty[mySide] && array[mySide][index + 2 * side] == controller.empty[mySide])
                    {
                        array[mySide][index + 2 * side] = array[mySide][index + side];
                        array[mySide][index + side] = controller.empty[mySide];
                        array[mySide][index + 2 * side].transform.position = PositionByIndex.GetPosition(mySide, index + 2 * side);
                        yield return Message.SendToSide(mySide, "Moved", new MoveData(gameObject, index + side, index + side * 2));
                        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == index + 2 * side))
                        {
                            b.transform.SetParent(array[mySide][index + 2 * side].transform, true);
                            array[mySide][index + 2 * side].GetComponent<Unit>().statuses.Add(b);
                        }
                        foreach (Burn b in statuses) b.index[1] = index + 2 * side;
                        if (array[mySide][index + 2 * side].GetComponent<Unit>().id == 700) direction = side;
                    }
                    else if(array[mySide][index + side] != controller.empty[mySide]) yield return Message.SendToSide(mySide, "MoveFailed", null);
                    side = 1;
                    yield return new WaitForSeconds(0.2f);
                }
                if(direction != 0)
                {
                    if (array[mySide][index + direction] == controller.empty[mySide])
                    {
                        array[mySide][index + direction] = gameObject;
                        array[mySide][index] = controller.empty[mySide];
                        transform.position = PositionByIndex.GetPosition(mySide, index + direction);
                        yield return Message.SendToSide(mySide, "Moved", new MoveData(gameObject, index, index + direction));
                        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
                        {
                            b.transform.SetParent(transform, true);
                            statuses.Add(b);
                        }
                        foreach (Burn b in statuses) b.index[1] = index;
                    }
                    else yield return Message.SendToSide(mySide, "MoveFailed", null);
                }
                triggered = true;
            }
        }
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return StartCoroutine(base.OnTurnStart1());
        triggered = false;
    }
}
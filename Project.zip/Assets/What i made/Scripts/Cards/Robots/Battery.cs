using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Battery : Robotsspell
{
    public int color;
    public override IEnumerator Play(int index)
    {
        pile = 1;
        controller.empty[mySide].GetComponent<Robots>().colors[color] = 2;
        yield return Message.SendToSide(mySide, "BatteryPlayed", null);
        controller.empty[mySide].GetComponent<Robots>().batteries.Remove(gameObject);
        OrderHand.OrderBatteries(controller.empty[mySide].GetComponent<Players>().hand, controller.empty[mySide].GetComponent<Robots>().batteries, mySide);
        Hide();
    }

    public override IEnumerator OnMouseDown()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") yield break;
        controller.runningProcesses++;
        int battery = controller.empty[mySide].GetComponent<Robots>().batteries.IndexOf(gameObject);
        yield return StartCoroutine(Play(pickedIndex));
        if (controller.mode == 1)
        {
            CardPlayedEvent cardPlayed = new CardPlayedEvent() { IndexOnBoard = 0, indexInHand = battery, cardType = 1 };
            Communication.forSend.Add(cardPlayed);
            OrderHand.OrderBatteries(controller.empty[mySide].GetComponent<Players>().hand, controller.empty[mySide].GetComponent<Robots>().batteries, mySide);
        }
        controller.runningProcesses--;
    }
}
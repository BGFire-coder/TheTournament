using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class ArmoredBot : Robotsunit
{
    public override IEnumerator Play(int index)
    {
        yield return StartCoroutine(base.Play(index));
        int bonusHP = 0;
        for(int i = 0; i < 5; i++)
        {
            if (array[mySide][i] != controller.empty[mySide] && i != pickedIndex && array[mySide][i].GetComponent<Robotsunit>().colorsPossesed.Contains(0))
            {
                bonusHP += array[mySide][i].GetComponent<Robotsunit>().currentATK;
            }
        }
        yield return StartCoroutine(TakeDMG(new AttackData(bonusHP, false, gameObject, false, dmgTypes.HPIncrease)));
    }
}
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;
using static UnityEngine.GraphicsBuffer;

public class CasinoBot : Robotsunit
{
    public override IEnumerator OnTurnStart1()
    {
        if (controller.empty[mySide].GetComponent<Robots>().colors.Where(x => x > 0).ToList().Count > 1)
        {
            yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().Draw(0));
            yield return new WaitForSeconds(0.2f);
            yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().Draw(0));
        }
    }
}
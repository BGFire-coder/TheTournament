using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using UnityEngine;

public class ChargingBot : Robotsunit
{
    public override IEnumerator OnTurnStart1()
    {
        yield return base.OnTurnStart1();
        if(controller.empty[mySide].GetComponent<Robots>().colors[0] > 0 && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            List<GameObject> possTargets = array[mySide].Where(x => x.GetComponent<Robotsunit>() != null && x.GetComponent<Robotsunit>().colorsPossesed.Contains(0)).ToList();
            int count = possTargets.Count;
            again:
            if (possTargets.Count > 0 && count - possTargets.Count < 2)
            {
                yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
                int index = ChanceValue.value;
                GameObject carrier = Instantiate(controller.effectCarrier, possTargets[index].transform);
                Effect buff = carrier.AddComponent<DmgBuff>();
                buff.power = 1;
                possTargets[index].GetComponent<Robotsunit>().statuses.Add(buff);
                yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], possTargets[index]), true, carrier));
                carrier = Instantiate(controller.effectCarrier, possTargets[index].transform);
                buff = carrier.AddComponent<CritBuff>();
                buff.power = 3;
                possTargets[index].GetComponent<Robotsunit>().statuses.Add(buff);
                yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], possTargets[index]), true, carrier));
                possTargets.RemoveAt(index);
                goto again;
            }
        }
    }
}
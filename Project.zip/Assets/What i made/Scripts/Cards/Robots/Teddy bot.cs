using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class TeddyBot : Robotsunit
{
    bool used = false;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Created");
    }

    public IEnumerator Created()
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0 && !used)
        {
            Players target = controller.empty[mySide].GetComponent<Players>();
            yield return target.StartCoroutine(target.TakeDMG(new AttackData(1, false, gameObject, false, dmgTypes.heal)));
            used = true;
        }
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return base.OnTurnStart1();
        used = false;
    }
}
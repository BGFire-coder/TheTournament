using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class Delivery_drone : Robotsunit
{
    int direction = 1;
    bool triggered = false;
    public override IEnumerator OnTurnEndAA()
    {
        yield return StartCoroutine(base.OnTurnEndAA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            if (!triggered)
            {
                int repeat = 1;
                SecondMove:
                int index = System.Array.IndexOf(array[mySide], gameObject);
                if (index + direction < 5 && index + direction > -1 && array[mySide][index + direction] == controller.empty[mySide])
                {
                    array[mySide][index + direction] = gameObject;
                    array[mySide][index] = controller.empty[mySide];
                    transform.position = PositionByIndex.GetPosition(mySide, index + direction);
                    yield return Message.SendToSide(mySide, "Moved", new MoveData(gameObject, index, index + direction));
                    foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
                    {
                        b.transform.SetParent(transform, true);
                        statuses.Add(b);
                    }
                }
                else
                {
                    direction *= -1;
                    if (index + direction < 5 && index + direction > -1 && array[mySide][index + direction] == controller.empty[mySide])
                    {
                        array[mySide][index + direction] = gameObject;
                        array[mySide][index] = controller.empty[mySide];
                        transform.position = PositionByIndex.GetPosition(mySide, index + direction);
                        yield return Message.SendToSide(mySide, "Moved", new MoveData(gameObject, index, index + direction));
                        foreach (Burn b in controller.burn.Where(b => b.index[0] == mySide && b.index[1] == System.Array.IndexOf(controller.board[mySide], gameObject)))
                        {
                            b.transform.SetParent(transform, true);
                            statuses.Add(b);
                        }
                        foreach (Burn b in statuses) b.index[1] = index;
                    }
                    else yield return Message.SendToSide(mySide, "MoveFailed", null);
                }
                yield return new WaitForSeconds(0.1f);
                repeat++;
                if (repeat == 2) goto SecondMove;
                yield return new WaitForSeconds(0.2f);
                triggered = true;
            }
        }
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return StartCoroutine(base.OnTurnStart1());
        triggered = false;
    }
}
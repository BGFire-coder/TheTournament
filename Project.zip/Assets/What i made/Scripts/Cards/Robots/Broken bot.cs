using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class BrokenBot : Robotsunit
{
    public override void Awake()
    {
        base.Awake();
        supportedTriggers.Add("Combined");
    }

    public IEnumerator Combined()
    {
        if(GetTargets().Count > 0)
        {
            if(mySide == 0)
            {
                yield return SpawnPickers();
                if (controller.mode == 1)
                {
                    MultichoiceEvent choice = new MultichoiceEvent() { index = pickedIndex, optionsCount = GetTargets().Count };
                    Communication.forSend.Add(choice);
                }
                yield return Play(pickedIndex);
            }
            else
            {
                if (controller.mode == 0) yield return Play(controller.empty[1].GetComponent<Players>().ai.ChoiceMaking(1, GetTargets()));
                else
                {
                    yield return new WaitUntil(() => EventQueue.events.Count > 0);
                    if (EventQueue.events[0].eventType == EventTypes.multichoiceMade)
                    {
                        MultichoiceEvent multichoice = EventQueue.events[0].ConvertTo<MultichoiceEvent>();
                        EventQueue.events.RemoveAt(0);
                        if (multichoice.optionsCount == GetTargets().Count) yield return StartCoroutine(Play(multichoice.index));
                        else
                        {
                            EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                            Communication.forSend.Add(error);
                        }
                    }
                    else
                    {
                        EnemyEvent error = new EnemyEvent() { eventType = EventTypes.error };
                        Communication.forSend.Add(error);
                    }
                }
            }
            OrderHand.OrderBatteries(controller.empty[mySide].GetComponent<Players>().hand, controller.empty[mySide].GetComponent<Robots>().batteries, mySide);
            supportedTriggers.Remove("Combined");
        }
        
    }

    public override bool CheckIfPlayable()
    {
        return false;
    }
}
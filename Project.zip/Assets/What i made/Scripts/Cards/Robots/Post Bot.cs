using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class PostBot : Robotsunit
{

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Drawing");
    }

    public IEnumerator Drawing()
    {
        List<GameObject> possTargets = array[mySide].Where(x => x != controller.empty[mySide] && x.GetComponent<Robotsunit>().currentHP < x.GetComponent<Robotsunit>().maxHP).ToList();
        if(possTargets.Count > 0 && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            yield return StartCoroutine(ChanceHandler.MultiChoice(possTargets));
            int target = ChanceValue.value;
            yield return possTargets[target].GetComponent<Robotsunit>().StartCoroutine(possTargets[target].GetComponent<Robotsunit>().TakeDMG(new AttackData(1, false, gameObject, true, dmgTypes.heal)));
        }
    }
}
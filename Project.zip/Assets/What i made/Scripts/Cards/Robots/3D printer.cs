using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Printer : Robotsunit
{
    public GameObject nanobot;
    List<GameObject> created;

    public override IEnumerator OnTurnEndBA()
    {
        yield return StartCoroutine(base.OnTurnEndBA());
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            for(int i = 0; i < 5; i++)
            {
                if (controller.board[mySide][i] == controller.empty[mySide])
                {
                    controller.board[mySide][i] = Instantiate(nanobot, PositionByIndex.GetPosition(mySide, i), new Quaternion());
                    controller.board[mySide][i].BroadcastMessage("Create", new int[2] { 1, 1 });
                    controller.board[mySide][i].GetComponent<Robotsunit>().mySide = mySide;
                    created.Add(controller.board[mySide][i]);
                }
            }
            yield return new WaitForSeconds(0.2f);
        }
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return StartCoroutine(base.OnTurnStart1());
        foreach (GameObject go in created)
        {
            created.Remove(go);
            controller.board[mySide][System.Array.IndexOf(controller.board[mySide], go)] = controller.empty[mySide];
            Destroy(go);
        }
        yield return new WaitForSeconds(0.1f);
    }
}
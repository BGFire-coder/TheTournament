using System.Collections;
using System;
using UnityEngine;

public class Scales : Robotsunit
{
    GameObject old;
    bool wasGreen;
    GameObject buff;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("onTurnStart2");
    }

    public override IEnumerator OnTurnEndAA()
    {
        yield return base.OnTurnEndAA();
        int blues = 0;
        for(int i = 0; i < Array.IndexOf(array[mySide], gameObject); i++)
        {
            if (array[mySide][i].GetComponent<Robotsunit>() != null && array[mySide][i].GetComponent<Robotsunit>().colorsPossesed.Contains(3)) blues++;
        }
        if(blues > 1 && Array.IndexOf(array[mySide], gameObject) < 4)
        {
            old = array[mySide][Array.IndexOf(array[mySide], gameObject) + 1];
            if(old != controller.empty[mySide])
            {
                wasGreen = old.GetComponent<Robotsunit>().colorsPossesed.Contains(2);
                if (!wasGreen) old.GetComponent<Robotsunit>().AddColor(2);
                buff = Instantiate(controller.effectCarrier, old.transform);
                Defence defense = buff.AddComponent<Defence>();
                defense.power = 1;
                defense.creator = gameObject;
                old.GetComponent<Robotsunit>().statuses.Add(defense);
                yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], old), true, buff));
            }
        }
    }

    public IEnumerator OnTurnStart2()
    {
        yield return null;
        if(old != controller.empty[mySide] && old.GetComponent<Robotsunit>() != null)
        {
            if (!wasGreen) old.GetComponent<Robotsunit>().RemoveColor(2);
        }
    }
}
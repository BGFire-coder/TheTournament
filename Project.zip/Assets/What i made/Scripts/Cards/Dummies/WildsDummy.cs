using System.Collections;
using UnityEngine;

public class WildsDummy : Wildsunit
{
    public Unit realScript;
    public override IEnumerator TakeDMG(AttackData atk)
    {
        yield return realScript.StartCoroutine(realScript.TakeDMG(atk));
    }

    public override IEnumerator Upgrade(int day)
    {
        yield break;
    }

    public override IEnumerator OnTurnEndAA()
    {
        yield return realScript.StartCoroutine(realScript.OnTurnEndAA());
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield return realScript.StartCoroutine(realScript.OnTurnEndBA());
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return realScript.StartCoroutine(realScript.OnTurnStart1());
    }
}
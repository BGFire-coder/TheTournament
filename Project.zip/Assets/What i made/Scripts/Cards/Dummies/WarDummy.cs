using System.Collections;
using UnityEngine;

public class WarDummy : Warunit
{
    public Unit realScript;
    public override IEnumerator TakeDMG(AttackData atk)
    {
        yield return realScript.StartCoroutine(realScript.TakeDMG(atk));
    }

    public override IEnumerator ChangeLifetime(int amount)
    {
        yield break;
    }

    public override IEnumerator OnTurnEndAA()
    {
        yield return realScript.StartCoroutine(realScript.OnTurnEndAA());
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield return realScript.StartCoroutine(realScript.OnTurnEndBA());
    }

    public override IEnumerator OnTurnStart1()
    {
        yield return realScript.StartCoroutine(realScript.OnTurnStart1());
    }

    public override IEnumerator OnTurnStart2()
    {
        yield break;
    }
}
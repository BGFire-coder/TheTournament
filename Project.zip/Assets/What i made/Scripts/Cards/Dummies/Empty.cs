using System.Collections;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Empty : Unit
{
    public GameObject owner;

    public override void Start()
    {
        base.Start();
        switch (controller.empty[mySide].GetComponent<Players>().type)
        {
            case 1:
                {
                    WarDummy dummy = gameObject.AddComponent<WarDummy>();
                    dummy.realScript = this;
                    dummy.pile = 1;
                    break;
                }
            case 2:
                {
                    WildsDummy dummy = gameObject.AddComponent<WildsDummy>();
                    dummy.realScript = this;
                    dummy.pile = 1;
                    break;
                }
            case 3:
                {
                    RobotsDummy dummy = gameObject.AddComponent<RobotsDummy>();
                    dummy.realScript = this;
                    dummy.pile = 1;
                    break;
                }
            case 4:
                {
                    MythsDummy dummy = gameObject.AddComponent<MythsDummy>();
                    dummy.realScript = this;
                    dummy.pile = 1;
                    break;
                }
        }
        supportedTriggers.Add("OnTurnStart2");
    }

    public IEnumerator OnTurnStart2()
    {
        yield return owner.GetComponent<Unit>().StartCoroutine("OnTurnStart2");
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        yield return controller.empty[mySide].GetComponent<Players>().StartCoroutine(controller.empty[mySide].GetComponent<Players>().TakeDMG(atk));
    }

    public override IEnumerator OnTurnEndAA()
    {
        yield break;
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield break;
    }

    public override IEnumerator OnTurnStart1()
    {
        yield break;
    }
}
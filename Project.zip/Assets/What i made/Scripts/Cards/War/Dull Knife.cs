using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class DullKnife : Warunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Kill");
    }

    public IEnumerator Kill(KillData data)
    {
        if(data.killer == gameObject)
        {
            GameObject shStone = Instantiate(controller.library.GetComponent<CardLibrary>().type1[4]);
            controller.empty[mySide].GetComponent<Players>().hand.Add(shStone);
            SharpeningStone stone = shStone.GetComponent<SharpeningStone>();
            stone.real = false;
            stone.mySide = mySide;
            stone.discardableAfterTurns = 1;
            OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        }
        yield return null;
    }
}
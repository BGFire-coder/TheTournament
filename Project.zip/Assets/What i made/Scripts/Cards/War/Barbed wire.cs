using System;
using System.Collections;
using System.Linq;
using UnityEngine;

public class BarbedWire : Warunit
{
    public override IEnumerator OnTurnStart2()
    {
        int index = System.Array.IndexOf(array[mySide], gameObject);
        if (index > 4 && array[mySide][index - 5] == controller.empty[mySide])
        {
            array[mySide][index] = controller.empty[mySide];
            array[mySide][index - 5] = gameObject;
            transform.position = PositionByIndex.GetPosition(mySide, index - 5);
            if(index - 6 > -1 && array[mySide][index - 6] != controller.empty[mySide]) yield return array[mySide][index - 6].GetComponent<Warunit>().StartCoroutine(array[mySide][index - 6].GetComponent<Warunit>().ChangeLifetime(-1));
            if(index - 4 < 5 && array[mySide][index - 4] != controller.empty[mySide]) yield return array[mySide][index - 4].GetComponent<Warunit>().StartCoroutine(array[mySide][index - 4].GetComponent<Warunit>().ChangeLifetime(-1));
            yield return new WaitForSeconds(0.2f);
        }
    }
}
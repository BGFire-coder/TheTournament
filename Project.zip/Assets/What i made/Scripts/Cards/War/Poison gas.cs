using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PoisonGas : Warspell
{
    int turnsLeft = 3;

    public override IEnumerator Play(int index)
    {
        pile = 1;
        controller.activeEffects.Add(this);
        supportedTriggers.Add("OnTurnStart1");
        supportedTriggers.Add("Played");
        transform.position = new Vector3(0, 10, 0);
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        AddToDiscard();
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, 10, null));
    }

    public IEnumerator Played(PlayData data)
    {
        if (data.side == otherSide && data.index < 10 && array[otherSide][data.index].GetComponent<Unit>() != null) yield return array[otherSide][data.index].GetComponent<Unit>().StartCoroutine(array[otherSide][data.index].GetComponent<Unit>().TakeDMG(new AttackData(1, false, gameObject, false, dmgTypes.damage)));
    }

    public IEnumerator OnTurnStart1()
    {
        yield return null;
        if(controller.turn == mySide)
        {
            turnsLeft--;
            if (turnsLeft == 0)
            {
                controller.activeEffects.Remove(this);
                AddToDiscard();
                Destroy(gameObject);
            }
        }
    }

    public override List<int> GetTargets()
    {
        return new List<int>{ 1 };
    }
}
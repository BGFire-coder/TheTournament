using System;
using System.Collections;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class Flamethrower : Warunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("OnTurnEndBA");
    }

    public override IEnumerator OnTurnEndBA()
    {
        yield return base.OnTurnEndBA();
        int index = Array.IndexOf(array[mySide], gameObject);
        if (index < 5 && array[mySide][index + 5] != controller.empty[mySide] && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            yield return array[mySide][index + 5].GetComponent<Warunit>().StartCoroutine(array[mySide][index + 5].GetComponent<Warunit>().TakeDMG(new AttackData(30, false, gameObject, false, dmgTypes.damage)));
            GameObject carrier = Instantiate(controller.effectCarrier, transform);
            Effect buff = carrier.AddComponent<DmgBuff>();
            buff.power = 1;
            statuses.Add(buff);
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, index, true, carrier));
            carrier = Instantiate(controller.effectCarrier, transform);
            buff = carrier.AddComponent<CritBuff>();
            buff.power = 3;
            statuses.Add(buff);
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, index, true, carrier));
        }
    }
}
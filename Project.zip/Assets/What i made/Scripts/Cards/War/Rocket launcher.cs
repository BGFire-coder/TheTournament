using System;
using System.Collections;
using System.Linq;
using System.Runtime.InteropServices;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class RocketLauncher : Warunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        cycles++;
        if (cycles == 4) cycles = 1;
        if(cycles == 3)
        {
            GameObject carrier = Instantiate(controller.effectCarrier, transform);
            Effect buff = carrier.AddComponent<CritBuff>();
            buff.power = 20;
            statuses.Add(buff);
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, Array.IndexOf(array[mySide], gameObject), true, carrier));
            supportedTriggers.Add("Crit");
        }
    }

    public IEnumerator Crit(CritData data)
    {
        if (data.critter == gameObject && statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
        {
            GameObject target = array[otherSide][4 - System.Array.IndexOf(array[mySide], gameObject)];
            GameObject debuff = Instantiate(controller.effectCarrier);
            Burn instance = debuff.AddComponent<Burn>();
            instance.creator = gameObject;
            instance.target = target;
            instance.turns = 2;
            instance.index = new int[] { otherSide, 4 - System.Array.IndexOf(array[mySide], gameObject) };
            instance.controller = controller;
            if (target != controller.empty[otherSide])
            {
                debuff.transform.SetParent(target.transform, false);
                target.GetComponent<Unit>().statuses.Add(instance);
                yield return Message.SendToBoard(otherSide, "Status", new StatusData(otherSide, Array.IndexOf(array[otherSide], target), false, debuff));
            }
            else
            {
                debuff.transform.localScale = Vector3.one * 1.2f;
                controller.burn.Add(instance);
                debuff.transform.position = target.transform.position;
            }
        }
    }
}
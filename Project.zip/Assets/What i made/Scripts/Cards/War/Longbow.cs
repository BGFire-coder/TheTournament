using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Longbow : Warunit
{
    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for (int i = 5; i < 10; i++)
        {
            if (array[mySide][i] == controller.empty[mySide] && array[mySide][i - 5] != controller.empty[mySide]) positions.Add(i);
        }
        return positions;
    }
}
using System;
using System.Collections;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class ShinyKnife : Warunit
{
    public override IEnumerator ChangeLifetime(int amount)
    {
        currentLifetime += amount;
        if (currentLifetime < 1 && currentHP > 0)
        {
            Hide();
            yield return Message.SendToAll(mySide, "Kill", new KillData(gameObject, mySide, System.Array.IndexOf(array[mySide], gameObject)));
            if(statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
            {
                GameObject dull = Instantiate(controller.library.GetComponent<CardLibrary>().type1[5], transform.position, new Quaternion());
                dull.transform.localScale = new Vector3(1.2f, 1.2f, 1);
                DullKnife knife = dull.GetComponent<DullKnife>();
                array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = dull;
                knife.mySide = mySide;
                knife.real = false;
                knife.pile = 1;
                knife.supportedTriggers.Add("OnTurnStart1");
                knife.supportedTriggers.Add("OnTurnEndBA");
                knife.supportedTriggers.Add("OnTurnEndAA");
                knife.supportedTriggers.Add("ChangeLifetime");
                knife.supportedTriggers.Add("OnTurnStart2");
                knife.supportedTriggers.Add("OnMoved");
                knife.supportedTriggers.Add("Hit");
            }
            else if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
        }
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        if (currentHP > 0)
        {
            int defense = 0;
            int reduction = 0;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.AntiHeal)) reduction += e.power;
            if (atk.type != dmgTypes.damage)
            {
                if (atk.amount > reduction)
                {
                    currentHP += (atk.amount - reduction);
                    if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
                    Instantiate(heal, transform);
                    yield return Message.SendToSide(mySide, "Healed", new AttackData(atk.amount, atk.isCrit, gameObject, false, dmgTypes.heal));
                }
            }
            else if (defense < atk.amount)
            {
                currentHP -= (atk.amount - defense);
                if (atk.isCrit) Instantiate(crit, transform);
                else Instantiate(damage, transform);
                yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
            }
            if (currentHP < 1)
            {
                Hide();
                if (controller.empty[mySide].GetComponent<Players>().type == 4) controller.empty[mySide].GetComponent<Myths>().corpses++;
                if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
                Instantiate(death, transform.position, new Quaternion());
                yield return Message.SendToAll(mySide, "Kill", new KillData(atk.attacker, mySide, System.Array.IndexOf(array[mySide], gameObject)));
                if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0)
                {
                    GameObject dull = Instantiate(controller.library.GetComponent<CardLibrary>().type1[5], transform.position, new Quaternion());
                    dull.transform.localScale = new Vector3(1.2f, 1.2f, 1);
                    DullKnife knife = dull.GetComponent<DullKnife>();
                    knife.mySide = mySide;
                    knife.real = false;
                    knife.supportedTriggers.Add("OnTurnStart1");
                    knife.supportedTriggers.Add("OnTurnEndBA");
                    knife.supportedTriggers.Add("OnTurnEndAA");
                    knife.supportedTriggers.Add("ChangeLifetime");
                    knife.supportedTriggers.Add("OnTurnStart2");
                    knife.supportedTriggers.Add("OnMoved");
                    knife.supportedTriggers.Add("Hit");
                    knife.supportedTriggers.Add("Kill");
                    knife.pile = 1;
                    if (System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = dull;
                }
                else if(System.Array.IndexOf(array[mySide], gameObject) > -1) array[mySide][System.Array.IndexOf(array[mySide], gameObject)] = controller.empty[mySide];
            }
        }
    }
}
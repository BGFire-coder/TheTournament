using System.Collections;
using System.Linq;

public class Graveyard : Warunit
{
    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        supportedTriggers.Add("Kill");
    }

    public IEnumerator Kill(KillData data)
    {
        if (statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0) yield return Attack();
    }
}
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SharpeningStone : Warspell
{
    public override List<int> GetTargets()
    {
        List<int> positions = new List<int>();
        for (int i = 0; i < 5; i++)
        {
            if (array[mySide][i] != controller.empty[mySide] && array[mySide][i].GetComponent<Warunit>() != null && array[mySide][i].GetComponent<Warunit>().currentLifetime < array[mySide][i].GetComponent<Warunit>().maxLifetime) positions.Add(i);
        }
        return positions;
    }

    public override IEnumerator Play(int index)
    {
        pile = 1;
        controller.empty[mySide].GetComponent<Players>().hand.Remove(gameObject);
        yield return array[mySide][index].GetComponent<Warunit>().StartCoroutine(array[mySide][index].GetComponent<Warunit>().ChangeLifetime(1));
        if (index - 1 > -1 && array[mySide][index - 1] != controller.empty[mySide]) yield return array[mySide][index - 1].GetComponent<Warunit>().StartCoroutine(array[mySide][index - 1].GetComponent<Warunit>().ChangeLifetime(1));
        if (index + 1 < 5 && array[mySide][index + 1] != controller.empty[mySide]) yield return array[mySide][index + 1].GetComponent<Warunit>().StartCoroutine(array[mySide][index + 1].GetComponent<Warunit>().ChangeLifetime(1));
        yield return Message.SendToAll(mySide, "Played", new PlayData(mySide, 10, null));
        OrderHand.Order(controller.empty[mySide].GetComponent<Players>().hand, mySide);
        Hide();
    }
}
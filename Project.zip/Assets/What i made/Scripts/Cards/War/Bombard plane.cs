using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Plane : Warunit
{
    public override IEnumerator Attack()
    {
        if (statuses.Where(x => x.power == 1 && (x.effect == EffectNames.Freeze || x.effect == EffectNames.Stun)).ToList().Count == 0)
        {
            int multiattack = 1;
            foreach (Effect effect in statuses.Where(x => x.effect == EffectNames.Multiattack)) multiattack += effect.power;
            for (int i = 0; i < multiattack; i++)
            {
                int crit = 1;
                bool isCrit = false;
                yield return StartCoroutine(ChanceHandler.Chance(currentCrit));
                if (ChanceValue.yesNo)
                {
                    isCrit = true;
                    crit = 2;
                }
                int index = System.Array.IndexOf(array[mySide], gameObject);
                GameObject attack = Instantiate(attackAnimation);
                Attack anim = attack.GetComponent<Attack>();
                anim.target = 4 - index;
                anim.beggining = index;
                anim.side = mySide;
                yield return new WaitUntil(() => anim.finished);
                GameObject target = array[otherSide][4 - index];
                yield return controller.empty[otherSide].GetComponent<Players>().StartCoroutine(controller.empty[otherSide].GetComponent<Players>().TakeDMG(new AttackData(currentATK * crit, isCrit, gameObject, true, dmgTypes.damage)));
                if (isCrit) yield return Message.SendToBoard(mySide, "Crit", new CritData(mySide, index, gameObject));
                yield return new WaitForSeconds(0.1f);
            }
            yield return new WaitForSeconds(0.3f);
        }
    }
}
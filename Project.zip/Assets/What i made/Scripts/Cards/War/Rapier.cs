using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Rapier : Warunit
{
    int attack;
    GameObject buff;
    DmgBuff dmgBuff;
    public override void Awake()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") return;
        base.Awake();
        buff = Instantiate(controller.effectCarrier, transform);
        buff.AddComponent<DmgBuff>();
        statuses.Add(buff.GetComponent<DmgBuff>());
        dmgBuff = buff.GetComponent<DmgBuff>();
    }

    public override void Update()
    {
        if (System.Array.IndexOf(array[mySide], gameObject) < 5)
        {
            attack = 0;
            for (int i = 5; i < 10; i++) if (array[mySide][i] != controller.empty[mySide]) attack += array[mySide][i].GetComponent<Unit>().currentATK;
            currentATK = baseATK;
            if(statuses.Where(x => x.power == 1 && x.effect == EffectNames.Freeze).ToList().Count == 0) dmgBuff.power = attack / 2;
            foreach (Effect e in statuses.Where(x => x.effect == EffectNames.ATKBoost)) currentATK += e.power;
        }
    }
}
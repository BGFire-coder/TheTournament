using System;
using System.Collections;
using System.Linq;
using TMPro;
using UnityEngine;

public class Gloves : Warunit
{
    GameObject buff;

    public override IEnumerator Play(int index)
    {
        yield return base.Play(index);
        if (System.Array.IndexOf(array[mySide], gameObject) > 4)
        {
            int targetIndex = System.Array.IndexOf(array[mySide], gameObject) - 5;
            buff = Instantiate(controller.effectCarrier, array[mySide][targetIndex].transform);
            buff.AddComponent<DmgBuff>();
            buff.GetComponent<DmgBuff>().power = 1;
            array[mySide][targetIndex].GetComponent<Unit>().statuses.Add(buff.GetComponent<DmgBuff>());
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, targetIndex, true, buff));
        }
    }

    public override IEnumerator TakeDMG(AttackData atk)
    {
        int defense = 0;
        foreach (Effect e in statuses.Where(x => x.effect == EffectNames.Defense)) defense += e.power;
        if (atk.type != dmgTypes.damage)
        {
            currentHP += atk.amount;
            if (currentHP > maxHP && atk.type == dmgTypes.heal) currentHP = maxHP;
        }
        else if (defense < atk.amount)
        {
            currentHP -= (atk.amount - defense);
            yield return Message.SendToBoard(mySide, "Hit", new HitData(mySide, System.Array.IndexOf(array[mySide], gameObject), atk));
        }
        if (currentHP < 1)
        {
            int index = Array.IndexOf(array[mySide], gameObject);
            if(index > -1) array[mySide][index] = controller.empty[mySide];
            
            if (index > 4 && array[mySide][index - 5] == controller.empty[mySide])
            {
                array[mySide][index - 5].GetComponent<Warunit>().statuses.Remove(buff.GetComponent<DmgBuff>());
            }
            Destroy(buff);
            foreach (Burn b in statuses.Where(b => b != null && b.effect == EffectNames.Burn))
            {
                controller.burn.Add(b);
                b.transform.SetParent(null, true);
            }
            yield return null;
            if (controller.empty[mySide].GetComponent<Players>().type == 4) controller.empty[mySide].GetComponent<Myths>().corpses++;
            if (controller.empty[otherSide].GetComponent<Players>().type == 4) controller.empty[otherSide].GetComponent<Myths>().corpses++;
            Instantiate(death, transform.position, new Quaternion());
            yield return Message.SendToAll(mySide, "Kill", new KillData(atk.attacker, mySide, System.Array.IndexOf(array[mySide], gameObject)));
            Hide();
        }
        yield return null;
    }
    public override IEnumerator OnMoved()
    {
        int index = System.Array.IndexOf(array[mySide], gameObject);
        if (index > 4 && array[mySide][index - 5] == controller.empty[mySide])
        {
            array[mySide][index] = controller.empty[mySide];
            array[mySide][index - 5] = gameObject;
            transform.position = PositionByIndex.GetPosition(mySide, index - 5);
        }
        else if (index > 4)
        {
            buff = Instantiate(controller.effectCarrier, array[mySide][index - 5].transform);
            buff.AddComponent<DmgBuff>();
            buff.GetComponent<DmgBuff>().power = 1;
            array[mySide][index - 5].GetComponent<Unit>().statuses.Add(buff.GetComponent<DmgBuff>());
            yield return Message.SendToBoard(mySide, "Status", new StatusData(mySide, index - 5, true, buff));
        }
        yield return null;
    }
}
using UnityEngine;

public class ColorIndication : MonoBehaviour
{
    SpriteRenderer renderer;
    Robots robots;
    public int color;

    public void Start()
    {
        renderer = GetComponent<SpriteRenderer>();
        robots = GetComponentInParent<Robots>();
    }

    private void Update()
    {
        renderer.enabled = robots.colors[color] > 0;
    }
}
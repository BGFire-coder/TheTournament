using TMPro;
using UnityEngine;

public class AmmoShowing : MonoBehaviour
{
    War war;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        war = GetComponentInParent<War>();
    }

    private void Update()
    {
        text.text = war.ammo.ToString();
    }
}
using TMPro;
using UnityEngine;

public class EnergyShowing : MonoBehaviour
{
    Wilds wilds;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        wilds = GetComponentInParent<Wilds>();
    }

    private void Update()
    {
        text.text = wilds.energy.ToString();
    }
}
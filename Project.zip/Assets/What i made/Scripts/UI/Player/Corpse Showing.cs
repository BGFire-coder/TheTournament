using TMPro;
using UnityEngine;

public class CorpseShowing : MonoBehaviour
{
    Myths myths;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        myths = GetComponentInParent<Myths>();
    }

    private void Update()
    {
        text.text = myths.corpses.ToString();
    }
}
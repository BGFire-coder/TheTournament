using UnityEngine;

public class PlayerBackground : MonoBehaviour
{
    public Sprite[] backgrounds = new Sprite[4];
    Color[] darkness = new Color[]{ new Color(1, 1, 1, 1), new Color(0.5f, 0.5f, 0.9f, 1) };
    Wilds type;

    void Start()
    {
        GetComponent<SpriteRenderer>().sprite = backgrounds[GetComponentInParent<Players>().type - 1];
        if (GetComponentInParent<Players>().type == 2) type = GetComponentInParent<Wilds>();
    }

    void Update()
    {
        if(type != null) GetComponent<SpriteRenderer>().color = darkness[type.day];
    }
}
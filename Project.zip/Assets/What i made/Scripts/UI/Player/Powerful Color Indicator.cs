using Unity.VisualScripting;
using UnityEngine;

public class PowerfulColorIndication : MonoBehaviour
{
    SpriteRenderer renderer;
    Robots robots;
    public int color;
    Color myColor;
    float alpha;

    public void Start()
    {
        renderer = GetComponent<SpriteRenderer>();
        robots = GetComponentInParent<Robots>();
        switch(color)
        {
            case 0:
            {
                myColor = new Color(255, 0, 0);
                break;
            }
            case 1:
                {
                    myColor = new Color(255, 255, 0);
                    break;
                }
            case 2:
                {
                    myColor = new Color(0, 255, 0);
                    break;
                }
            case 3:
                {
                    myColor = new Color(0, 0, 255);
                    break;
                }
        }
    }

    private void Update()
    {
        if (robots.colors[color] < 2) alpha = 0;
        else if (robots.colors[color] == 2) alpha = 0.5f;
        else if (robots.colors[color] == 3) alpha = 1;
        renderer.color = new Color(myColor.r, myColor.g, myColor.b, alpha);
    }
}
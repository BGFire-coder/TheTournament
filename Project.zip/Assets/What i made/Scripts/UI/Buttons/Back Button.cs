using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Back : MonoBehaviour
{
    void OnMouseDown()
    {
        if (SceneManager.GetActiveScene().name == "Deck editing") SceneManager.LoadScene("Deck selection");
        else SceneManager.LoadScene("Title screen");
    }

    void OnMouseEnter()
    {
        GetComponentInParent<TextMeshPro>().color = Color.white;
    }

    void OnMouseExit()
    {
        GetComponentInParent<TextMeshPro>().color = Color.black;
    }
}
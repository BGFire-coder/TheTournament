using UnityEngine;
using UnityEngine.SceneManagement;

public class ExitButton : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[3];

    private void Awake()
    {
        if (SaveSystem.save.decks.Count == 0) Destroy(gameObject);
    }

    void OnMouseEnter()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[1];
    }

    void OnMouseExit()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[0];
    }

    void OnMouseDown()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[2];
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
        Application.Quit();
        #endif
    }
}
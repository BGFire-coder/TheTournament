using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectButton : MonoBehaviour
{
    void OnMouseEnter()
    {
        GetComponentInChildren<TextMeshPro>().color = Color.white;
    }

    void OnMouseExit()
    {
        GetComponentInChildren<TextMeshPro>().color = Color.black;
    }

    void OnMouseDown()
    {
        DeckSave selected = transform.parent.GetComponentInParent<DeckSelection>().deck;
        Deck.decks[0] = selected;
        SaveSystem.save.chosenDeck = SaveSystem.save.decks.IndexOf(selected);
        SaveSystem.instance.Save();
        transform.parent.gameObject.SetActive(false);
    }
}
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Collections;

public class Save : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[2];
    string oldName;

    void OnEnable()
    {
        oldName = DeckManager.deck.name;
    }

    void OnMouseDown()
    {
        DeckManager.deck.name = DeckManager.deck.name.ToUpper().Trim(' ');
        if(CheckDeckValidity())
        {
            if(DeckManager.creating)
            {
                SaveSystem.save.decks.Add(DeckManager.deck);
                SaveSystem.instance.Save();
                DeckManager.creating = false;
            }
            else
            {
                DeckSave newSave = SaveSystem.save.decks.First(x => x.name == oldName);
                SaveSystem.save.decks[SaveSystem.save.decks.IndexOf(newSave)] = DeckManager.deck;
                SaveSystem.instance.Save();
            }
            GetComponent<SpriteRenderer>().sprite = sprites[1];
            StartCoroutine(Wait());
        }
    }

    void OnMouseEnter()
    {
        if(CheckDeckValidity()) GetComponentInParent<TextMeshPro>().color = Color.white;
    }

    void OnMouseExit()
    {
        GetComponentInParent<TextMeshPro>().color = Color.black;
        GameObject.Find("Information").GetComponent<TextMeshPro>().text = "";
    }

    bool CheckDeckValidity()
    {
        TextMeshPro info = GameObject.Find("Information").GetComponent<TextMeshPro>();
        info.text = "";
        bool valid = true;
        if (DeckManager.deck.type == 4)
        {
            if (DeckManager.deck.specialCards[0] == -1)
            {
                info.text = info.text + "Book not chosen";
                valid = false;
            }
            if (DeckManager.deck.cards.Contains(-1))
            {
                if (info.text == "") info.text = $"Deck size is lower than required. You should have {DeckManager.deckSize - 1} cards in the deck";
                else info.text = info.text + $"\n\nDeck size is lower than required. You should have {DeckManager.deckSize - 1} cards in the deck";
                valid = false;
            }
        }
        else
        {
            if (DeckManager.deck.type == 3)
            {
                if (!DeckManager.deck.specialCards.Contains(1))
                {
                    info.text = "You haven't chosen any batteries";
                    valid = false;
                }
            }
            if (DeckManager.deck.cards.Contains(-1))
            {
                if (info.text == "") info.text = $"Deck size is lower than required. You should have {DeckManager.deckSize} cards in the deck";
                else info.text = info.text + $"\n\nDeck size is lower than required. You should have {DeckManager.deckSize} cards in the deck";
                valid = false;
            }
            
        }
        if (DeckManager.deck.name == "" || DeckManager.deck.name == null)
        {
            if (info.text == "") info.text = "Deck doesn't have a name";
            else info.text = info.text + "\n\nDeck doesn't have a name";
            valid = false;
        }
        if ((DeckManager.creating || (!DeckManager.creating && DeckManager.deck.name != oldName)) && SaveSystem.save.decks.Where(x => DeckManager.deck.name == x.name).Count() > 0)
        {
            if (info.text == "") info.text = "A deck with the same name already exists";
            else info.text = info.text + "\n\nA deck with the same name already exists";
            valid = false;
        }
        return valid;
    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(0.2f);
        GetComponent<SpriteRenderer>().sprite = sprites[0];
    }
}
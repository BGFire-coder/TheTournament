using UnityEngine;
using UnityEngine.SceneManagement;

public class StartButton : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[3];

    private void Awake()
    {
        if(SaveSystem.save.decks.Count == 0) Destroy(gameObject);
    }

    void OnMouseEnter()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[1];
    }

    void OnMouseExit()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[0];
    }

    void OnMouseDown()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[2];
        Time.timeScale = 1;
        SceneManager.LoadScene("Preparation");
    }
}
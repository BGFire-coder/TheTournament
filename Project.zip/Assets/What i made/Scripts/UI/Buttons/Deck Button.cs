using UnityEngine;
using UnityEngine.SceneManagement;

public class DeckButton : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[3];
    void OnMouseEnter()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[1];
    }

    void OnMouseExit()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[0];
    }

    void OnMouseDown()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[2];
        SceneManager.LoadScene("Deck selection");
    }
}
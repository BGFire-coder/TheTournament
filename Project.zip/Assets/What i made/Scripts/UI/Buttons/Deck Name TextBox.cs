using TMPro;
using UnityEngine;

public class DeckNameInput : MonoBehaviour
{
    void OnEnable()
    {
        GetComponent<TMP_InputField>().text = DeckManager.deck.name;
    }

    public void EnterName(string name)
    {
        DeckManager.deck.name = name;
    }
}
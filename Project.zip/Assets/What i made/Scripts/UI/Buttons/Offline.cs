﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PVЕButton : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[3];

    void OnMouseEnter()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[1];
    }

    void OnMouseExit()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[0];
    }

    IEnumerator OnMouseDown()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[2];
        DontDestroyOnLoad(gameObject);
        SceneManager.LoadScene("Battle");
        yield return new WaitUntil(() => SceneManager.GetActiveScene().name == "Battle");
        GameObject.Find("EndTurnButton").GetComponent<EndTurn>().mode = 0;
        Destroy(gameObject);
    }
}
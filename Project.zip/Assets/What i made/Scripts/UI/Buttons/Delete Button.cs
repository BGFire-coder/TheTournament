using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeleteButton : MonoBehaviour
{
    void OnMouseEnter()
    {
        GetComponentInChildren<TextMeshPro>().color = Color.white;
    }

    void OnMouseExit()
    {
        GetComponentInChildren<TextMeshPro>().color = Color.black;
    }

    void OnMouseDown()
    {
        SaveSystem.save.decks.Remove(transform.parent.GetComponentInParent<DeckSelection>().deck);
        if (SaveSystem.save.chosenDeck == DeckSelection.allObjects.IndexOf(transform.parent.GetComponentInParent<DeckSelection>()) && SaveSystem.save.decks.Count > 0) SaveSystem.save.chosenDeck = 0;
        DeckSelection.allObjects.Remove(transform.parent.GetComponentInParent<DeckSelection>());
        foreach (DeckSelection ds in DeckSelection.allObjects) ds.Move();
        SaveSystem.instance.Save();
        Destroy(transform.parent.parent.gameObject);
    }
}
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Collections;
using System.IO;

public class CreateAccount : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[2];

    void OnMouseDown()
    {
        if (CheckNameValidity())
        {
            SaveSystem.save = new SaveObject();
            SaveSystem.save.name = GameObject.Find("Name").GetComponent<TMP_InputField>().text;
            SaveSystem.instance.Save();
            SceneManager.LoadScene("Title screen");
        }
    }

    void OnMouseEnter()
    {
        if (CheckNameValidity()) GetComponent<SpriteRenderer>().sprite = sprites[1];
    }

    void OnMouseExit()
    {
        GetComponent<SpriteRenderer>().sprite = sprites[0];
    }

    bool CheckNameValidity()
    {
        return GameObject.Find("Name").GetComponent<TMP_InputField>().text != "";
    }
}
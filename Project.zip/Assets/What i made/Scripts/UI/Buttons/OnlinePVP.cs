using System;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;

public class PVPButton : MonoBehaviour
{
    public Sprite[] sprites = new Sprite[4];

    void Awake()
    {
        Ping();
    }

    async Task Ping()
    {
        
        CancellationTokenSource token = new CancellationTokenSource(30);
        while (true)
        {
            TcpClient client = new TcpClient();
            try
            {
                
                Task timeout = Task.Delay(1000);
                Task ping = client.ConnectAsync("95.168.240.43", 443);
                Task finished = await Task.WhenAny(ping, timeout);
                if (timeout.IsCompleted)
                {
                    client.Close();
                    GetComponentInChildren<TextMeshPro>().text = "Unavailable";
                    GetComponent<SpriteRenderer>().sprite = sprites[3];
                }
                else
                {
                    GetComponentInChildren<TextMeshPro>().text = "Online PVP";
                    GetComponent<SpriteRenderer>().sprite = sprites[0];
                    await client.GetStream().WriteAsync(new byte[1] { 1 });
                    client.Close();
                }
            }
            catch (Exception ex)
            {
                client.Close();
                GetComponentInChildren<TextMeshPro>().text = "Unavailable";
                GetComponent<SpriteRenderer>().sprite = sprites[3];
            }
            await Task.Delay(1000);
        }
    }

    void OnMouseEnter()
    {
        if(GetComponent<SpriteRenderer>().sprite != sprites[3]) GetComponent<SpriteRenderer>().sprite = sprites[1];
    }

    void OnMouseExit()
    {
        if (GetComponent<SpriteRenderer>().sprite != sprites[3]) GetComponent<SpriteRenderer>().sprite = sprites[0];
    }

    void OnMouseDown()
    {
        if (GetComponent<SpriteRenderer>().sprite != sprites[3])
        {
            GetComponent<SpriteRenderer>().sprite = sprites[2];
            Destroy(GameObject.Find("PVE"));
            Communication.StartConnection();
            Destroy(gameObject);
        }
    }
}
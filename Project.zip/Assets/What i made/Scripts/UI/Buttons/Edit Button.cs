using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EditButton : MonoBehaviour
{
    void OnMouseEnter()
    {
        GetComponentInChildren<TextMeshPro>().color = Color.white;
    }

    void OnMouseExit()
    {
        GetComponentInChildren<TextMeshPro>().color = Color.black;
    }

    void OnMouseDown()
    {
        DeckManager.deck = transform.parent.GetComponentInParent<DeckSelection>().deck;
        DeckManager.creating = false;
        SceneManager.LoadScene("Deck editing");
    }
}
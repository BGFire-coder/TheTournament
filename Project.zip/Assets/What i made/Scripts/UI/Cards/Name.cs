using System.Drawing;
using TMPro;
using UnityEngine;
using static Unity.VisualScripting.Member;

public class Names : MonoBehaviour
{
    public void Start()
    {
        GetComponentInParent<Canvas>().worldCamera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
        TextMeshPro txt = GetComponent<TextMeshPro>();
        txt.text = transform.parent.parent.name.Remove(transform.parent.parent.name.Length - 7);
        txt.alignment = TextAlignmentOptions.Center;
        txt.fontSize = 0.5f;
        txt.fontStyle = FontStyles.UpperCase;
        switch (GetComponentInParent<Basecard>().type)
        {
            case 1:
                {
                    txt.color = UnityEngine.Color.black;
                    break;
                }
            case 2:
                {
                    if (GetComponentInParent<Wildsunit>() != null && GetComponentInParent<Wildsunit>().upgrade != 2) txt.color = UnityEngine.Color.black;
                    else txt.color = UnityEngine.Color.white;
                    break;
                }
            case 3:
                {
                    txt.color = UnityEngine.Color.black;
                    break;
                }
            case 4:
                {
                    txt.color = UnityEngine.Color.black;
                    break;
                }
            case 5:
                {
                    txt.color = UnityEngine.Color.white;
                    break;
                }
            case 6:
                {
                    txt.color = UnityEngine.Color.black;
                    break;
                }
        }
        txt.sortingOrder = 10;
        GetComponent<RectTransform>().localPosition.Set(0, 0.34f, -0.001f);
    }

    public void Upgraded()
    {
        GetComponent<TextMeshPro>().color = UnityEngine.Color.white;
    }

    public void UpgradeRemoved() { GetComponent<TextMeshPro>().color = UnityEngine.Color.black; }
}
using UnityEngine;

public class MaskingCharging : MonoBehaviour
{
    Mythsunit source;

    private void Start()
    {
        source = GetComponentInParent<Mythsunit>();
    }

    void Update()
    {
        transform.localPosition = new Vector3(0, 0.75f - (float)(0.75f / source.charges * (source.charges - source.currentcharges)), 0);
        transform.localScale = new Vector3(1, 1.5f / (float)source.charges * (source.charges - source.currentcharges), 1);
    }
}

using TMPro;
using UnityEngine;

public class EnergyCost : MonoBehaviour
{
    IWilds source;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        source = transform.parent.parent.parent.GetComponentInParent<IWilds>();
        text.fontSize = 1.1f;
        if ((GetComponentInParent<Wildsunit>() != null && GetComponentInParent<Wildsunit>().upgrade != 2) || GetComponentInParent<Wildsunit>() == null) text.color = Color.black;
        else text.color = Color.white;
    }

    public void Upgraded()
    {
        text.color = Color.white;
    }

    void Update()
    {
        text.text = source.EnergyCost.ToString();
    }
}
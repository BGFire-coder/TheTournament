using TMPro;
using UnityEngine;

public class BloodCost : MonoBehaviour
{
    IWilds source;
    Basecard card;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        source = transform.parent.parent.parent.GetComponentInParent<IWilds>();
        card = (Basecard)source;
        text.fontSize = 1.1f;
        if ((GetComponentInParent<Wildsunit>() != null && GetComponentInParent<Wildsunit>().upgrade != 2) || GetComponentInParent<Wildsunit>() == null) text.color = Color.black;
        else text.color = Color.white;
    }

    public void Upgraded()
    {
        text.color = Color.white;
    }

    void Update()
    {
        if (card.pile == 1) Destroy(transform.parent.parent.gameObject);
        text.text = source.BloodCost.ToString();
    }
}
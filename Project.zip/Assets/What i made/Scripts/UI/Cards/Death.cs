using UnityEngine;

public class Death : MonoBehaviour
{
    void Awake()
    {
        transform.localScale = Vector3.one * 1.2f;
    }

    public void Finish()
    {
        Destroy(gameObject);
    }
}
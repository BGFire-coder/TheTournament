using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Attack : MonoBehaviour
{
    public int target;
    public int beggining;
    public int side;
    public bool finished = false;

    void Start()
    {
        Vector3 dir = PositionByIndex.GetPosition(side, beggining) - PositionByIndex.GetPosition(1 - side, target);
        Vector3 center = (PositionByIndex.GetPosition(side, beggining) + PositionByIndex.GetPosition(1 - side, target)) / 2f;
        float angle = Mathf.Atan2(dir.x, -dir.y) * Mathf.Rad2Deg;
        transform.position = center + transform.forward * 2 + new Vector3(0, 0, -2);
        transform.rotation = Quaternion.Euler(0, 0, angle);
        transform.localScale = Vector3.one * 2;
        GetComponent<SpriteRenderer>().sortingOrder = 3;
    }

    public void Finish()
    {
        finished = true;
    }

    public void End()
    {
        Destroy(gameObject);
    }
}
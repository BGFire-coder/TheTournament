using TMPro;
using UnityEngine;

public class Crit1 : MonoBehaviour
{
    TextMeshPro text;
    Unit source;

    private void Start()
    {
        text = GetComponent<TextMeshPro>();
        source = GetComponentInParent<Unit>();
        text.color = Color.black;
        text.fontSize = 0.7f;
        switch (GetComponentInParent<Unit>().type)
        {
            case 2:
                {
                    if (GetComponentInParent<Wildsunit>().upgrade != 2) text.color = Color.black;
                    else text.color = Color.white;
                    break;
                }
            case 5:
                {
                    text.color = Color.white;
                    break;
                }
            default:
                {
                    break;
                }
        }
    }

    public void Upgraded() { text.color = Color.white; }

    void Update() { text.text = source.currentCrit.ToString(); }

    public void UpgradeRemoved() { text.color = Color.black; }
}

using UnityEngine;

public class Damage : MonoBehaviour
{
    private void Start()
    {
        GetComponent<Animator>().speed = 1.2f;
        transform.localPosition = new Vector3(0, -0.375f, -1);
        GetComponent<SpriteRenderer>().sortingOrder = 5;
        transform.SetParent(null, true);
    }

    public void Finish()
    {
        Destroy(gameObject);
    }
}
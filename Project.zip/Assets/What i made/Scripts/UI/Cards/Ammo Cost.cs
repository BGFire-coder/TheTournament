using TMPro;
using UnityEngine;

public class AmmoCost : MonoBehaviour
{
    IWar source;
    Basecard card;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        source = transform.parent.parent.GetComponentInParent<IWar>();
        card = (Basecard)source;
        text.fontSize = 2f;
        text.color = Color.black;
        text.text = source.AmmoCost.ToString();
    }

    void Update()
    {
        if (card.pile == 1) Destroy(transform.parent.gameObject);
    }
}
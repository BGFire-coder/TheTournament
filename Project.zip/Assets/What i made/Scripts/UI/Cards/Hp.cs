using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class Hp : MonoBehaviour
{
    TextMeshPro text;
    Unit source;
    private void Start()
    {
        text = GetComponent<TextMeshPro>();
        source = transform.parent.parent.GetComponentInParent<Unit>();
        text.color = Color.black;
        text.fontSize = 0.7f;
        switch (GetComponentInParent<Unit>().type)
        {
            case 2:
                {
                    if (GetComponentInParent<Wildsunit>().upgrade != 2) text.color = Color.black;
                    else text.color = Color.white;
                    break;
                }
            case 5:
                {
                    text.color = Color.white;
                    break;
                }
            default:
                {
                    break;
                }
        }
    }

    public void Upgraded()
    {
        text.color = Color.white;
    }

    void Update()
    {
        if(source.currentHP > 0) text.text = source.currentHP.ToString();
    }

    public void UpgradeRemoved() { text.color = Color.black; }
}

using TMPro;
using UnityEngine;

public class CorpseCost : MonoBehaviour
{
    IMyths source;
    Basecard card;
    TextMeshPro text;

    public void Start()
    {
        text = GetComponent<TextMeshPro>();
        source = transform.parent.parent.GetComponentInParent<IMyths>();
        card = (Basecard)source;
        text.fontSize = 2f;
        text.color = Color.black;
        text.text = source.CorpseCost.ToString();
    }

    void Update()
    {
        if (card.pile == 1) Destroy(transform.parent.gameObject);
    }
}
using UnityEngine;

public class MaskingLifetime : MonoBehaviour
{
    Warunit source;

    private void Start()
    {
        source = GetComponentInParent<Warunit>();
    }

    void Update()
    {
        transform.localPosition = new Vector3(0, 0.75f - (float)(0.75f / source.maxLifetime * (source.maxLifetime - source.currentLifetime)), 0);
        transform.localScale = new Vector3(1, 1.5f / (float)source.maxLifetime * (source.maxLifetime - source.currentLifetime), 1);
    }
}

using UnityEngine;

public class CAmeraScaling : MonoBehaviour
{
    void Awake()
    {
        Camera camera = GetComponent<Camera>();
        float targetRatio = 16f / 9f;
        float screenRatio = (float)Screen.width / (float)Screen.height;

        if (screenRatio > targetRatio) camera.orthographicSize = 4f;
        else camera.orthographicSize = (7f / screenRatio);

        float scaleHeight = screenRatio / targetRatio;
        if (scaleHeight < 1.0f)
        {
            Rect rect = camera.rect;
            rect.width = 1;
            rect.height = scaleHeight;
            rect.x = 0;
            rect.y = (1 - scaleHeight) / 2;
            camera.rect = rect;
        }
        else
        {
            float scaleWidth = 1.0f / scaleHeight;
            Rect rect = camera.rect;
            rect.width = scaleWidth;
            rect.height = 1;
            rect.x = (1 - scaleWidth) / 2;
            rect.y = 0;
            camera.rect = rect;
        }
    }
}

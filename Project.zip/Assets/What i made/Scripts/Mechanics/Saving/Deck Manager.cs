using NUnit.Framework;
using System.Collections.Generic;
using UnityEngine;

public class DeckManager : MonoBehaviour
{
    public static bool creating;
    public static int deckSize = 11;

    public GameObject[] unlocked = new GameObject[6];
    public GameObject[] locked = new GameObject[5];
    public GameObject info;
    public GameObject save;
    public GameObject deckName;

    public static DeckSave deck;
    CardLibrary cardLibrary;
    List<GameObject> types = new List<GameObject>();

    void Start()
    {
        cardLibrary = GameObject.Find("Card Library").GetComponent<CardLibrary>();
        info.SetActive(false);
        //for later
        if (creating)
        {
            for (int i = 0; i < SaveSystem.save.wins + 1; i++) types.Add(Instantiate(unlocked[i]));
            for (int i = SaveSystem.save.wins; i < 5; i++) types.Add(Instantiate(locked[i]));
            deck = new DeckSave();
        }
        else Cards();
    }

    public void Cards()
    {
        if(types.Count > 0)
        {
            for(int i = 5; i > -1; i--)
            {
                Destroy(types[i]);
                types.RemoveAt(i);
            }
        }
        info.SetActive(true);
        save.SetActive(true);
        deckName.SetActive(true);
        if (creating)
        {
            deck.cards = new int[deckSize];
            deck.specialCards = new int[0];
            if(deck.type == 4)
            {
                deck.cards = new int[deckSize - 1];
                deck.specialCards = new int[1];
                deck.specialCards[0] = -1;
            }
            for (int i = 0; i < deck.cards.Length; i++) deck.cards[i] = -1;
            if (deck.type == 3) deck.specialCards = new int[4];
        }
        else if ((deck.cards.Length < deckSize && deck.type != 4) || (deck.cards.Length < deckSize - 1 && deck.type == 4))
        {
            int[] newDeck = new int[deckSize];
            deck.cards.CopyTo(newDeck, 0);
            newDeck[newDeck.Length - 1] = -1;
            deck.cards = newDeck;
        }
        int position = 0;
        for (int i = 0; i < cardLibrary.allCards[deck.type - 1].Count; i++)
        {
            GameObject instance = Instantiate(cardLibrary.allCards[deck.type - 1][i]);
            BaseDeckCard card = instance.AddComponent<BaseDeckCard>();
            card.position = position;
            card.save = deck;
            position++;
        }
    }
}
using System;

[Serializable]
public class DeckSave
{
    public string name;
    public int type;
    public int[] cards;
    public int[] specialCards;
}
using System.Collections.Generic;

public class SaveObject
{
    public string name;
    public int wins;
    public bool[] unlocks;
    public int chosenDeck;
    public List<DeckSave> decks = new List<DeckSave>();
}
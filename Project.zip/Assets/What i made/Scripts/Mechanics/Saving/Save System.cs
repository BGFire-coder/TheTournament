using NUnit.Framework;
using System.Collections.Generic;
using System.Data;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveSystem : MonoBehaviour
{
    public static SaveObject save;
    public static SaveSystem instance;
    public string path;

    void Awake()
    {
        if (instance != null) Destroy(gameObject);
        instance = this;
        DontDestroyOnLoad(gameObject);
        path = Path.Combine(Application.persistentDataPath, "save.json");
        if(File.Exists(path))
        {
            string json = File.ReadAllText(path);
            save = JsonUtility.FromJson<SaveObject>(json);
            if(save.decks.Count > 0)
            {
                Deck.decks[0] = save.decks[save.chosenDeck];
            }
            
            SceneManager.LoadScene("Title screen");
        }
        else GameObject.Find("Background").transform.position = new Vector3(0, 0, 3);
    }

    public void Save()
    {
        string json = JsonUtility.ToJson(save);
        File.WriteAllText(path, json);
    }
}
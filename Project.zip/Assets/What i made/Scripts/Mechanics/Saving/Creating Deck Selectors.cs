using UnityEngine;
using System.Collections.Generic;

public class CreateSelectors : MonoBehaviour
{
    public GameObject[] selectors = new GameObject[6];

    void Start()
    {
        DeckSelection.startingIndex = 0;
        DeckSelection.allObjects = new List<DeckSelection>();
        for (int i = 0; i < SaveSystem.save.decks.Count; i++)
        {
            GameObject instance = Instantiate(selectors[SaveSystem.save.decks[i].type - 1], new Vector3(10, 10, 0), new Quaternion());
            DeckSelection selection = instance.GetComponent<DeckSelection>();
            selection.deck = SaveSystem.save.decks[i];
            DeckSelection.allObjects.Add(selection);
            selection.Move();
        }
    }

    void Update()
    {
        if (Input.mouseScrollDelta.y < -0.4f)
        {
            if(DeckSelection.startingIndex < SaveSystem.save.decks.Count - 5) DeckSelection.startingIndex++;
            foreach(DeckSelection ds in DeckSelection.allObjects) ds.Move();
        }
        if (Input.mouseScrollDelta.y > 0.4f)
        {
            if(DeckSelection.startingIndex > 0) DeckSelection.startingIndex--;
            foreach (DeckSelection ds in DeckSelection.allObjects) ds.Move();
        }
    }
}
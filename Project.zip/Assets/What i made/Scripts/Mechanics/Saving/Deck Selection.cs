using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DeckSelection : MonoBehaviour
{
    static Vector3[] positions = { new Vector3(0, 2, -1), new Vector3(3, 2, -1), new Vector3(-3, -2, -1), new Vector3(0, -2, -1), new Vector3(3, -2, -1) };
    public static int startingIndex = 0;
    public static List<DeckSelection> allObjects = new List<DeckSelection>();
    public DeckSave deck;

    void Start()
    {
        transform.GetChild(0).GetComponentInChildren<TextMeshPro>().text = deck.name;
    }

    public void Move()
    {
        int index = allObjects.IndexOf(this);
        if(index - startingIndex > -1 && index - startingIndex < 5) transform.position = positions[index - startingIndex];
        else transform.position = new Vector3(10, 10, 0);
    }

    void OnMouseDown()
    {
        transform.Find("Options").gameObject.SetActive(true);
    }
}
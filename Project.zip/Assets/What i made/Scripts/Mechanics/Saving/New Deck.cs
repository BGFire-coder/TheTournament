using UnityEngine;
using UnityEngine.SceneManagement;

public class NewDeck : MonoBehaviour
{
    public Sprite idle;
    public Sprite selected;
    public Sprite clicked;

    void OnMouseDown()
    {
        GetComponent<SpriteRenderer>().sprite = clicked;
        DeckManager.creating = true;
        SceneManager.LoadScene("Deck editing");
    }

    void OnMouseEnter()
    {
        GetComponent<SpriteRenderer>().sprite = selected;
    }

    void OnMouseExit()
    {
        GetComponent<SpriteRenderer>().sprite = idle;
    }
}
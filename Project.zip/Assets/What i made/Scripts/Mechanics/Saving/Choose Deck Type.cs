using UnityEngine;

public class ChooseType : MonoBehaviour
{
    public int type;

    void OnMouseDown()
    {
        DeckManager.deck.type = type;
        GameObject.Find("Deck Manager").GetComponent<DeckManager>().Cards();
    }
}
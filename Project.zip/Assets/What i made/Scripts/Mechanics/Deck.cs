public static class Deck
{
    public static DeckSave[] decks = new DeckSave[2]{new DeckSave(), new DeckSave(){type = 2, cards = new int[] {12, 7, 9, 13, 11, 10, 0, 8, 5, 6}, name = "Bot"}};
}
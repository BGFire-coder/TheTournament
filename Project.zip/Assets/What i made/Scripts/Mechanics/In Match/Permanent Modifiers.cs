using UnityEngine;

public class PermanentModifiers
{
    public int HPmodifier;
    public int ATKmodifier;
    public int Critmodifier;
}

public class WarModifiers : PermanentModifiers
{
    public int cycles;
}

public class WildsModifiers : PermanentModifiers
{
    public int upgraded;
}

public class RobotsModifiers : PermanentModifiers
{
    public int timesCombined;
    public int[] previousColors;
}

public class MythsModifiers : PermanentModifiers
{
    public int chargeRate;
    public int charges;
    public int healing;
}
using Unity.VisualScripting;
using UnityEngine;

public class IndexPicker : MonoBehaviour
{
    public Basecard reciever;
    public UpgradeAltar altar;
    public int index;

    void Start()
    {
        transform.position += new Vector3(0, 0, -3);
        if(GetComponent<SpriteRenderer>() != null) GetComponent<SpriteRenderer>().sortingOrder = 3;
    }

    private void OnMouseDown()
    {
        if (reciever == null && altar != null) altar.pickedIndex = index;
        else if(reciever != null) reciever.pickedIndex = index;
    }
}
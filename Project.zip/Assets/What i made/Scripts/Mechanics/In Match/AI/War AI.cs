using System.Linq;
using System.Collections;

public class WarAI : AI
{
    public WarAI(Players player, EndTurn end) : base(player, end)
    {
    }
}
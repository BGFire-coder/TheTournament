using System.Linq;
using System.Collections;
using UnityEngine;

public class MythsAI : AI
{
    public MythsAI(Players player, EndTurn end) : base(player, end)
    {
    }

    public override IEnumerator MyTurn()
    {
        foreach (GameObject go in controller.board[1].Where(x => x.GetComponent<Mythsunit>() != null)) yield return go.GetComponent<Mythsunit>().StartCoroutine(UseAbility(go.GetComponent<Mythsunit>()));
        yield return base.MyTurn();
    }

    public IEnumerator UseAbility(Mythsunit unit)
    {
        unit.OnMouseDown();
        yield return new WaitForSeconds(0.2f);
        yield return new WaitUntil(() => controller.runningProcesses == 0);
    }
}
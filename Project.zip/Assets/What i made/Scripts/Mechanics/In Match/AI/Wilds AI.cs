using NUnit.Framework.Internal;
using System.Collections;
using System.Linq;
using UnityEngine;

public class WildsAI : AI
{
    public WildsAI(Players player, EndTurn end) : base(player, end)
    {
    }

    public override IEnumerator MyTurn()
    {
        bool playAvailbale = false;
        bool upgraded = false;
        if (me.hand.Where(x => x.GetComponent<Basecard>().CheckIfPlayable() && x.GetComponent<Basecard>().GetTargets().Count > 0).ToList().Count > 0) playAvailbale = true;
        if (me.hand.Where(x => x.GetComponent<Wildsunit>() != null && x.GetComponent<Wildsunit>().upgrade == 0).ToList().Count > 0 && me.hand.Count > 1 && !upgraded) playAvailbale = true;
        while (playAvailbale)
        {
            GameObject available = me.hand.FirstOrDefault(x => x.GetComponent<Basecard>().CheckIfPlayable() && x.GetComponent<Basecard>().GetTargets().Count > 0);
            if(available != null)
            {
                Basecard playable = available.GetComponent<Basecard>();
                yield return playable.StartCoroutine(ChanceHandler.MultiChoice(playable.GetTargets()));
                int index = playable.GetTargets()[ChanceValue.value];
                playable.ChangeResources();
                yield return playable.StartCoroutine(playable.Play(index));
            }
            else
            {
                Wildsunit upgrade = me.hand.FirstOrDefault(x => x.GetComponent<Wildsunit>() != null && x.GetComponent<Wildsunit>().upgrade == 0).GetComponent<Wildsunit>();
                yield return upgrade.StartCoroutine(upgrade.Upgrade());
                yield return upgrade.StartCoroutine(ChanceHandler.MultiChoice(me.hand));
                IWilds discarded = me.hand[ChanceValue.value].GetComponent<IWilds>();
                while (discarded == upgrade)
                {
                    yield return upgrade.StartCoroutine(ChanceHandler.MultiChoice(me.hand));
                    discarded = me.hand[ChanceValue.value].GetComponent<IWilds>();
                }
                yield return discarded.DiscardByUpgrade();
                upgraded = true;
            }
            playAvailbale = false;

            yield return new WaitForSeconds(0.5f);
            if (me.hand.Where(x => x.GetComponent<Basecard>().CheckIfPlayable() && x.GetComponent<Basecard>().GetTargets().Count > 0).ToList().Count > 0) playAvailbale = true;
            if (me.hand.Where(x => x.GetComponent<Wildsunit>() != null && x.GetComponent<Wildsunit>().upgrade == 0).ToList().Count > 0 && me.hand.Count > 1 && !upgraded) playAvailbale = true;
        }
        yield return controller.StartCoroutine(controller.End());
    }
}
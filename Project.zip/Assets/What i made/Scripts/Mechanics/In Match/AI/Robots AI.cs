using System.Linq;
using System.Collections;
using UnityEngine;

public class RobotsAI : AI
{
    public RobotsAI(Players player, EndTurn end) : base(player, end)
    {
    }

    public override IEnumerator MyTurn()
    {
        Robots robots = me.GetComponent<Robots>();
        for(int i = robots.batteries.Count - 1; i > -1; i--) if (robots.colors[robots.batteries[i].GetComponent<Battery>().color] < 1) yield return robots.batteries[i].GetComponent<Battery>().StartCoroutine(robots.batteries[i].GetComponent<Battery>().Play(0));
        yield return base.MyTurn();
    }
}
using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class AI
{
    public Players me;
    public EndTurn controller;

    public AI(Players player, EndTurn end)
    {
        me = player;
        controller = end;
    }

    public virtual IEnumerator MyTurn()
    {
        bool playAvailbale = false;
        if (me.hand.Where(x => x.GetComponent<Basecard>().CheckIfPlayable() && x.GetComponent<Basecard>().GetTargets().Count > 0).ToList().Count > 0) playAvailbale = true;
        while(playAvailbale)
        {
            Basecard playable = me.hand.First(x => x.GetComponent<Basecard>().CheckIfPlayable() && x.GetComponent<Basecard>().GetTargets().Count > 0).GetComponent<Basecard>();
            yield return playable.StartCoroutine(ChanceHandler.MultiChoice(playable.GetTargets()));
            int index = playable.GetTargets()[ChanceValue.value];
            playable.ChangeResources();
            yield return playable.StartCoroutine(playable.Play(index));

            playAvailbale = false;

            yield return new WaitForSeconds(0.5f);
            if (me.hand.Where(x => x.GetComponent<Basecard>().CheckIfPlayable() && x.GetComponent<Basecard>().GetTargets().Count > 0).ToList().Count > 0) playAvailbale = true;
        }
        yield return controller.StartCoroutine(controller.End());
    }

    public virtual int ChoiceMaking(int mode, List<int> options)
    {
        if (mode == 1)
        {
            ChanceHandler.MultiChoice(options);
            return options[ChanceValue.value];
        }
        else return 0;
    }
}
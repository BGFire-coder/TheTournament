using UnityEngine;

public class PlayerHpShowcase : MonoBehaviour
{
    Players myPlayer;
    public SpriteRenderer[] renderers = new SpriteRenderer[10];
    Color originalColor;
    public Sprite[] sprites = new Sprite[4];
    void Start()
    {
        myPlayer = GetComponentInParent<Players>();
        foreach (SpriteRenderer sr in renderers)
        {
            sr.sprite = sprites[myPlayer.type - 1];
        }
    }

    public void UpdateVisuals()
    {
        for (int i = 0; i < myPlayer.hp; i++) renderers[i].color = Color.white;
        for(int i = myPlayer.hp; i < 10; i++) renderers[i].color = Color.black;
    }
}
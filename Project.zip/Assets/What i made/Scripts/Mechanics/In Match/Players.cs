using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Players : MonoBehaviour
{
    public int type;
    public int mySide;
    public int hp = 10;
    public List<(GameObject, PermanentModifiers)> drawPile = new List<(GameObject, PermanentModifiers)>();
    public List<GameObject> hand = new List<GameObject>();
    public List<(GameObject, PermanentModifiers)> discardPile = new List<(GameObject, PermanentModifiers)>();
    public Type typeController;
    PlayerHpShowcase hpShowcase;
    System.Type permanents;
    public AI ai;
    EndTurn controller;

    void Awake()
    {
        controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        hpShowcase = GetComponentInChildren<PlayerHpShowcase>();
        type = Deck.decks[mySide].type;
        switch(type)
        {
            case 1:
                {
                    typeController = gameObject.AddComponent<War>();
                    ai = new WarAI(this, controller);
                    permanents = typeof(WarModifiers);
                    break;
                }
            case 2:
                {
                    typeController = gameObject.AddComponent<Wilds>();
                    ai = new WildsAI(this, controller);
                    permanents = typeof(WildsModifiers);
                    break;
                }
            case 3:
                {
                    typeController = gameObject.AddComponent<Robots>();
                    ai = new RobotsAI(this, controller);
                    permanents = typeof(RobotsModifiers);
                    break;
                }
            case 4:
                {
                    typeController = gameObject.AddComponent<Myths>();
                    ai = new MythsAI(this, controller);
                    permanents = typeof(MythsModifiers);
                    break;
                }
        }
        for (int i = 0; i < Deck.decks[mySide].cards.Length; i++) drawPile.Add((controller.library.GetComponent<CardLibrary>().allCards[type - 1][Deck.decks[mySide].cards[i]], (PermanentModifiers)Activator.CreateInstance(permanents)));
        
    }

    public IEnumerator Prepare()
    {
        if (controller.mode == 0) yield return StartCoroutine(ChanceHandler.Order(drawPile));
        if (type == 4)
        {
            Myths myths = (Myths)typeController;
            yield return myths.StartCoroutine(myths.Book());
        }
    }

    public IEnumerator TakeDMG(AttackData data)
    {
        if (data.type == dmgTypes.heal)
        {
            hp += data.amount;
            if (hp > 10) hp = 10;
            hpShowcase.UpdateVisuals();
        }
        else
        {
            hp -= data.amount;
            if (hp > 0) hpShowcase.UpdateVisuals();
            yield return StartCoroutine(Message.SendToSide(mySide, "Damaged", null));
        }
        if (hp < 1)
        {
            if (SaveSystem.save.wins < 3 && mySide == 1)
            {
                SaveSystem.save.wins++;
                SaveSystem.instance.Save();
            }
            if (controller.mode == 1) Communication.forSend.Add(new EnemyEvent() { eventType = EventTypes.matchEnded });
            for (int i = 0; i < 80; i++) Time.timeScale -= 0.01f;
            Communication.isOver = true;
            yield return new WaitForSeconds(0.1f);
            SceneManager.LoadScene("Title screen");
        }
    }

    public IEnumerator Draw(int drawMode)
    {
        if (type != 3 || drawMode == 0)
        {
            if (drawPile.Count == 0 || (type == 1 && drawPile.Count < 3))
            {
                yield return ChanceHandler.Order(discardPile);
                drawPile.AddRange(discardPile);
                discardPile.Clear();
            }
            if(drawPile.Count > 0) yield return typeController.StartCoroutine(typeController.Draw(mySide, hand, drawPile));
        }
        else yield return typeController.StartCoroutine("DrawBattery");
    }

    public IEnumerator FirstDraw()
    {
        yield return typeController.StartCoroutine(typeController.FirstDraw(mySide, hand, drawPile));
    }

    public IEnumerator StartTurn()
    {
        if (drawPile.Count == 0 || (type == 1 && drawPile.Count < 3))
        {
            yield return ChanceHandler.Order(discardPile);
            drawPile.AddRange(discardPile);
            discardPile.Clear();
        }
        yield return typeController.StartCoroutine(typeController.StartTurn(mySide, hand, drawPile));
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EndTurn : MonoBehaviour
{
    public int mode = 1;
    public AI opponent;

    public int turn = 0;
    public GameObject[][] board = new GameObject[2][];
    public int runningProcesses = 0;
    public GameObject effectCarrier;
    public GameObject[] empty = new GameObject[2];
    public List<Burn> burn;
    public GameObject library;
    public int turnsPassed = 0;
    public List<GameObject> disposed = new List<GameObject>();
    public GameObject[] types;
    public GameObject altar;
    public Sprite[] states = new Sprite[3];
    public List<Basecard> activeEffects = new List<Basecard>();

    IEnumerator Start()
    {
        yield return null;
        ChanceHandler.mode = mode;
        if (turn == 1) GetComponent<SpriteRenderer>().enabled = false;
        burn = new List<Burn>();
        GetComponent<SpriteRenderer>().sprite = states[0];
        board[0] = new GameObject[10];
        for(int i = 0; i < 10; i++) board[0][i] = empty[0];
        board[1] = new GameObject[10];
        for (int i = 0; i < 10; i++) board[1][i] = empty[1];
        yield return StartCoroutine(FirstDraw());
        
        if (turn == 1 && mode == 1)
        {
            yield return StartCoroutine(EventQueue.Resolve());
        }
        opponent = empty[1].GetComponent<Players>().ai;
    }

    IEnumerator FirstDraw()
    {
        runningProcesses++;
        yield return new WaitForSeconds(0.5f);
        yield return empty[0].GetComponent<Players>().StartCoroutine(empty[0].GetComponent<Players>().Prepare());
        yield return empty[1].GetComponent<Players>().StartCoroutine(empty[1].GetComponent<Players>().Prepare());
        yield return new WaitForSeconds(0.3f);
        yield return empty[turn].GetComponent<Players>().StartCoroutine(empty[turn].GetComponent<Players>().FirstDraw());
        runningProcesses--;
    }

    void OnMouseEnter()
    {
        if(runningProcesses == 0) GetComponent<SpriteRenderer>().sprite = states[1];
    }

    void OnMouseExit()
    {
        if (runningProcesses == 0) GetComponent<SpriteRenderer>().sprite = states[0];
    }

    void OnMouseDown()
    {
        if (runningProcesses == 0 && turn == 0)
        {
            StartCoroutine(End());
        }
    }

    public IEnumerator End()
    {
        runningProcesses++;
        if(mode == 1 && turn == 0)
        {
            EndEvent endEvent = new EndEvent();
            Communication.forSend.Add(endEvent);
        }
        GetComponent<SpriteRenderer>().enabled = false;
        yield return StartCoroutine(Message.SendToSide(turn, "OnTurnEndBA", null));
        for (int i = 0; i < 5; i++)
        {
            if (board[turn][i] != empty[turn])
            {
                Unit u = board[turn][i].GetComponent<Unit>();
                yield return u.StartCoroutine(u.Attack());
            }
        }
        yield return StartCoroutine(Message.SendToSide(turn, "OnTurnEndAA", null));
        yield return new WaitForSeconds(0.5f);

        turn = 1 - turn;
        turnsPassed++;

        if (turnsPassed > 1) yield return empty[turn].GetComponent<Players>().StartCoroutine(empty[turn].GetComponent<Players>().StartTurn());
        else yield return empty[turn].GetComponent<Players>().StartCoroutine(empty[turn].GetComponent<Players>().FirstDraw());

        for (int i = burn.Count - 1; i > -1; i--) if (burn[i] != null && burn[i].index[0] == turn) yield return burn[i].StartCoroutine(burn[i].OnTurnStart1());

        yield return StartCoroutine(Message.SendToSide(turn, "OnTurnStart1", null));
        yield return StartCoroutine(Message.SendToSide(turn, "OnTurnStart2", null));

        for (int i = disposed.Count - 1; i > -1; i--)
        {
            yield return disposed[i].GetComponent<Basecard>().StartCoroutine(disposed[i].GetComponent<Basecard>().Discard());
            if (disposed.Count == i + 1) disposed.RemoveAt(i);
        }

        if (turn == 1)
        {
            if (mode == 0) yield return StartCoroutine(opponent.MyTurn());
            else
            {
                yield return StartCoroutine(EventQueue.Resolve());
            }
        }
        GetComponent<SpriteRenderer>().enabled = true;
        runningProcesses--;
    }
}
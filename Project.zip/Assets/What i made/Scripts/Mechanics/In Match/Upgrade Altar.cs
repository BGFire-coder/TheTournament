using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public class UpgradeAltar : MonoBehaviour
{
    public GameObject picker;
    EndTurn controller;
    public int mySide;
    public int pickedIndex = -1;

    private void Start()
    {
        controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        mySide = GetComponentInParent<Players>().mySide;
    }

    public void OnMouseDown()
    {
        if (controller.runningProcesses == 0 && controller.turn == mySide && GetComponentInParent<Players>().hand.Where(x => x.GetComponent<Wildsunit>() != null && x.GetComponent<Wildsunit>().upgrade == 0).ToList().Count > 0) StartCoroutine(Upgrade());
    }

    public IEnumerator Upgrade()
    {
        controller.runningProcesses++;
        pickedIndex = -1;
        List<GameObject> indexers = new List<GameObject>();
        List<GameObject> hand = GetComponentInParent<Players>().hand;
        List<GameObject> units = hand.Where(x => x.GetComponent<Wildsunit>() != null && x.GetComponent<Wildsunit>().upgrade == 0).ToList();
        if (hand.Count < 2 && units.Count < 1)
        {
            controller.runningProcesses--;
            yield break;
        }
        int index = 0;
        foreach (GameObject go in units)
        {
            indexers.Add(Instantiate(picker, go.transform.position + new Vector3(0, -0.475f, -0.1f), new Quaternion()));
            indexers[indexers.Count - 1].GetComponent<IndexPicker>().altar = this;
            indexers[indexers.Count - 1].GetComponent<IndexPicker>().index = index;
            indexers[indexers.Count - 1].transform.localScale = new Vector3(1.8f, 1.8f, 1);
            index++;
        }
        IndexPicker empty = GameObject.Find("Empty Click").GetComponent<IndexPicker>();
        empty.altar = this;
        empty.transform.position = new Vector3(0, 0, -2);
        empty.index = 20;
        yield return new WaitUntil(() => pickedIndex > -1);
        for (int i = indexers.Count - 1; i > -1; i--)
        {
            Destroy(indexers[i]);
            indexers.RemoveAt(i);
        }
        empty.transform.position = new Vector3(0, 0, 5);
        empty.altar = null;
        empty.index = 10;
        if(pickedIndex < 20)
        {
            int toUpgrade = pickedIndex;
            GameObject upgraded = units[pickedIndex];
            hand = hand.Where(x => x != upgraded).ToList();
            index = 0;
            pickedIndex = -1;
            foreach (GameObject go in hand)
            {
                indexers.Add(Instantiate(picker, go.transform.position + new Vector3(0, -0.475f, -0.1f), new Quaternion()));
                indexers[indexers.Count - 1].GetComponent<IndexPicker>().altar = this;
                indexers[indexers.Count - 1].GetComponent<IndexPicker>().index = index;
                indexers[indexers.Count - 1].transform.localScale = new Vector3(1.8f, 1.8f, 1);
                index++;
            }
            yield return new WaitUntil(() => pickedIndex > -1);
            for (int i = indexers.Count - 1; i > -1; i--)
            {
                Destroy(indexers[i]);
                indexers.RemoveAt(i);
            }
            GameObject discarded = hand[pickedIndex];
            yield return upgraded.GetComponent<Wildsunit>().StartCoroutine(upgraded.GetComponent<Wildsunit>().Upgrade());
            yield return discarded.GetComponent<Basecard>().StartCoroutine("DiscardByUpgrade");
            if(controller.mode == 1)
            {
                UpgradeEvent upgrade = new UpgradeEvent() { index = toUpgrade, discardIndex = pickedIndex };
                Communication.forSend.Add(upgrade);
            }
        }
        controller.runningProcesses--;
    }
}
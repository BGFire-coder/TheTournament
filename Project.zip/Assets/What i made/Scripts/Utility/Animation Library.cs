using System.Collections.Generic;
using UnityEngine;

public class AnimationLibrary : MonoBehaviour
{
    public GameObject picker;
    public List<GameObject> deaths = new List<GameObject>();
    public List<GameObject> effects = new List<GameObject>();
    public List<GameObject> attacks = new List<GameObject>();
}
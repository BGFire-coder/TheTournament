using System.Collections.Generic;
using UnityEngine;

public class CardLibrary : MonoBehaviour
{
    public List<GameObject> type1 = new List<GameObject>();
    public List<GameObject> type2 = new List<GameObject>();
    public List<GameObject> type3 = new List<GameObject>();
    public List<GameObject> type4 = new List<GameObject>();
    public List<GameObject> type5 = new List<GameObject>();
    public List<GameObject> type6 = new List<GameObject>();
    public List<GameObject> help = new List<GameObject>();

    public List<GameObject>[] allCards = new List<GameObject>[7];

    private void Awake()
    {
        allCards[0] = type1;
        allCards[1] = type2;
        allCards[2] = type3;
        allCards[3] = type4;
        allCards[4] = type5;
        allCards[5] = type6;
        allCards[6] = help;
    }
}
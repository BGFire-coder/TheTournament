using NUnit.Framework;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class Data : MonoBehaviour
{
    public List<int> deck = new List<int>();
    public List<int> eDeck = new List<int>();

    void Start()
    {
        deck = Deck.decks[0].cards.ToList();
        eDeck = Deck.decks[1].cards.ToList();
    }
}

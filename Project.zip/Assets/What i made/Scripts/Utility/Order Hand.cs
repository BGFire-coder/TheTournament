using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public static class OrderHand
{
    public static void Order(List<GameObject> hand, int side)
    {
        for (int i = 0; i < hand.Count; i++)
        {
            hand[i].transform.position = new Vector3((float)(4 - (i + 1) * (8f / (hand.Count + 1))), -2.5f + side * 9, i / -100f );
            hand[i].GetComponent<SortingGroup>().sortingOrder = i;
        }
    }

    public static void OrderBatteries(List<GameObject> hand, List<GameObject> batteries, int side)
    {
        for (int i = 0; i < hand.Count; i++)
        {
            hand[i].transform.position = new Vector3((float)(6f - (i + 1) * (7f / (hand.Count + 1))), -2.5f + side * 9, i / -100f);
            hand[i].GetComponent<SortingGroup>().sortingOrder = i;
        }
        for (int i = 0; i < batteries.Count; i++)
        {
            batteries[i].transform.position = new Vector3((float)(-2.2f - (i + 1) * (3.8f / (hand.Count + 1))), -2.5f + side * 9, i / -100f);
            batteries[i].GetComponent<SortingGroup>().sortingOrder = i;
        }
    }
}
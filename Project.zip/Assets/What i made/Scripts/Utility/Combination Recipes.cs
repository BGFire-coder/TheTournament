using UnityEngine;
using System.Collections.Generic;
using System;
using System.Collections;

public static class CombinationRecipes
{
    static List<(Predicate<GameObject>[], GameObject)> recipes = new List<(Predicate<GameObject>[], GameObject)>();

    public static void Fill(CardLibrary library)
    {
        bool MatchesId(GameObject obj, int id) { return obj.GetComponent<Unit>().id == id; }
        bool Exists(GameObject obj) { return obj.GetComponent<Robotsunit>() != null; }
        bool Color(GameObject obj, int color) { return obj.GetComponent<Robotsunit>().colorsPossesed.Contains(color); }


        recipes.Add((new Predicate<GameObject>[] {
            (GameObject u) => MatchesId(u, 700),
            (GameObject u) => MatchesId(u, 700),
            (GameObject u) => MatchesId(u, 700)},
            library.help[4]));

        recipes.Add((new Predicate<GameObject>[] {
            (GameObject u) => Exists(u) && Color(u, 0) && !MatchesId(u, 705),
            (GameObject u) => Exists(u) && Color(u, 0) && !MatchesId(u, 705)},
            library.help[5]));

        recipes.Add((new Predicate<GameObject>[] {
            (GameObject u) => MatchesId(u, 304),
            (GameObject u) => Exists(u) && Color(u, 1) && !MatchesId(u, 706)},
            library.help[6]));
    }

    public static IEnumerator CheckRecipes(GameObject[] units, Robots caller)
    {
        foreach ((Predicate<GameObject>[], GameObject) recipe in recipes)
        {
            Predicate<GameObject>[] require = recipe.Item1;
            if (require.Length == 2 && units.Length == 2)
            {
                if ((require[0](units[0]) && require[1](units[1])) || (require[0](units[1]) && require[1](units[0])))
                {
                    yield return caller.StartCoroutine(caller.ExecuteRecipe(new GameObject[2] { units[0], units[1] }, recipe.Item2));
                }
            }
            else
            {
                if (units.Length == 2) continue;
                if(require[0](units[0]) && require[1](units[1]) && require[2](units[2]))
                {
                    yield return caller.StartCoroutine(caller.ExecuteRecipe(new GameObject[3] { units[0], units[1], units[2] }, recipe.Item2));
                }
            }
        }
    }
}
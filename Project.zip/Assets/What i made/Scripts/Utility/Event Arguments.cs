using UnityEngine;

public enum dmgTypes
{
    damage,
    heal,
    HPIncrease
}

public class AttackData
{
    public int amount;
    public bool isCrit;
    public GameObject attacker;
    public bool interactive;
    public dmgTypes type;

    public AttackData(int amount, bool isCrit, GameObject attacker, bool interactive, dmgTypes type)
    {
        this.amount = amount;
        this.isCrit = isCrit;
        this.attacker = attacker;
        this.interactive = interactive;
        this.type = type;
    }
}

public class MoveData
{
    public GameObject movedObject;
    public int oldIndex;
    public int newIndex;

    public MoveData(GameObject moved, int oldIndex, int newIndex)
    {
        movedObject = moved;
        this.oldIndex = oldIndex;
        this.newIndex = newIndex;
    }
}

public class KillData
{
    public GameObject killer;
    public int side;
    public int index;

    public KillData(GameObject killer, int side, int index)
    {
        this.killer = killer;
        this.side = side;
        this.index = index;
    }
}

public class PlayData
{
    public int side;
    public int index;
    public int[] colors;

    public PlayData(int side, int index, int[] colors)
    {
        this.side = side;
        this.index = index;
        this.colors = colors;
    }
}

public class CritData
{
    public int side;
    public int index;
    public GameObject critter;

    public CritData(int side, int index, GameObject critter)
    {
        this.side = side;
        this.index = index;
        this.critter = critter;
    }
}

public class StatusData
{
    public int side;
    public int index;
    public bool buff;
    public GameObject carrier;

    public StatusData(int side, int index, bool buff, GameObject carrier)
    {
        this.side = side;
        this.index = index;
        this.buff = buff;
        this.carrier = carrier;
    }
}

public class HitData
{
    public int side;
    public int index;
    public AttackData attack;

    public HitData(int side, int index, AttackData attack)
    {
        this.index = index;
        this.side = side;
        this.attack = attack;
    }
}
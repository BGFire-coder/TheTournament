using UnityEngine;

public class PositionByIndex
{
    public static Vector3 GetPosition(int side, int index)
    {
        if (index < 5) return new Vector3((float)(-4 + side * 6.4f + ((1.6f - 3.2f * side) * index)), 0.9f + side * 2.35f, 0);
        else return new Vector3((float)(-4 + side * 6.4f + ((1.6f - 3.2f * side) * (index - 5))), -1 + side * 6.28f, 0);
    }

    public static Vector3 GetPositionInDeck(int index)
    {
        int row = index / 8;
        int col = index % 8;
        return new Vector3(-6f + col * 1.5f, 1 - row * 2, -1);
    }
}
using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class Message
{
    public static IEnumerator SendToAll(int side, string method, object args)
    {
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        foreach (GameObject go in controller.board[side].Where(x => x != controller.empty[side])) if(go.GetComponent<Unit>().supportedTriggers.Contains(method)) yield return go.GetComponent<Unit>().StartCoroutine(method, args);
        foreach (GameObject go in controller.board[1 - side].Where(x => x != controller.empty[1 - side])) if (go.GetComponent<Unit>().supportedTriggers.Contains(method)) yield return go.GetComponent<Unit>().StartCoroutine(method, args);
        for (int i = controller.activeEffects.Count - 1; i > -1; i--) if (controller.activeEffects[i].supportedTriggers.Contains(method)) yield return controller.activeEffects[i].StartCoroutine(method, args);
        List<GameObject> hand = controller.empty[side].GetComponent<Players>().hand;
        for (int i = hand.Count - 1; i > -1; i--) if (hand[i].GetComponent<Basecard>().supportedTriggers.Contains(method)) yield return hand[i].GetComponent<Unit>().StartCoroutine(method, args);
        hand = controller.empty[1 - side].GetComponent<Players>().hand;
        for (int i = hand.Count - 1; i > -1; i--) if (hand[i].GetComponent<Basecard>().supportedTriggers.Contains(method)) yield return hand[i].GetComponent<Unit>().StartCoroutine(method, args);
    }

    public static IEnumerator SendToBoard(int side, string method, object args)
    {
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        foreach (GameObject go in controller.board[side].Where(x => x != controller.empty[side])) if (go.GetComponent<Unit>().supportedTriggers.Contains(method)) yield return go.GetComponent<Unit>().StartCoroutine(method, args);
        foreach (GameObject go in controller.board[1 - side].Where(x => x != controller.empty[1 - side])) if (go.GetComponent<Unit>().supportedTriggers.Contains(method)) yield return go.GetComponent<Unit>().StartCoroutine(method, args);
        for (int i = controller.activeEffects.Count - 1; i > -1; i--) if (controller.activeEffects[i].supportedTriggers.Contains(method)) yield return controller.activeEffects[i].StartCoroutine(method, args);
    }

    public static IEnumerator SendToSide(int side, string method, object args)
    {
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        foreach (GameObject go in controller.board[side].Where(x => x != controller.empty[side])) if (go.GetComponent<Unit>().supportedTriggers.Contains(method)) yield return go.GetComponent<Unit>().StartCoroutine(method, args);
        for (int i = controller.activeEffects.Count - 1; i > -1; i--) if (controller.activeEffects[i].supportedTriggers.Contains(method)) yield return controller.activeEffects[i].StartCoroutine(method, args);
    }


    public static IEnumerator SendToAllOnASide(int side, string method, object args)
    {
        EndTurn controller = GameObject.Find("EndTurnButton").GetComponent<EndTurn>();
        foreach (GameObject go in controller.board[side].Where(x => x != controller.empty[side])) if (go.GetComponent<Unit>().supportedTriggers.Contains(method)) yield return go.GetComponent<Unit>().StartCoroutine(method, args);
        for (int i = controller.activeEffects.Count - 1; i > -1; i--) if (controller.activeEffects[i].supportedTriggers.Contains(method)) yield return controller.activeEffects[i].StartCoroutine(method, args);
        List<GameObject> hand = controller.empty[side].GetComponent<Players>().hand;
        for (int i = hand.Count - 1; i > -1; i--) if (hand[i].GetComponent<Basecard>().supportedTriggers.Contains(method)) yield return hand[i].GetComponent<Unit>().StartCoroutine(method, args);
    }

    public static IEnumerator SendToEffects(GameObject owner, string method, object args)
    {
        List<Effect> statuses = owner.GetComponent<Unit>().statuses;
        for (int i = statuses.Count - 1; i > -1; i--) if (statuses[i].supportedTriggers.Contains(method)) yield return statuses[i].StartCoroutine(method, args);
    }
}